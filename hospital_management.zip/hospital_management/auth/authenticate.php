<?php

session_start();

require_once "../config/database.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php");
    exit();
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

if ($username === '' || $password === '') {
    header("Location: login.php?error=Please enter username and password.");
    exit();
}

$sql = "SELECT id, username, password, full_name, role, status
        FROM users
        WHERE username = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Database error.");
}

$stmt->bind_param("s", $username);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    header("Location: login.php?error=Invalid username or password.");
    exit();
}

$user = $result->fetch_assoc();

if ($user['status'] !== 'active') {
    header("Location: login.php?error=Your account is inactive.");
    exit();
}

if (!password_verify($password, $user['password'])) {
    header("Location: login.php?error=Invalid username or password.");
    exit();
}

/*
 * Login successful
 */

session_regenerate_id(true);

$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['full_name'] = $user['full_name'];
$_SESSION['role'] = $user['role'];

$stmt->close();
$conn->close();

/*
 * Redirect according to role
 */

switch ($user['role']) {

    case 'admin':
        header("Location: ../admin/dashboard.php");
        break;

    case 'doctor':
        header("Location: ../doctor/dashboard.php");
        break;

    case 'receptionist':
        header("Location: ../receptionist/dashboard.php");
        break;

    case 'patient':
        header("Location: ../patient/dashboard.php");
        break;

    default:
        session_destroy();
        header("Location: login.php?error=Invalid account role.");
        break;
}

exit();

?>