<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: ../admin/dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Hospital Management System - Login</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #0d6efd, #00b4d8);
            min-height: 100vh;

            display: flex;
            justify-content: center;
            align-items: center;
        }

        .login-container {
            width: 400px;
            background: white;
            padding: 40px;

            border-radius: 15px;

            box-shadow:
                0 10px 30px rgba(0, 0, 0, 0.2);
        }

        .hospital-icon {
            text-align: center;
            font-size: 50px;
            color: #0d6efd;

            margin-bottom: 10px;
        }

        h1 {
            text-align: center;
            color: #333;

            margin-bottom: 5px;
        }

        .subtitle {
            text-align: center;
            color: #777;

            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;

            margin-bottom: 8px;

            color: #333;
            font-weight: bold;
        }

        input {
            width: 100%;

            padding: 12px;

            border: 1px solid #ddd;
            border-radius: 8px;

            font-size: 15px;
        }

        input:focus {
            outline: none;

            border-color: #0d6efd;
        }

        .login-btn {
            width: 100%;

            padding: 13px;

            border: none;
            border-radius: 8px;

            background: #0d6efd;
            color: white;

            font-size: 16px;
            font-weight: bold;

            cursor: pointer;
        }

        .login-btn:hover {
            background: #0b5ed7;
        }

        .error {
            background: #f8d7da;
            color: #842029;

            padding: 10px;

            border-radius: 6px;

            margin-bottom: 20px;

            text-align: center;
        }

        .footer {
            text-align: center;

            margin-top: 25px;

            color: #888;

            font-size: 13px;
        }
    </style>
</head>

<body>

    <div class="login-container">

        <div class="hospital-icon">
            ✚
        </div>

        <h1>
            Hospital Management
        </h1>

        <p class="subtitle">
            Administrator Login
        </p>

        <?php if (isset($_GET['error'])): ?>

            <div class="error">
                <?php
                echo htmlspecialchars($_GET['error']);
                ?>
            </div>

        <?php endif; ?>


        <form action="authenticate.php" method="POST">

            <div class="form-group">

                <label for="username">
                    Username
                </label>

                <input
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Enter username"
                    required
                    autocomplete="username"
                >

            </div>


            <div class="form-group">

                <label for="password">
                    Password
                </label>

                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Enter password"
                    required
                    autocomplete="current-password"
                >

            </div>


            <button
                type="submit"
                class="login-btn"
            >
                Login
            </button>

        </form>


        <div class="footer">
            © 2026 Hospital Management System
        </div>

    </div>

</body>
</html>