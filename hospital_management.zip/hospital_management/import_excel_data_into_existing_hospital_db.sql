USE hospital_management;

-- =========================================================
-- IMPORT EXCEL DUMMY DATA INTO YOUR EXISTING DATABASE
-- This script does NOT delete the existing admin account.
-- =========================================================

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Departments (new table if it does not already exist)
CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department_id VARCHAR(20) NOT NULL UNIQUE,
    department_name VARCHAR(100) NOT NULL,
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

-- 2. Admissions (new table)
CREATE TABLE IF NOT EXISTS admissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admission_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    admission_date DATE NOT NULL,
    room_no VARCHAR(30) NOT NULL,
    bed_no VARCHAR(30) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Admitted',
    discharge_date DATE NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 3. Medicines (new table)
CREATE TABLE IF NOT EXISTS medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_id VARCHAR(20) NOT NULL UNIQUE,
    medicine_name VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    unit_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Add invoice_number to your existing billing table.
-- Your existing invoice_id remains the primary numeric ID.
SET @column_exists := (
    SELECT COUNT(*)
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'billing'
      AND COLUMN_NAME = 'invoice_number'
);

SET @sql_add_invoice_number := IF(
    @column_exists = 0,
    'ALTER TABLE billing ADD COLUMN invoice_number VARCHAR(20) NULL AFTER invoice_id',
    'SELECT 1'
);
PREPARE stmt_add_invoice_number FROM @sql_add_invoice_number;
EXECUTE stmt_add_invoice_number;
DEALLOCATE PREPARE stmt_add_invoice_number;

-- =========================================================
-- PATIENTS: import 5 Excel records
-- =========================================================

INSERT INTO patients
(patient_id, name, gender, age, blood_group, phone, address, registration_date, status)
VALUES
('P0001', 'Rahim Uddin', 'Male', '45', '1711000001', 'B+', 'Dhaka', '2026-09-01', 'Active'),
('P0002', 'Nusrat Jahan', 'Female', '32', '1811000002', 'O+', 'Gazipur', '2026-09-01', 'Active'),
('P0003', 'Karim Ahmed', 'Male', '58', '1911000003', 'A+', 'Narayanganj', '2026-09-01', 'Active'),
('P0004', 'Sumi Akter', 'Female', '27', '1611000004', 'AB+', 'Cumilla', '2026-09-01', 'Active'),
('P0005', 'Hasan Mahmud', 'Male', '36', '1511000005', 'O-', 'Chattogram', '2026-09-01', 'Active');

-- =========================================================
-- DOCTORS: import 5 Excel records
-- =========================================================

INSERT INTO doctors
(doctor_id, name, specialization, phone, consultation_fee, status)
VALUES
('D001', 'Dr. Md. Kamal Hossain', 'Medicine', '1712000001', 800.0, 'Active'),
('D002', 'Dr. Farzana Rahman', 'Gynecology', '1812000002', 1000.0, 'Active'),
('D003', 'Dr. Saiful Islam', 'Cardiology', '1912000003', 1200.0, 'Active'),
('D004', 'Dr. Tania Ahmed', 'Pediatrics', '1612000004', 700.0, 'Active'),
('D005', 'Dr. Arif Khan', 'Orthopedics', '1512000005', 900.0, 'Active');

-- =========================================================
-- DEPARTMENTS: import 7 Excel records
-- =========================================================

INSERT INTO departments (department_id, department_name, status)
VALUES
('DEP001', 'Medicine', 'Active'),
('DEP002', 'Cardiology', 'Active'),
('DEP003', 'Gynecology', 'Active'),
('DEP004', 'Pediatrics', 'Active'),
('DEP005', 'Orthopedics', 'Active'),
('DEP006', 'Emergency', 'Active'),
('DEP007', 'Pathology', 'Active');

-- =========================================================
-- APPOINTMENTS: import 5 Excel records
-- =========================================================

INSERT INTO appointments
(appointment_id, patient_id, doctor_id, appointment_date, appointment_time, status)
SELECT x.appointment_id, p.id, d.id, x.appointment_date, x.appointment_time, x.status
FROM (
SELECT 'A0001' AS appointment_id, 'P0001' AS patient_code, 'D001' AS doctor_code, '2026-09-01' AS appointment_date, '10:00:00' AS appointment_time, 'Completed' AS status
UNION ALL
SELECT 'A0002' AS appointment_id, 'P0002' AS patient_code, 'D002' AS doctor_code, '2026-09-01' AS appointment_date, '11:30:00' AS appointment_time, 'Completed' AS status
UNION ALL
SELECT 'A0003' AS appointment_id, 'P0003' AS patient_code, 'D003' AS doctor_code, '2026-09-02' AS appointment_date, '09:30:00' AS appointment_time, 'Completed' AS status
UNION ALL
SELECT 'A0004' AS appointment_id, 'P0004' AS patient_code, 'D004' AS doctor_code, '2026-09-03' AS appointment_date, '12:00:00' AS appointment_time, 'Pending' AS status
UNION ALL
SELECT 'A0005' AS appointment_id, 'P0005' AS patient_code, 'D005' AS doctor_code, '2026-09-04' AS appointment_date, '15:00:00' AS appointment_time, 'Cancelled' AS status
) x
JOIN patients p ON p.patient_id = x.patient_code
JOIN doctors d ON d.doctor_id = x.doctor_code;

-- =========================================================
-- ADMISSIONS: import 3 Excel records
-- =========================================================

INSERT INTO admissions
(admission_id, patient_id, doctor_id, admission_date, room_no, bed_no, status)
SELECT x.admission_id, p.id, d.id, x.admission_date, x.room_no, x.bed_no, x.status
FROM (
SELECT 'AD001' AS admission_id, 'P0001' AS patient_code, 'D001' AS doctor_code, '2026-09-01' AS admission_date, 'R101' AS room_no, 'B01' AS bed_no, 'Admitted' AS status
UNION ALL
SELECT 'AD002' AS admission_id, 'P0003' AS patient_code, 'D003' AS doctor_code, '2026-09-02' AS admission_date, 'R201' AS room_no, 'B03' AS bed_no, 'Admitted' AS status
UNION ALL
SELECT 'AD003' AS admission_id, 'P0005' AS patient_code, 'D005' AS doctor_code, '2026-09-03' AS admission_date, 'R301' AS room_no, 'B02' AS bed_no, 'Discharged' AS status
) x
JOIN patients p ON p.patient_id = x.patient_code
JOIN doctors d ON d.doctor_id = x.doctor_code;

-- =========================================================
-- MEDICINES: import 5 Excel records
-- =========================================================

INSERT INTO medicines
(medicine_id, medicine_name, category, unit_price, stock, status)
VALUES
('M001', 'Napa 500mg', 'Tablet', 2.0, 5000, 'Available'),
('M002', 'Omeprazole 20mg', 'Capsule', 3.5, 3000, 'Available'),
('M003', 'Azithromycin 500mg', 'Tablet', 15.0, 1200, 'Available'),
('M004', 'Salbutamol', 'Inhaler', 180.0, 150, 'Available'),
('M005', 'Ceftriaxone 1g', 'Injection', 120.0, 300, 'Available');

-- =========================================================
-- BILLS: import 5 Excel records
-- =========================================================

INSERT INTO billing
(invoice_number, patient_id, appointment_id,
 consultation_fee, medicine_fee, test_fee, room_fee,
 other_fee, discount, total_amount,
 payment_status, payment_method, billing_date, notes)
SELECT
    x.invoice_number,
    p.id,
    a.id,
    x.consultation,
    x.medicine,
    x.test_fee,
    x.room_fee,
    0,
    0,
    x.total,
    'Unpaid',
    'Cash',
    x.bill_date,
    'Imported from Excel dummy data'
FROM (
SELECT 'INV001' AS invoice_number, 'P0001' AS patient_code, '2026-09-01' AS bill_date, 800.0 AS consultation, 250.0 AS medicine, 600.0 AS test_fee, 1000.0 AS room_fee, 2650.0 AS total
UNION ALL
SELECT 'INV002' AS invoice_number, 'P0002' AS patient_code, '2026-09-01' AS bill_date, 1000.0 AS consultation, 450.0 AS medicine, 800.0 AS test_fee, 0.0 AS room_fee, 2250.0 AS total
UNION ALL
SELECT 'INV003' AS invoice_number, 'P0003' AS patient_code, '2026-09-02' AS bill_date, 1200.0 AS consultation, 850.0 AS medicine, 1500.0 AS test_fee, 2000.0 AS room_fee, 5550.0 AS total
UNION ALL
SELECT 'INV004' AS invoice_number, 'P0004' AS patient_code, '2026-09-03' AS bill_date, 700.0 AS consultation, 300.0 AS medicine, 500.0 AS test_fee, 0.0 AS room_fee, 1500.0 AS total
UNION ALL
SELECT 'INV005' AS invoice_number, 'P0005' AS patient_code, '2026-09-04' AS bill_date, 900.0 AS consultation, 600.0 AS medicine, 750.0 AS test_fee, 1500.0 AS room_fee, 3750.0 AS total
) x
JOIN patients p ON p.patient_id = x.patient_code
LEFT JOIN appointments a
    ON a.patient_id = p.id
   AND a.appointment_date = x.bill_date;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================================================
-- VERIFY IMPORT
-- =========================================================

SELECT 'Patients' AS table_name, COUNT(*) AS total FROM patients
UNION ALL
SELECT 'Doctors', COUNT(*) FROM doctors
UNION ALL
SELECT 'Departments', COUNT(*) FROM departments
UNION ALL
SELECT 'Appointments', COUNT(*) FROM appointments
UNION ALL
SELECT 'Admissions', COUNT(*) FROM admissions
UNION ALL
SELECT 'Medicines', COUNT(*) FROM medicines
UNION ALL
SELECT 'Bills', COUNT(*) FROM billing
UNION ALL
SELECT 'Users', COUNT(*) FROM users;
