# Import the Apollo Imperial Hospitals doctor directory

This update contains **115 public directory profiles across 35 departments**,
collected from all 10 pages of the [Apollo Imperial Hospitals doctor directory](https://aihlbd.org/our-doctors/)
on **9 September 2026 (UTC)**. The two other department filter options returned
no doctors: Critical Care & Emergency, and Internal Medicine & Nephrology.

The update is ready to run on your computer. Your local XAMPP database has not
been accessed or changed by preparing these files.

## Install on your current project

1. Export a backup of your existing `hospital_management` database in
   phpMyAdmin and keep copies of the PHP files you replace.
2. Extract `hospital_doctors_update.zip`. Copy the **contents** of its
   `hospital_management` folder into `C:\xampp\htdocs\hospital_management\`,
   replacing the matching files. This updates the Doctors page and the doctor
   dropdowns in Appointments and Medical Records. No database connection file
   is included or replaced.
3. Start Apache and MySQL in XAMPP. Open phpMyAdmin, select your existing
   **hospital_management** database, then choose **Import**.
4. Select `imports/aihl_doctors_import.sql` from the extracted files and click
   **Import/Go**. The file is self-contained; the JSON file is not required to
   execute the import. Use phpMyAdmin's SQL-file import so it processes the
   included `DELIMITER` statements.
5. Refresh **Dashboard → Doctors**. Click **View** on an imported doctor to see
   the designation, experience, photograph, and source information.

Import only `aihl_doctors_import.sql` for this update. Do not re-import the
original schema files over your existing database. If your database has a
different name, select that database in phpMyAdmin; the import uses the
currently selected database rather than a hardcoded database name.

The import returns `source_doctors`, `added_doctors`, `matched_doctors` and
`Import completed`. You should get **115 source doctors**. Your Doctors list
may have more than 115 rows because your existing unrelated doctors are kept.

## What is imported

| Website field | Database destination |
| --- | --- |
| Doctor name | `doctors.name` |
| Department | `doctors.specialization`; also linked through `department_id` if your schema has a departments table |
| Qualifications | `doctors.qualification` |
| Designation | `doctor_external_profiles.designation` |
| Experience as listed | `doctor_external_profiles.experience` |
| Photograph URL and available image sizes | `doctor_external_profiles.photo_url` and `photo_srcset` |
| Source hospital, directory URL, page and retrieval date | `doctor_external_profiles` |

The source table also keeps the original listed name, department and
qualifications. The complete extracted dataset is included in
`imports/aihl_doctors_data.json`. Spelling follows the source website; only
whitespace is normalized.

The directory does not provide personal phone numbers, email addresses,
addresses, gender, dates of birth, joining dates, consultation fees or live
availability. New records leave those personal fields and fees as `NULL`.
Existing values in matched records are preserved. The general hospital
appointment number is not assigned as each doctor's personal phone number.

Photographs are saved as source URLs and displayed from the source website;
they require an internet connection. Image files are not bundled in the ZIP.

## Existing records and repeat imports

- The importer first matches its saved source identifier. On a first import,
  it can match one existing doctor with the same full name and specialization,
  ignoring case and leading/trailing spaces.
- A matched doctor keeps the existing numeric `id` and readable `doctor_id`.
  Appointments, prescriptions, admissions and medical records keep referencing
  the same numeric ID.
- Source name, specialization, qualifications and source-profile details are
  refreshed. Existing contacts, fees, status, user account links and personal
  dates are preserved. When present, `department_id` is linked to the imported
  department.
- New doctors receive stable codes beginning with `AIHL-`. A repeat import of
  this file matches the same records instead of adding them again.
- Two local matches with the same name and specialization cause the import to
  stop for review. It also stops if an import code belongs to an unrelated row.
  Different spellings or titles in existing names are not fuzzy-matched.
- No doctor is removed because it is absent from this snapshot. Importing the
  same file does not fetch newer website data. A newer recorded snapshot is
  protected against replacement by this older one.

New records use your database's existing default status: **Active** in the
import schema or **Available** in the classic schema. This is a local
application setting, not availability downloaded from the website. The
updated forms and doctor dropdowns recognize both schema formats.

## Database and page changes

The script creates `doctor_external_profiles` only if it is missing. If the
existing consultation-fee column rejects `NULL`, it changes that column to
`DECIMAL(10,2) NULL DEFAULT NULL`; existing fee values remain unchanged. These
schema preparations commit separately from the doctor-data transaction.

The import uses a temporary staging table, a short-lived stored procedure and
a database-scoped advisory lock. Doctor data changes run inside an InnoDB
transaction, with rollback on a query failure. The stored procedure is dropped
after success. phpMyAdmin's database user needs permission to create/alter
tables, create/drop routines, and update records; the usual local XAMPP root
account supports these operations.

The updated Doctors page displays unknown fees as **Not provided**, while an
explicit zero fee displays **৳0.00**. Blank optional contacts and dates can be
saved without inventing data. **View** includes the source hospital so imported
directory details remain attributable to Apollo Imperial Hospitals.

## If the import reports an error

- **No database selected:** select your project database before using Import.
- **Ambiguous local doctor duplicates:** review rows with identical full names
  and specializations. The script deliberately avoids guessing which ID to use.
- **AIHL code already used:** inspect that existing code and its linked records
  before changing it; the import does not overwrite an unrelated doctor.
- **Another import is running:** wait for it to finish, then retry.
- **Permissions/schema/InnoDB error:** use the database account and schema for
  your XAMPP project. Do not remove the checks or disable foreign keys to force
  the import through.

Schema preparations may remain after a failed data import, but the doctor-data
transaction is rolled back. Resolve the reported issue and import the same
file again.

## Validation

The SQL was executed with **MariaDB 10.11.18 in offline bootstrap mode** against
both supplied schema layouts. Checks covered all 115 profiles, exact imported
field values, repeated imports, existing IDs/contact details/fees/statuses,
appointment references, all 35 department links where supported, rejection of
ambiguous matches, and rollback after an injected failure late in the import.
The user's local XAMPP server was not accessed.

PHP syntax checks and 18 isolated Doctors-page cases also passed, covering
source-profile display, unknown versus zero fees, saving blank optional fields,
editing, both status formats, and invalid input. Those page checks used actual
PHP execution with a SQLite-backed mysqli adapter; the SQL import checks used
the MariaDB engine itself. Browser layout testing was not performed.
