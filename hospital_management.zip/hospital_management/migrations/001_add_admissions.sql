-- Existing installation: select your hospital database in phpMyAdmin first.
-- Creates the missing table; leaves existing admission records unchanged.
CREATE TABLE IF NOT EXISTS admissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admission_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    admission_date DATE NOT NULL,
    room_no VARCHAR(30) NOT NULL,
    bed_no VARCHAR(30) NOT NULL,
    status ENUM('Admitted','Discharged') NOT NULL DEFAULT 'Admitted',
    discharge_date DATE NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_admissions_patient_status (patient_id, status),
    INDEX idx_admissions_bed_status (room_no, bed_no, status),
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
