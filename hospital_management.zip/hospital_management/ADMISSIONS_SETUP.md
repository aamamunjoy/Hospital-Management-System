# Add patient admissions to The People's Hospital

Add an **Admissions** page beside **Patients** in the dashboard navigation.
Keep admissions in their own table: a patient can have several hospital stays,
and a new stay should not overwrite their earlier admission history.

## Install on your existing XAMPP project

1. Back up the PHP files you are replacing and export your current database
   from phpMyAdmin.
2. Extract `hospital_admissions_update.zip`. Copy the included
   `hospital_management` folder into `C:\xampp\htdocs\`, merging it with your
   existing folder and replacing the matching admin files.
3. Start Apache and MySQL. Open phpMyAdmin, select your existing
   `hospital_management` database, choose **Import**, and select
   `hospital_management/migrations/001_add_admissions.sql` from the extracted files.
   This script creates `admissions` only if it is missing. If you imported the
   supplied schema that already has this table, the script leaves it unchanged.
4. Sign in as administrator and open **Dashboard → Admissions**, or visit
   `http://localhost/hospital_management/admin/admissions.php`.
5. Choose a registered patient and doctor, enter the admission date, room and
   bed, keep the status **Admitted**, and click **Admit patient**.

Import only `001_add_admissions.sql` for this update. Do not re-import the
original `database.sql` or `hospital_management_import.sql` over your live data.
The update package does not contain a database connection file, so your current
connection settings stay in place.

## Where each file goes

| File | Destination under `C:\xampp\htdocs\hospital_management\` | Purpose |
| --- | --- | --- |
| `admissions.php` | `admin\admissions.php` | Form, admission history, editing, discharge, search and status filter |
| `dashboard.php` | `admin\dashboard.php` | Adds Admissions to the dashboard menu and Clinical workspace |
| `_common.php` | `admin\_common.php` | Adds Admissions to the shared admin navigation |
| `admin.css` | `admin\assets\admin.css` | Shared admin page styles, included for the new page |
| `001_add_admissions.sql` | `migrations\001_add_admissions.sql` | Import this file in phpMyAdmin if the table is missing |

The Admissions page uses the existing `admin/assets/admin.css` stylesheet,
`admin/_common.php` helpers, and `config/database.php` connection. It must run
inside your existing project; it is not a standalone PHP application.

If you have made additional dashboard changes since the previous download,
merge this entry into the `$navigation` array in your own `admin/dashboard.php`
immediately after Patients instead of replacing that file:

```php
'admissions.php' => 'Admissions',
```

In `admin/_common.php`, the shared `$items` array uses names without `.php`:

```php
'admissions' => 'Admissions',
```

## Form fields

| Field | How it works |
| --- | --- |
| Patient ID / name | Select an existing patient; the table stores the numeric `patients.id` reference and displays the readable `patients.patient_id` code. |
| Assigned doctor | Required because the admissions table in your supplied database requires `doctor_id`. Register a doctor first if the list is empty. |
| Admission date | A valid date up to today. |
| Room number | Required, up to 30 characters, for example `R101`. |
| Bed number | Required, up to 30 characters, for example `B01`. Bed numbers may repeat in different rooms. |
| Status | `Admitted` or `Discharged`, matching your existing database. |
| Discharge date | Required when selecting `Discharged`; must be between admission and today. |

Admission IDs are generated automatically. Patient and doctor profile tables
are not altered by this update. Existing admission notes remain unchanged when
editing a record.

## Daily use

- **Edit** corrects an admission's details or records a discharge on a selected date.
- **Discharge** marks an active stay as discharged today, releases its bed and
  keeps the admission in the history. For another discharge date, use Edit.
- A discharged patient returning to hospital gets a **new admission**. Keep the
  earlier stay as a separate record.
- Search by patient name/code, admission ID, room or bed. Filter by status.
  History shows 25 records per page.
- An active bed cannot be assigned to a second active admission through this page.
  A patient cannot have two active admissions through this page. These checks
  concern current occupancy; the module does not check overlapping dates in
  imported or historical discharged records, or manage a predefined room inventory.

Writes require an administrator session and the existing CSRF token. Queries
use prepared statements. A database-scoped MySQL advisory lock serializes this
page's check-and-save operations, and a transaction groups each change. Any
other code that writes admissions must follow the same locking rules or provide
its own database-level constraints. The lock is explicitly released after the
transaction; see the [MySQL locking documentation](https://dev.mysql.com/doc/refman/8.4/en/locking-functions.html).

If the table is missing, the page displays the migration instructions instead
of attempting to create tables on a web request. Detailed query failures go to
the PHP error log, normally `C:\xampp\php\logs\php_error_log` if configured there.
If your database has a different admissions schema from the supplied files,
`CREATE TABLE IF NOT EXISTS` does not modify its columns.

## Validation

PHP and JavaScript syntax checks passed, along with 76 isolated workflow tests
using actual PHP execution with a SQLite-backed mysqli adapter. These exercise
the column layouts from both supplied schemas. They do not connect to your
XAMPP/MySQL server or verify real MySQL lock contention. After installing, try
an admission, a conflicting bed, an edit, and a discharge using test records
before entering real records. Dates follow your PHP server's configured timezone.
