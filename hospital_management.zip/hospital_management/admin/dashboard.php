<?php
// Self-contained PHP dashboard: no external CSS, JavaScript or icon downloads.
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../auth/login.php');
    exit;
}
require_once __DIR__ . '/../config/database.php';

function dashboard_escape($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function dashboard_icon($name) {
    return '<svg class="icon" aria-hidden="true" focusable="false"><use href="#icon-' . dashboard_escape($name) . '"></use></svg>';
}
$fullName = trim((string) ($_SESSION['full_name'] ?? ''));
if ($fullName === '') $fullName = 'Administrator';
$initial = function_exists('mb_substr') ? mb_substr($fullName, 0, 1, 'UTF-8') : substr($fullName, 0, 1);
$today = date('Y-m-d');

// Both SQL files in the supplied archive use different settings formats.
// Support either format without a database migration.
$hospitalName = 'Hospital Management';
$settings = $conn->query('SELECT * FROM system_settings LIMIT 50');
while ($setting = $settings->fetch_assoc()) {
    if (($setting['setting_name'] ?? '') === 'hospital_name' && trim((string) ($setting['setting_value'] ?? '')) !== '') {
        $hospitalName = trim($setting['setting_value']);
    } elseif (trim((string) ($setting['hospital_name'] ?? '')) !== '') {
        $hospitalName = trim($setting['hospital_name']);
    }
}
$settings->free();

// Fixed table allowlist; these identifiers never come from request input.
$totals = [];
foreach (['patients', 'doctors', 'appointments', 'users'] as $table) {
    $result = $conn->query("SELECT COUNT(*) AS total FROM `$table`");
    $totals[$table] = (int) $result->fetch_assoc()['total'];
    $result->free();
}
$statusCounts = ['Scheduled' => 0, 'Pending' => 0, 'Completed' => 0, 'Cancelled' => 0];
$stmt = $conn->prepare('SELECT status, COUNT(*) AS total FROM appointments WHERE appointment_date = ? GROUP BY status');
$stmt->bind_param('s', $today);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    if (array_key_exists($row['status'], $statusCounts)) $statusCounts[$row['status']] = (int) $row['total'];
}
$stmt->close();
$todayTotal = array_sum($statusCounts);
$completionRate = $todayTotal > 0 ? (int) round($statusCounts['Completed'] / $todayTotal * 100) : 0;

$stmt = $conn->prepare('SELECT a.id, a.appointment_id, a.appointment_time, a.status,
    p.name AS patient_name, d.name AS doctor_name
    FROM appointments a
    INNER JOIN patients p ON p.id = a.patient_id
    INNER JOIN doctors d ON d.id = a.doctor_id
    WHERE a.appointment_date = ?
    ORDER BY a.appointment_time ASC, a.id ASC LIMIT 10');
$stmt->bind_param('s', $today);
$stmt->execute();
$appointments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$navigation = [
    'dashboard.php' => 'Dashboard', 'patients.php' => 'Patients',
    'admissions.php' => 'Admissions',
    'doctors.php' => 'Doctors', 'appointments.php' => 'Appointments',
    'medical_records.php' => 'Medical records', 'prescriptions.php' => 'Prescriptions',
    'billing.php' => 'Billing', 'reports.php' => 'Reports',
    'users.php' => 'Users'
];
$metrics = [
    ['patients', 'Total patients', 'Registered patient profiles', 'patients', 'patients.php'],
    ['doctors', 'Doctors', 'Hospital doctor directory', 'doctor', 'doctors.php'],
    ['appointments', 'Appointments', 'All recorded appointments', 'calendar', 'appointments.php'],
    ['users', 'System users', 'Registered user accounts', 'users', 'users.php']
];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title>Dashboard | <?= dashboard_escape($hospitalName) ?></title>
    <style>
        /* Reference-inspired palette. Change these variables to rebrand. */
        :root {
            --teal: #007c9d;
            --teal-dark: #005d77;
            --teal-deep: #073e50;
            --gold: #fcd34d;
            --ink: #183b49;
            --muted: #526b77;
            --line: #dce8ed;
            --paper: #f4f8fa;
        }
        * { box-sizing: border-box; }
        body { margin: 0; color: var(--ink); background: var(--paper); font: 1rem/1.55 "Segoe UI", Arial, sans-serif; }
        h1, h2, h3, p { margin: 0; }
        a { color: inherit; text-decoration: none; }
        button { font: inherit; cursor: pointer; }
        a:focus-visible, button:focus-visible, [tabindex]:focus-visible { outline: 3px solid #d79200; outline-offset: 4px; }
        .icon { width: 1.4rem; height: 1.4rem; flex: 0 0 auto; fill: none; stroke: currentColor; stroke-width: 1.7; stroke-linecap: round; stroke-linejoin: round; }
        .sprite { position: absolute; width: 0; height: 0; overflow: hidden; }
        .container { width: min(1280px, calc(100% - 64px)); margin-inline: auto; }
        .sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip-path: inset(50%); white-space: nowrap; border: 0; }
        .skip-link { position: fixed; top: -100px; left: 16px; z-index: 30; background: var(--gold); padding: 12px 20px; font-weight: 700; }
        .skip-link:focus { top: 12px; }

        /* Hospital header and navigation. */
        .utility-bar { background: var(--teal-deep); color: #fff; font-size: .8125rem; }
        .utility-inner { min-height: 36px; display: flex; justify-content: space-between; align-items: center; gap: 12px; padding-block: 6px; }
        .utility-inner p { letter-spacing: .03em; }
        .utility-inner time { color: #e1f3f7; }
        .site-header { background: #fff; }
        .header-inner { min-height: 106px; display: flex; align-items: center; justify-content: space-between; gap: 28px; padding-block: 20px; }
        .brand { display: flex; align-items: center; gap: 14px; min-width: 0; }
        .brand-mark { background: var(--teal); color: #fff; width: 58px; height: 58px; border-radius: 15px 15px 15px 3px; display: grid; place-items: center; position: relative; flex: 0 0 auto; }
        .brand-mark::after { content: ""; position: absolute; bottom: -4px; right: -4px; width: 17px; height: 17px; border-radius: 50%; border: 3px solid #fff; background: var(--gold); }
        .brand-mark .icon { width: 35px; height: 35px; stroke-width: 2.3; }
        .brand-name { display: block; font-size: clamp(1.1rem, 2.3vw, 1.55rem); font-weight: 750; line-height: 1.25; color: var(--teal-dark); overflow-wrap: anywhere; }
        .brand-label { display: block; margin-top: 5px; color: var(--muted); font-size: .8125rem; text-transform: uppercase; letter-spacing: .1em; }
        .account { display: flex; align-items: center; gap: 15px; flex-shrink: 0; }
        .avatar { display: grid; place-items: center; width: 42px; height: 42px; border-radius: 50%; background: #e7f4f8; color: var(--teal-dark); font-weight: 700; text-transform: uppercase; }
        .account-copy { display: grid; max-width: 230px; overflow-wrap: anywhere; }
        .account-copy strong { font-size: .9375rem; }
        .account-copy span { color: var(--muted); font-size: .8125rem; }
        .logout { display: inline-flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 15px; border: 1px solid var(--line); border-radius: 6px; font-size: .875rem; font-weight: 650; background: #fff; min-height: 44px; white-space: nowrap; }
        .logout:hover { background: #fff2f1; border-color: #b94842; color: #a6322d; }
        .logout .icon { width: 18px; height: 18px; }
        .navigation { background: var(--teal); color: #fff; }
        .nav-links { display: flex; align-items: stretch; flex-wrap: wrap; gap: 0 4px; }
        .nav-links a { display: flex; align-items: center; min-height: 54px; padding: 13px 14px; font-size: .875rem; font-weight: 600; border-bottom: 3px solid transparent; }
        .nav-links a:hover { background: var(--teal-dark); }
        .nav-links a[aria-current="page"] { color: var(--gold); border-bottom-color: var(--gold); background: #006d8a; }
        .menu-toggle { display: none; min-height: 50px; color: #fff; background: transparent; border: 0; padding: 10px 0; align-items: center; justify-content: space-between; width: 100%; font-weight: 650; }

        /* Overview and primary actions. */
        main { padding-top: 28px; padding-bottom: 40px; }
        .breadcrumb { font-size: .8125rem; color: var(--muted); display: flex; align-items: center; gap: 8px; margin-bottom: 16px; }
        .breadcrumb .icon { width: 13px; height: 13px; }
        .page-heading { display: flex; justify-content: space-between; align-items: center; gap: 20px; margin-bottom: 26px; }
        .eyebrow { font-size: .8125rem; font-weight: 750; color: var(--teal); text-transform: uppercase; letter-spacing: .09em; margin-bottom: 5px; }
        h1 { font-size: clamp(1.8rem, 3.2vw, 2.55rem); line-height: 1.2; letter-spacing: -.035em; font-weight: 750; }
        .welcome-copy { color: var(--muted); margin-top: 9px; }
        .welcome-copy strong { color: var(--ink); font-weight: 600; }
        .button { display: inline-flex; align-items: center; justify-content: center; gap: 9px; padding: 12px 19px; border-radius: 6px; font-size: .9375rem; font-weight: 700; min-height: 46px; flex-shrink: 0; }
        .button-gold { background: var(--gold); color: #2d3c31; border: 1px solid var(--gold); }
        .button-gold:hover { background: #f4c332; border-color: #f4c332; }
        .button-teal { background: var(--teal); color: #fff; }
        .button-teal:hover { background: var(--teal-dark); }
        .metrics { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 18px; margin-bottom: 25px; }
        .metric { display: flex; flex-direction: column; background: #fff; border: 1px solid var(--line); border-top: 3px solid var(--teal); border-radius: 9px; padding: 20px 21px 18px; transition: border-color .15s, box-shadow .15s; }
        .metric:hover { border-color: var(--teal); box-shadow: 0 4px 18px #00415a0c; }
        .metric:nth-child(3) { border-top-color: var(--gold); }
        .metric-top { display: flex; justify-content: space-between; align-items: center; gap: 12px; }
        .metric-label { font-size: .875rem; font-weight: 600; color: var(--muted); }
        .metric-icon { width: 38px; height: 38px; border-radius: 9px; display: grid; place-items: center; color: var(--teal); background: #edf7fa; }
        .metric:nth-child(3) .metric-icon { background: #fff8dc; color: #806000; }
        .metric-number { font-size: clamp(1.9rem, 3vw, 2.4rem); font-weight: 750; letter-spacing: -.025em; line-height: 1.2; margin: 9px 0 7px; overflow-wrap: anywhere; font-variant-numeric: tabular-nums; }
        .metric-note { color: var(--muted); font-size: .8125rem; }
        .quick-actions { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); background: #fff; border: 1px solid var(--line); border-radius: 9px; margin-bottom: 28px; overflow: hidden; }
        .quick-action { display: flex; align-items: center; gap: 13px; padding: 18px 20px; border-right: 1px solid var(--line); min-width: 0; }
        .quick-action:last-child { border-right: 0; }
        .quick-action:hover { background: #eff9fc; }
        .quick-action > .icon { width: 26px; height: 26px; color: var(--teal); }
        .quick-action strong { display: block; font-size: .9375rem; font-weight: 650; }
        .quick-action small { display: block; color: var(--muted); font-size: .8125rem; margin-top: 2px; }

        /* Appointment workspace. */
        .workspace-grid { display: grid; grid-template-columns: minmax(0, 1fr) 294px; gap: 22px; align-items: start; }
        .panel { background: #fff; border: 1px solid var(--line); border-radius: 10px; overflow: hidden; }
        .panel-heading { padding: 22px 24px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
        h2 { font-size: 1.18rem; font-weight: 750; line-height: 1.3; }
        .panel-subtitle { color: var(--muted); font-size: .8125rem; margin-top: 5px; }
        .text-link { display: inline-flex; align-items: center; gap: 6px; color: var(--teal-dark); font-weight: 650; font-size: .875rem; white-space: nowrap; min-height: 36px; }
        .text-link:hover { text-decoration: underline; }
        .text-link .icon { width: 16px; height: 16px; }
        .table-scroll { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; }
        th { background: #f3f8fa; border-block: 1px solid var(--line); color: var(--muted); font-size: .8125rem; font-weight: 650; padding: 13px 16px; white-space: nowrap; }
        td { border-bottom: 1px solid #e8eff2; padding: 17px 16px; font-size: .875rem; vertical-align: middle; }
        th:first-child, td:first-child { padding-left: 24px; }
        th:last-child, td:last-child { padding-right: 24px; }
        tbody tr:last-child td { border-bottom: 0; }
        tbody tr:hover { background: #fcfefe; }
        .time { white-space: nowrap; font-weight: 650; font-variant-numeric: tabular-nums; }
        .patient-name { display: block; font-weight: 650; min-width: 140px; overflow-wrap: anywhere; }
        .record-link { display: inline-block; color: var(--teal-dark); font-size: .8125rem; margin-top: 3px; text-decoration: underline; text-underline-offset: 3px; }
        .doctor-name { min-width: 130px; overflow-wrap: anywhere; }
        .badge { display: inline-flex; align-items: center; border-radius: 5px; padding: 4px 9px; font-size: .875rem; line-height: 1.5; white-space: nowrap; }
        .badge-scheduled { color: #075d77; background: #e7f4fa; }
        .badge-pending { color: #7b5900; background: #fff3ce; }
        .badge-completed { color: #17643f; background: #e7f6ec; }
        .badge-cancelled { color: #a33936; background: #ffeded; }
        .badge-other { color: #455563; background: #edf1f4; }
        .table-footer { border-top: 1px solid var(--line); padding: 14px 24px; font-size: .8125rem; color: var(--muted); }
        .empty { display: flex; align-items: center; flex-direction: column; text-align: center; padding: 45px 25px; }
        .empty > .icon { width: 44px; height: 44px; color: var(--teal); margin-bottom: 16px; }
        .empty h3 { font-size: 1rem; margin-bottom: 6px; }
        .empty p { color: var(--muted); margin-bottom: 20px; max-width: 360px; }
        .day-summary { padding: 24px; border-top: 4px solid var(--gold); }
        .day-total { display: flex; align-items: baseline; gap: 9px; margin: 18px 0 19px; }
        .day-total strong { font-size: 2.35rem; font-weight: 750; line-height: 1; color: var(--teal-dark); font-variant-numeric: tabular-nums; }
        .day-total span { color: var(--muted); font-size: .875rem; }
        .progress-caption { font-size: .875rem; display: flex; justify-content: space-between; margin-bottom: 9px; gap: 12px; }
        progress { display: block; width: 100%; height: 7px; border: 0; border-radius: 6px; background: #e7eff2; appearance: none; overflow: hidden; }
        progress::-webkit-progress-bar { background: #e7eff2; }
        progress::-webkit-progress-value { background: var(--teal); border-radius: 6px; }
        progress::-moz-progress-bar { background: var(--teal); border-radius: 6px; }
        .status-list { margin: 17px 0 20px; padding: 0; list-style: none; }
        .status-list li { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #edf2f4; font-size: .875rem; }
        .status-list li:last-child { border: 0; }
        .status-list span { display: inline-flex; align-items: center; gap: 9px; }
        .status-list span::before { content: ""; width: 7px; height: 7px; border-radius: 2px; background: var(--teal); }
        .status-list .pending::before { background: #bf8c00; }
        .status-list .completed::before { background: #248855; }
        .status-list .cancelled::before { background: #bd5353; }
        .summary-link { display: block; text-align: center; border: 1px solid #bcdae4; border-radius: 6px; padding: 10px 12px; color: var(--teal-dark); font-size: .875rem; font-weight: 650; }
        .summary-link:hover { background: #eff9fc; }
        .clinical-links { margin-top: 20px; padding: 22px 24px; }
        .clinical-links h2 { font-size: 1rem; margin-bottom: 12px; }
        .clinical-links a { display: flex; align-items: center; gap: 10px; padding: 10px 0; font-size: .875rem; }
        .clinical-links a:hover { color: var(--teal); text-decoration: underline; }
        .clinical-links .icon { color: var(--teal); width: 19px; height: 19px; }
        .site-footer { border-top: 4px solid var(--gold); background: var(--teal-deep); color: #fff; }
        .footer-inner { display: flex; align-items: center; justify-content: space-between; gap: 20px; padding-block: 23px; }
        .footer-inner strong { font-weight: 650; display: block; font-size: .9375rem; }
        .footer-inner small { display: block; color: #d0e5ec; font-size: .8125rem; margin-top: 3px; }
        .footer-links { display: flex; align-items: center; gap: 24px; font-size: .875rem; }
        .footer-links a:hover { color: var(--gold); text-decoration: underline; }

        /* Responsive navigation, cards and tables. */
        @media (max-width: 1120px) {
            .container { width: calc(100% - 40px); }
            .nav-links a { padding-inline: 10px; }
            .workspace-grid { grid-template-columns: minmax(0, 1fr) 270px; gap: 18px; }
            .quick-action { padding-inline: 15px; gap: 10px; }
            .quick-action small { display: none; }
            .metric { padding-inline: 17px; }
        }
        @media (max-width: 920px) {
            .header-inner { min-height: 94px; gap: 16px; }
            .account-copy { display: none; }
            .menu-toggle:not([hidden]) { display: flex; }
            .navigation[data-collapsible="true"][data-open="false"] .nav-links { display: none; }
            .nav-links { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); padding-bottom: 10px; }
            .nav-links a { min-height: 45px; }
            .metrics { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
            .workspace-grid { grid-template-columns: minmax(0, 1fr); }
            .support-panels { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 18px; align-items: start; }
            .clinical-links { margin-top: 0; }
            .quick-actions { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .quick-action { padding: 16px 18px; }
            .quick-action:nth-child(2) { border-right: 0; }
            .quick-action:nth-child(-n+2) { border-bottom: 1px solid var(--line); }
            .quick-action small { display: block; }
        }
        @media (max-width: 620px) {
            .container { width: calc(100% - 32px); }
            .utility-inner { font-size: .75rem; flex-wrap: wrap; gap: 2px 12px; }
            .header-inner { align-items: center; gap: 12px; padding-block: 17px; }
            .brand { gap: 10px; }
            .brand-mark { width: 42px; height: 42px; border-radius: 10px 10px 10px 2px; }
            .brand-mark .icon { width: 29px; height: 29px; }
            .brand-name { font-size: 1.0625rem; }
            .brand-label { font-size: .75rem; letter-spacing: .03em; }
            .avatar { display: none; }
            .logout { padding: 9px 10px; gap: 5px; }
            .logout .icon { display: none; }
            main { padding-top: 20px; }
            .page-heading { display: block; margin-bottom: 20px; }
            .page-heading .button { margin-top: 18px; }
            .welcome-copy { font-size: .9375rem; }
            .metric { padding: 15px 13px; }
            .metric-top { align-items: start; gap: 6px; }
            .metric-icon { width: 30px; height: 30px; }
            .metric-icon .icon { width: 18px; height: 18px; }
            .metric-note { font-size: .75rem; }
            .quick-action { align-items: start; padding: 15px 13px; gap: 9px; }
            .quick-action > .icon { width: 20px; height: 20px; margin-top: 3px; }
            .quick-action strong { font-size: .875rem; }
            .quick-action small { font-size: .75rem; }
            .panel-heading { padding: 20px 18px; flex-wrap: wrap; gap: 10px; }
            .support-panels { grid-template-columns: minmax(0, 1fr); }
            .footer-inner { flex-direction: column; align-items: start; }
            .footer-links { flex-wrap: wrap; gap: 14px 24px; }
        }
        @media (max-width: 360px) {
            .metrics, .quick-actions { grid-template-columns: minmax(0, 1fr); }
            .quick-action { border-right: 0; border-bottom: 1px solid var(--line); }
            .quick-action:last-child { border-bottom: 0; }
        }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; scroll-behavior: auto !important; } }
        @media print {
            body { background: white; }
            .utility-bar, .navigation, .account, .quick-actions, .page-heading .button, .clinical-links, .footer-links, .summary-link { display: none; }
            .container { width: 100%; }
            .header-inner { min-height: auto; }
            .metrics { grid-template-columns: repeat(4, minmax(0, 1fr)); }
            .workspace-grid { display: block; }
            .support-panels { margin-top: 20px; }
            .panel, .metric { break-inside: avoid; }
            .table-scroll { overflow: visible; }
            .site-footer { color: #183b49; background: white; }
        }
    </style>
</head>
<body>
<a class="skip-link" href="#main-content">Skip to dashboard</a>
<svg class="sprite" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <symbol id="icon-cross" viewBox="0 0 24 24"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/></symbol>
    <symbol id="icon-calendar" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18M8 15h2M14 15h2M8 18h2"/></symbol>
    <symbol id="icon-patients" viewBox="0 0 24 24"><circle cx="9" cy="7" r="4"/><path d="M2 21v-2a7 7 0 0 1 14 0v2M20 8v6M17 11h6"/></symbol>
    <symbol id="icon-users" viewBox="0 0 24 24"><circle cx="8" cy="8" r="4"/><path d="M1 21v-2a7 7 0 0 1 14 0v2M16 4a4 4 0 0 1 0 8M23 21v-2a7 7 0 0 0-5-6.7"/></symbol>
    <symbol id="icon-doctor" viewBox="0 0 24 24"><path d="M6 3H3v5a6 6 0 0 0 12 0V3h-3M6 2v3M12 2v3M9 14v2a5 5 0 0 0 10 0v-3"/><circle cx="19" cy="10" r="3"/></symbol>
    <symbol id="icon-arrow" viewBox="0 0 24 24"><path d="M4 12h16M14 6l6 6-6 6"/></symbol>
    <symbol id="icon-chevron" viewBox="0 0 24 24"><path d="m9 5 7 7-7 7"/></symbol>
    <symbol id="icon-plus" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></symbol>
    <symbol id="icon-record" viewBox="0 0 24 24"><path d="M14 2H5a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V9zM14 2v7h7M8 13h8M8 17h5"/></symbol>
    <symbol id="icon-bill" viewBox="0 0 24 24"><path d="m4 3 2 1 2-1 2 1 2-1 2 1 2-1 2 1 2-1v18l-2-1-2 1-2-1-2 1-2-1-2 1-2-1-2 1zM8 8h8M8 12h8M8 16h4"/></symbol>
    <symbol id="icon-pill" viewBox="0 0 24 24"><path d="m10 3-7 7a6.36 6.36 0 0 0 9 9l7-7a6.36 6.36 0 0 0-9-9ZM7 7l10 10"/></symbol>
    <symbol id="icon-chart" viewBox="0 0 24 24"><path d="M3 3v18h18M7 16v-5M12 16V7M17 16v-8"/></symbol>
    <symbol id="icon-logout" viewBox="0 0 24 24"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M9 12h12m-5-5 5 5-5 5"/></symbol>
    <symbol id="icon-menu" viewBox="0 0 24 24"><path d="M3 6h18M3 12h18M3 18h18"/></symbol>
</svg>

<div class="utility-bar">
    <div class="container utility-inner">
        <p>Hospital management system · Administrator portal</p>
        <time datetime="<?= dashboard_escape($today) ?>"><?= dashboard_escape(date('l, d F Y')) ?></time>
    </div>
</div>
<header class="site-header">
    <div class="container header-inner">
        <a class="brand" href="dashboard.php" aria-label="The People's Hospital dashboard">
            <span class="brand-mark"><?= dashboard_icon('cross') ?></span>
            <span class="brand-name">The People's Hospital</span>
        </a>
        <div class="account">
            <span class="avatar" aria-hidden="true"><?= dashboard_escape($initial) ?></span>
            <div class="account-copy"><strong><?= dashboard_escape($fullName) ?></strong><span>Administrator</span></div>
            <a class="logout" href="../auth/logout.php" data-logout><?= dashboard_icon('logout') ?>Log out</a>
        </div>
    </div>
</header>
<nav class="navigation" aria-label="Main navigation" id="main-navigation">
    <div class="container">
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="navigation-links" hidden>Menu <?= dashboard_icon('menu') ?></button>
        <div class="nav-links" id="navigation-links">
            <?php foreach ($navigation as $href => $label): ?>
                <a href="<?= dashboard_escape($href) ?>"<?= $href === 'dashboard.php' ? ' aria-current="page"' : '' ?>><?= dashboard_escape($label) ?></a>
            <?php endforeach; ?>
        </div>
    </div>
</nav>

<main class="container" id="main-content" tabindex="-1">
    <p class="breadcrumb">Administration <?= dashboard_icon('chevron') ?> <span>Dashboard</span></p>
    <div class="page-heading">
        <div>
            <p class="eyebrow">Hospital overview</p>
            <h1>Your hospital, at a glance.</h1>
            <p class="welcome-copy">Welcome back, <strong><?= dashboard_escape($fullName) ?></strong>.</p>
        </div>
        <a class="button button-gold" href="appointments.php"><?= dashboard_icon('plus') ?>New appointment</a>
    </div>

    <section class="metrics" aria-label="Hospital totals">
        <?php foreach ($metrics as $metric): ?>
            <a class="metric" href="<?= dashboard_escape($metric[4]) ?>">
                <span class="metric-top"><span class="metric-label"><?= dashboard_escape($metric[1]) ?></span><span class="metric-icon"><?= dashboard_icon($metric[3]) ?></span></span>
                <strong class="metric-number"><?= number_format($totals[$metric[0]]) ?></strong>
                <span class="metric-note"><?= dashboard_escape($metric[2]) ?></span>
            </a>
        <?php endforeach; ?>
    </section>

    <nav class="quick-actions" aria-label="Quick actions">
        <a class="quick-action" href="patients.php"><?= dashboard_icon('patients') ?><span><strong>Register a patient</strong><small>Patient profiles &amp; details</small></span></a>
        <a class="quick-action" href="doctors.php"><?= dashboard_icon('doctor') ?><span><strong>Manage doctors</strong><small>Consultants &amp; specialties</small></span></a>
        <a class="quick-action" href="billing.php"><?= dashboard_icon('bill') ?><span><strong>Billing &amp; payments</strong><small>Invoices &amp; payment status</small></span></a>
        <a class="quick-action" href="reports.php"><?= dashboard_icon('chart') ?><span><strong>View reports</strong><small>Hospital activity &amp; billing</small></span></a>
    </nav>

    <div class="workspace-grid">
        <section class="panel" aria-labelledby="appointments-title">
            <div class="panel-heading">
                <div><h2 id="appointments-title">Today's appointments</h2><p class="panel-subtitle"><?= dashboard_escape(date('d F Y')) ?> · In time order</p></div>
                <a class="text-link" href="appointments.php">View all <?= dashboard_icon('arrow') ?></a>
            </div>
            <?php if (count($appointments) > 0): ?>
                <div class="table-scroll" tabindex="0" role="region" aria-label="Today's appointment table; scroll horizontally on small screens">
                    <table>
                        <caption class="sr-only">First ten appointments today, ordered by appointment time.</caption>
                        <thead><tr><th scope="col">Time</th><th scope="col">Patient</th><th scope="col">Doctor</th><th scope="col">Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($appointments as $appointment):
                            $status = (string) $appointment['status'];
                            $statusClass = array_key_exists($status, $statusCounts) ? strtolower($status) : 'other';
                            $appointmentTime = strtotime($appointment['appointment_time']);
                        ?>
                            <tr>
                                <td class="time"><?= dashboard_escape($appointmentTime !== false ? date('h:i A', $appointmentTime) : $appointment['appointment_time']) ?></td>
                                <td><span class="patient-name"><?= dashboard_escape($appointment['patient_name']) ?></span><a class="record-link" href="appointments.php?edit=<?= (int) $appointment['id'] ?>" aria-label="Edit appointment <?= dashboard_escape($appointment['appointment_id']) ?>"><?= dashboard_escape($appointment['appointment_id']) ?></a></td>
                                <td class="doctor-name"><?= dashboard_escape($appointment['doctor_name']) ?></td>
                                <td><span class="badge badge-<?= $statusClass ?>"><?= dashboard_escape($status) ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="table-footer">Showing <?= count($appointments) ?> of <?= number_format($todayTotal) ?> appointments for today.</div>
            <?php else: ?>
                <div class="empty">
                    <?= dashboard_icon('calendar') ?>
                    <h3>No appointments today</h3>
                    <p>New bookings for today will appear here.</p>
                    <a class="button button-teal" href="appointments.php">Book an appointment <?= dashboard_icon('arrow') ?></a>
                </div>
            <?php endif; ?>
        </section>

        <aside class="support-panels" aria-label="Daily summary and clinical tools">
            <section class="panel day-summary" aria-labelledby="day-title">
                <p class="eyebrow">Today's activity</p><h2 id="day-title">Appointment summary</h2>
                <div class="day-total"><strong><?= number_format($todayTotal) ?></strong><span><?= $todayTotal === 1 ? 'appointment' : 'appointments' ?> today</span></div>
                <div class="progress-caption"><label for="day-progress">Completed</label><strong><?= $completionRate ?>%</strong></div>
                <progress id="day-progress" max="100" value="<?= $completionRate ?>"><?= $completionRate ?>%</progress>
                <ul class="status-list">
                    <?php foreach ($statusCounts as $label => $count): ?>
                        <li><span class="<?= strtolower($label) ?>"><?= dashboard_escape($label) ?></span><strong><?= number_format($count) ?></strong></li>
                    <?php endforeach; ?>
                </ul>
                <a class="summary-link" href="appointments.php">Manage appointments</a>
            </section>
            <section class="panel clinical-links" aria-labelledby="clinical-title">
                <h2 id="clinical-title">Clinical workspace</h2>
                <a href="admissions.php"><?= dashboard_icon('patients') ?>Patient admissions</a>
                <a href="medical_records.php"><?= dashboard_icon('record') ?>Medical records</a>
                <a href="prescriptions.php"><?= dashboard_icon('pill') ?>Prescriptions</a>
            </section>
        </aside>
    </div>
</main>

<footer class="site-footer">
    <div class="container footer-inner">
        <div><strong><?= dashboard_escape($hospitalName) ?></strong><small>&copy; <?= date('Y') ?> · Hospital management system</small></div>
        <nav class="footer-links" aria-label="Administration links"><a href="reports.php">Reports</a><a href="../auth/logout.php" data-logout>Log out</a></nav>
    </div>
</footer>
<script>
    // Links remain available without JavaScript. Add a mobile disclosure menu.
    (function () {
        const navigation = document.getElementById('main-navigation');
        const toggle = navigation.querySelector('.menu-toggle');
        toggle.hidden = false;
        navigation.dataset.collapsible = 'true';
        navigation.dataset.open = 'false';
        function setOpen(open) {
            navigation.dataset.open = String(open);
            toggle.setAttribute('aria-expanded', String(open));
        }
        toggle.addEventListener('click', function () {
            setOpen(toggle.getAttribute('aria-expanded') !== 'true');
        });
        navigation.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
                setOpen(false);
                toggle.focus();
            }
        });
        document.querySelectorAll('[data-logout]').forEach(function (link) {
            link.addEventListener('click', function (event) {
                if (!window.confirm('Are you sure you want to log out?')) event.preventDefault();
            });
        });
    }());
</script>
</body>
</html>
