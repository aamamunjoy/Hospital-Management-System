<?php

session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

require_once "../config/database.php";

$message = "";
$error = "";

/* =========================================================
   DELETE PATIENT
========================================================= */

if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);

    if ($id > 0) {

        $stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");

        if ($stmt) {

            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                $message = "Patient deleted successfully.";
            } else {
                $error = "Unable to delete patient.";
            }

            $stmt->close();

        } else {
            $error = "Database error.";
        }
    }
}


/* =========================================================
   ADD PATIENT
========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST" &&
    isset($_POST['add_patient'])) {

    $name = trim($_POST['name'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $date_of_birth = $_POST['date_of_birth'] ?? '';
    $blood_group = trim($_POST['blood_group'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $emergency_contact = trim($_POST['emergency_contact'] ?? '');
    $emergency_contact_name =
        trim($_POST['emergency_contact_name'] ?? '');
    $medical_history =
        trim($_POST['medical_history'] ?? '');
    $allergies =
        trim($_POST['allergies'] ?? '');

    if ($name === '') {

        $error = "Patient name is required.";

    } elseif ($phone === '') {

        $error = "Phone number is required.";

    } else {

        /* Generate Patient ID */

        $result = $conn->query(
            "SELECT id FROM patients ORDER BY id DESC LIMIT 1"
        );

        if ($result && $result->num_rows > 0) {

            $lastPatient = $result->fetch_assoc();
            $nextNumber = $lastPatient['id'] + 1;

        } else {

            $nextNumber = 1;
        }

        $patient_id = "PAT-" .
            str_pad(
                $nextNumber,
                5,
                "0",
                STR_PAD_LEFT
            );

        $sql = "INSERT INTO patients
        (
            patient_id,
            name,
            gender,
            date_of_birth,
            blood_group,
            phone,
            email,
            address,
            emergency_contact,
            emergency_contact_name,
            medical_history,
            allergies
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);

        if ($stmt) {

            $stmt->bind_param(
                "ssssssssssss",
                $patient_id,
                $name,
                $gender,
                $date_of_birth,
                $blood_group,
                $phone,
                $email,
                $address,
                $emergency_contact,
                $emergency_contact_name,
                $medical_history,
                $allergies
            );

            if ($stmt->execute()) {

                $message =
                    "Patient registered successfully. Patient ID: "
                    . $patient_id;

            } else {

                $error =
                    "Unable to register patient.";
            }

            $stmt->close();

        } else {

            $error = "Database error.";
        }
    }
}


/* =========================================================
   UPDATE PATIENT
========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST" &&
    isset($_POST['update_patient'])) {

    $id = intval($_POST['id']);

    $name = trim($_POST['name'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $date_of_birth = $_POST['date_of_birth'] ?? '';
    $blood_group = trim($_POST['blood_group'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $emergency_contact =
        trim($_POST['emergency_contact'] ?? '');
    $emergency_contact_name =
        trim($_POST['emergency_contact_name'] ?? '');
    $medical_history =
        trim($_POST['medical_history'] ?? '');
    $allergies =
        trim($_POST['allergies'] ?? '');

    if ($name === '') {

        $error = "Patient name is required.";

    } elseif ($phone === '') {

        $error = "Phone number is required.";

    } else {

        $sql = "UPDATE patients SET
                name = ?,
                gender = ?,
                date_of_birth = ?,
                blood_group = ?,
                phone = ?,
                email = ?,
                address = ?,
                emergency_contact = ?,
                emergency_contact_name = ?,
                medical_history = ?,
                allergies = ?
                WHERE id = ?";

        $stmt = $conn->prepare($sql);

        if ($stmt) {

            $stmt->bind_param(
                "sssssssssssi",
                $name,
                $gender,
                $date_of_birth,
                $blood_group,
                $phone,
                $email,
                $address,
                $emergency_contact,
                $emergency_contact_name,
                $medical_history,
                $allergies,
                $id
            );

            if ($stmt->execute()) {

                $message =
                    "Patient information updated successfully.";

            } else {

                $error =
                    "Unable to update patient.";
            }

            $stmt->close();

        } else {

            $error = "Database error.";
        }
    }
}


/* =========================================================
   SEARCH
========================================================= */

$search = trim($_GET['search'] ?? '');

if ($search !== '') {

    $searchValue = "%" . $search . "%";

    $stmt = $conn->prepare(
        "SELECT *
         FROM patients
         WHERE patient_id LIKE ?
         OR name LIKE ?
         OR phone LIKE ?
         OR email LIKE ?
         ORDER BY id DESC"
    );

    $stmt->bind_param(
        "ssss",
        $searchValue,
        $searchValue,
        $searchValue,
        $searchValue
    );

    $stmt->execute();

    $patients = $stmt->get_result();

    $stmt->close();

} else {

    $patients = $conn->query(
        "SELECT *
         FROM patients
         ORDER BY id DESC"
    );
}


/* =========================================================
   EDIT PATIENT
========================================================= */

$editPatient = null;

if (isset($_GET['edit'])) {

    $editId = intval($_GET['edit']);

    $stmt = $conn->prepare(
        "SELECT * FROM patients WHERE id = ?"
    );

    $stmt->bind_param("i", $editId);

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $editPatient = $result->fetch_assoc();
    }

    $stmt->close();
}


/* =========================================================
   VIEW PATIENT
========================================================= */

$viewPatient = null;

if (isset($_GET['view'])) {

    $viewId = intval($_GET['view']);

    $stmt = $conn->prepare(
        "SELECT * FROM patients WHERE id = ?"
    );

    $stmt->bind_param("i", $viewId);

    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $viewPatient = $result->fetch_assoc();
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Patient Management | Hospital Management System</title>

<style>

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    background: #f4f7fb;
    color: #333;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position: fixed;
    left: 0;
    top: 0;

    width: 240px;
    height: 100vh;

    background: #172b4d;
    color: white;

    padding-top: 25px;
}

.sidebar h2 {

    text-align: center;
    margin-bottom: 30px;
    font-size: 22px;
}

.sidebar a {

    display: block;

    color: #dbe5f5;
    text-decoration: none;

    padding: 14px 25px;

    font-size: 15px;
}

.sidebar a:hover,
.sidebar a.active {

    background: #1f6feb;
    color: white;
}


/* =========================================================
   MAIN CONTENT
========================================================= */

.main {

    margin-left: 240px;
    padding: 30px;
}


/* =========================================================
   TOP HEADER
========================================================= */

.header {

    background: white;

    padding: 20px 25px;

    border-radius: 10px;

    margin-bottom: 25px;

    box-shadow: 0 2px 8px rgba(0,0,0,0.06);

    display: flex;
    justify-content: space-between;
    align-items: center;
}

.header h1 {

    font-size: 25px;
    color: #172b4d;
}

.header span {

    color: #666;
}


/* =========================================================
   MESSAGES
========================================================= */

.success {

    background: #d1e7dd;
    color: #0f5132;

    padding: 14px;

    border-radius: 6px;

    margin-bottom: 20px;
}

.error {

    background: #f8d7da;
    color: #842029;

    padding: 14px;

    border-radius: 6px;

    margin-bottom: 20px;
}


/* =========================================================
   CARD
========================================================= */

.card {

    background: white;

    border-radius: 10px;

    padding: 25px;

    margin-bottom: 25px;

    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.card h2 {

    margin-bottom: 20px;
    color: #172b4d;
}


/* =========================================================
   FORM
========================================================= */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}

.form-group {

    display: flex;
    flex-direction: column;
}

.form-group.full {

    grid-column: 1 / -1;
}

.form-group label {

    font-weight: bold;

    margin-bottom: 7px;

    font-size: 14px;
}

.form-group input,
.form-group select,
.form-group textarea {

    padding: 11px;

    border: 1px solid #ccd4df;

    border-radius: 6px;

    font-size: 14px;

    outline: none;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #1f6feb;
}

.form-group textarea {

    resize: vertical;
    min-height: 80px;
}

.btn {

    border: none;

    padding: 11px 18px;

    border-radius: 6px;

    cursor: pointer;

    font-size: 14px;

    text-decoration: none;

    display: inline-block;
}

.btn-primary {

    background: #1f6feb;
    color: white;
}

.btn-primary:hover {

    background: #1557b0;
}

.btn-success {

    background: #198754;
    color: white;
}

.btn-warning {

    background: #f0ad4e;
    color: white;
}

.btn-danger {

    background: #dc3545;
    color: white;
}

.btn-secondary {

    background: #6c757d;
    color: white;
}


/* =========================================================
   SEARCH
========================================================= */

.search-box {

    display: flex;
    gap: 10px;

    margin-bottom: 20px;
}

.search-box input {

    flex: 1;

    padding: 12px;

    border: 1px solid #ccd4df;

    border-radius: 6px;
}


/* =========================================================
   TABLE
========================================================= */

.table-container {

    overflow-x: auto;
}

table {

    width: 100%;

    border-collapse: collapse;

    min-width: 900px;
}

table th {

    background: #172b4d;

    color: white;

    padding: 13px;

    text-align: left;

    font-size: 14px;
}

table td {

    padding: 12px;

    border-bottom: 1px solid #e5e7eb;

    font-size: 14px;
}

table tr:hover {

    background: #f8fafc;
}


/* =========================================================
   ACTION BUTTONS
========================================================= */

.actions {

    display: flex;
    gap: 5px;
    flex-wrap: wrap;
}

.actions .btn {

    padding: 7px 10px;

    font-size: 12px;
}


/* =========================================================
   PATIENT DETAILS
========================================================= */

.details-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 15px;
}

.detail-item {

    padding: 12px;

    background: #f8fafc;

    border-radius: 6px;
}

.detail-item strong {

    display: block;

    color: #172b4d;

    margin-bottom: 5px;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .sidebar {

        width: 200px;
    }

    .main {

        margin-left: 200px;
    }

    .form-grid {

        grid-template-columns: 1fr 1fr;
    }
}

@media (max-width: 650px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .main {

        margin-left: 0;

        padding: 15px;
    }

    .form-grid {

        grid-template-columns: 1fr;
    }

    .details-grid {

        grid-template-columns: 1fr;
    }

    .header {

        flex-direction: column;

        align-items: flex-start;

        gap: 10px;
    }
}

</style>

</head>

<body>


<!-- ======================================================
     SIDEBAR
====================================================== -->

<div class="sidebar">

    <h2>🏥 HMS</h2>

    <a href="dashboard.php">
        Dashboard
    </a>

    <a href="patients.php" class="active">
        👤 Patients
    </a>

    <a href="doctors.php">
        👨‍⚕️ Doctors
    </a>

    <a href="appointments.php">
        📅 Appointments
    </a>

    <a href="medical_records.php">
        📋 Medical Records
    </a>

    <a href="prescriptions.php">
        💊 Prescriptions
    </a>

    <a href="billing.php">
        💰 Billing
    </a>

    <a href="reports.php">
        📊 Reports
    </a>

    <a href="users.php">
        👥 Users
    </a>

    <a href="settings.php">
        ⚙ Settings
    </a>

    <a href="../auth/logout.php">
        🚪 Logout
    </a>

</div>


<!-- ======================================================
     MAIN
====================================================== -->

<div class="main">


    <!-- HEADER -->

    <div class="header">

        <h1>Patient Management</h1>

        <span>
            Welcome,
            <?php echo htmlspecialchars(
                $_SESSION['full_name']
            ); ?>
        </span>

    </div>


    <!-- MESSAGES -->

    <?php if ($message !== ""): ?>

        <div class="success">
            <?php echo htmlspecialchars($message); ?>
        </div>

    <?php endif; ?>


    <?php if ($error !== ""): ?>

        <div class="error">
            <?php echo htmlspecialchars($error); ?>
        </div>

    <?php endif; ?>


    <!-- ==================================================
         VIEW PATIENT DETAILS
    =================================================== -->

    <?php if ($viewPatient): ?>

    <div class="card">

        <h2>Patient Details</h2>

        <div class="details-grid">

            <div class="detail-item">
                <strong>Patient ID</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['patient_id']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Name</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['name']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Gender</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['gender']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Date of Birth</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['date_of_birth']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Blood Group</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['blood_group']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Phone</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['phone']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Email</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['email']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Registration Date</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['registration_date']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Emergency Contact Name</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['emergency_contact_name']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Emergency Contact</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['emergency_contact']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Status</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['status']
                ); ?>
            </div>

            <div class="detail-item">
                <strong>Address</strong>
                <?php echo htmlspecialchars(
                    $viewPatient['address']
                ); ?>
            </div>

            <div class="detail-item">

                <strong>Medical History</strong>

                <?php echo nl2br(
                    htmlspecialchars(
                        $viewPatient['medical_history']
                    )
                ); ?>

            </div>

            <div class="detail-item">

                <strong>Allergies</strong>

                <?php echo nl2br(
                    htmlspecialchars(
                        $viewPatient['allergies']
                    )
                ); ?>

            </div>

        </div>

        <br>

        <a href="patients.php"
           class="btn btn-secondary">
            ← Back to Patients
        </a>

    </div>

    <?php endif; ?>


    <!-- ==================================================
         ADD / EDIT PATIENT
    =================================================== -->

    <?php if (!$viewPatient): ?>

    <div class="card">

        <h2>
            <?php
            echo $editPatient
                ? "Edit Patient"
                : "Register New Patient";
            ?>
        </h2>


        <form method="POST"
              action="patients.php<?php
                  echo $editPatient
                      ? '?edit=' . $editPatient['id']
                      : '';
              ?>">


            <?php if ($editPatient): ?>

                <input
                    type="hidden"
                    name="id"
                    value="<?php echo $editPatient['id']; ?>"
                >

            <?php endif; ?>


            <div class="form-grid">


                <!-- NAME -->

                <div class="form-group">

                    <label>
                        Patient Name *
                    </label>

                    <input
                        type="text"
                        name="name"
                        required
                        value="<?php
                        echo htmlspecialchars(
                            $editPatient['name'] ?? ''
                        );
                        ?>"
                    >

                </div>


                <!-- GENDER -->

                <div class="form-group">

                    <label>Gender</label>

                    <select name="gender">

                        <option value="">
                            Select Gender
                        </option>

                        <option value="Male"
                            <?php
                            if (($editPatient['gender'] ?? '')
                                === 'Male')
                                echo 'selected';
                            ?>>
                            Male
                        </option>

                        <option value="Female"
                            <?php
                            if (($editPatient['gender'] ?? '')
                                === 'Female')
                                echo 'selected';
                            ?>>
                            Female
                        </option>

                        <option value="Other"
                            <?php
                            if (($editPatient['gender'] ?? '')
                                === 'Other')
                                echo 'selected';
                            ?>>
                            Other
                        </option>

                    </select>

                </div>


                <!-- DOB -->

                <div class="form-group">

                    <label>Date of Birth</label>

                    <input
                        type="date"
                        name="date_of_birth"
                        value="<?php
                        echo htmlspecialchars(
                            $editPatient['date_of_birth'] ?? ''
                        );
                        ?>"
                    >

                </div>


                <!-- BLOOD GROUP -->

                <div class="form-group">

                    <label>Blood Group</label>

                    <select name="blood_group">

                        <option value="">
                            Select Blood Group
                        </option>

                        <?php

                        $bloodGroups = [
                            "A+",
                            "A-",
                            "B+",
                            "B-",
                            "AB+",
                            "AB-",
                            "O+",
                            "O-"
                        ];

                        foreach ($bloodGroups as $group):

                        ?>

                        <option value="<?php echo $group; ?>"
                            <?php
                            if (($editPatient['blood_group'] ?? '')
                                === $group)
                                echo 'selected';
                            ?>>

                            <?php echo $group; ?>

                        </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <!-- PHONE -->

                <div class="form-group">

                    <label>Phone *</label>

                    <input
                        type="text"
                        name="phone"
                        required
                        value="<?php
                        echo htmlspecialchars(
                            $editPatient['phone'] ?? ''
                        );
                        ?>"
                    >

                </div>


                <!-- EMAIL -->

                <div class="form-group">

                    <label>Email</label>

                    <input
                        type="email"
                        name="email"
                        value="<?php
                        echo htmlspecialchars(
                            $editPatient['email'] ?? ''
                        );
                        ?>"
                    >

                </div>


                <!-- ADDRESS -->

                <div class="form-group full">

                    <label>Address</label>

                    <textarea
                        name="address"
                    ><?php
                    echo htmlspecialchars(
                        $editPatient['address'] ?? ''
                    );
                    ?></textarea>

                </div>


                <!-- EMERGENCY CONTACT NAME -->

                <div class="form-group">

                    <label>
                        Emergency Contact Name
                    </label>

                    <input
                        type="text"
                        name="emergency_contact_name"
                        value="<?php
                        echo htmlspecialchars(
                            $editPatient[
                                'emergency_contact_name'
                            ] ?? ''
                        );
                        ?>"
                    >

                </div>


                <!-- EMERGENCY CONTACT -->

                <div class="form-group">

                    <label>
                        Emergency Contact
                    </label>

                    <input
                        type="text"
                        name="emergency_contact"
                        value="<?php
                        echo htmlspecialchars(
                            $editPatient[
                                'emergency_contact'
                            ] ?? ''
                        );
                        ?>"
                    >

                </div>


                <!-- MEDICAL HISTORY -->

                <div class="form-group full">

                    <label>
                        Medical History
                    </label>

                    <textarea
                        name="medical_history"
                    ><?php
                    echo htmlspecialchars(
                        $editPatient[
                            'medical_history'
                        ] ?? ''
                    );
                    ?></textarea>

                </div>


                <!-- ALLERGIES -->

                <div class="form-group full">

                    <label>
                        Allergies
                    </label>

                    <textarea
                        name="allergies"
                    ><?php
                    echo htmlspecialchars(
                        $editPatient[
                            'allergies'
                        ] ?? ''
                    );
                    ?></textarea>

                </div>


            </div>


            <br>


            <?php if ($editPatient): ?>

                <button
                    type="submit"
                    name="update_patient"
                    class="btn btn-success">
                    Update Patient
                </button>

                <a
                    href="patients.php"
                    class="btn btn-secondary">
                    Cancel
                </a>

            <?php else: ?>

                <button
                    type="submit"
                    name="add_patient"
                    class="btn btn-primary">
                    Register Patient
                </button>

            <?php endif; ?>


        </form>

    </div>

    <?php endif; ?>


    <!-- ==================================================
         PATIENT LIST
    =================================================== -->

    <div class="card">

        <h2>Patient List</h2>


        <!-- SEARCH -->

        <form method="GET"
              class="search-box">

            <input
                type="text"
                name="search"
                placeholder="Search by Patient ID, Name, Phone or Email..."
                value="<?php echo htmlspecialchars($search); ?>"
            >

            <button
                type="submit"
                class="btn btn-primary">
                🔎 Search
            </button>

            <?php if ($search !== ''): ?>

                <a
                    href="patients.php"
                    class="btn btn-secondary">
                    Clear
                </a>

            <?php endif; ?>

        </form>


        <!-- TABLE -->

        <div class="table-container">

        <table>

            <thead>

                <tr>

                    <th>#</th>

                    <th>Patient ID</th>

                    <th>Name</th>

                    <th>Gender</th>

                    <th>Blood Group</th>

                    <th>Phone</th>

                    <th>Registration Date</th>

                    <th>Actions</th>

                </tr>

            </thead>


            <tbody>

            <?php

            if ($patients &&
                $patients->num_rows > 0):

                $counter = 1;

                while ($patient =
                    $patients->fetch_assoc()):

            ?>

                <tr>

                    <td>
                        <?php echo $counter++; ?>
                    </td>

                    <td>
                        <strong>
                            <?php
                            echo htmlspecialchars(
                                $patient['patient_id']
                            );
                            ?>
                        </strong>
                    </td>

                    <td>
                        <?php
                        echo htmlspecialchars(
                            $patient['name']
                        );
                        ?>
                    </td>

                    <td>
                        <?php
                        echo htmlspecialchars(
                            $patient['gender']
                        );
                        ?>
                    </td>

                    <td>
                        <?php
                        echo htmlspecialchars(
                            $patient['blood_group']
                        );
                        ?>
                    </td>

                    <td>
                        <?php
                        echo htmlspecialchars(
                            $patient['phone']
                        );
                        ?>
                    </td>

                    <td>
                        <?php
                        echo htmlspecialchars(
                            $patient['registration_date']
                        );
                        ?>
                    </td>

                    <td>

                        <div class="actions">

                            <a
                                href="patients.php?view=<?php
                                echo $patient['id'];
                                ?>"
                                class="btn btn-primary">
                                View
                            </a>

                            <a
                                href="patients.php?edit=<?php
                                echo $patient['id'];
                                ?>"
                                class="btn btn-warning">
                                Edit
                            </a>

                            <a
                                href="patients.php?delete=<?php
                                echo $patient['id'];
                                ?>"
                                class="btn btn-danger"
                                onclick="return confirm(
                                    'Are you sure you want to delete this patient?'
                                );">
                                Delete
                            </a>

                        </div>

                    </td>

                </tr>

            <?php

                endwhile;

            else:

            ?>

                <tr>

                    <td colspan="8"
                        style="text-align:center;padding:30px;">

                        No patients found.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

        </div>

    </div>

</div>

</body>

</html>