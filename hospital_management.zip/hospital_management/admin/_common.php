<?php
session_start();
if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'admin') {
    header('Location: ../auth/login.php'); exit;
}
require_once '../config/database.php';
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function csrf() { return '<input type="hidden" name="csrf" value="'.e($_SESSION['csrf']).'">'; }
function verify_csrf() { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) die('Invalid request token.'); }
function flash($type, $message) { $_SESSION['flash'] = [$type, $message]; }
function pull_flash() { $f = $_SESSION['flash'] ?? null; unset($_SESSION['flash']); return $f; }
function page_top($title, $active) {
    $name = e($_SESSION['full_name'] ?? 'Administrator');
    $items=['dashboard'=>'Dashboard','patients'=>'Patients','admissions'=>'Admissions','doctors'=>'Doctors','appointments'=>'Appointments','medical_records'=>'Medical Records','prescriptions'=>'Prescriptions','billing'=>'Billing','reports'=>'Reports','users'=>'Users','settings'=>'Settings'];
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.e($title).' | Hospital Management</title><link rel="stylesheet" href="assets/admin.css"></head><body><aside><div class="brand"><span>✚</span><b>CarePoint</b><small>Hospital Management</small></div><nav>';
    foreach($items as $file=>$label) echo '<a '.($active===$file?'class="active" ':'').'href="'.$file.'.php">'.e($label).'</a>';
    echo '</nav><a class="logout" href="../auth/logout.php">Sign out</a></aside><main><header><div><p class="eyebrow">ADMIN PORTAL</p><h1>'.e($title).'</h1></div><div class="profile"><span>'.strtoupper(substr($name,0,1)).'</span><div><b>'.$name.'</b><small>Administrator</small></div></div></header>';
    $f=pull_flash(); if($f) echo '<div class="alert '.e($f[0]).'">'.e($f[1]).'</div>';
}
function page_bottom(){ echo '</main></body></html>'; }
