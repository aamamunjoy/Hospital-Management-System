<?php

session_start();

require_once "../config/database.php";

/* =========================================================
   ADMIN ACCESS PROTECTION
========================================================= */

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$message = "";
$error = "";
$editRecord = null;


/* =========================================================
   DELETE MEDICAL RECORD
========================================================= */

if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);

    if ($id > 0) {

        $stmt = $conn->prepare("
            DELETE FROM medical_records
            WHERE record_id = ?
        ");

        if ($stmt) {

            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {
                $message = "Medical record deleted successfully.";
            } else {
                $error = "Unable to delete record. " . $stmt->error;
            }

            $stmt->close();

        } else {
            $error = "Database error.";
        }
    }
}


/* =========================================================
   EDIT MEDICAL RECORD
========================================================= */

if (isset($_GET['edit'])) {

    $id = intval($_GET['edit']);

    $stmt = $conn->prepare("
        SELECT *
        FROM medical_records
        WHERE record_id = ?
    ");

    if ($stmt) {

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $editRecord = $result->fetch_assoc();
        }

        $stmt->close();
    }
}


/* =========================================================
   ADD / UPDATE MEDICAL RECORD
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? "";

    $patient_id = intval($_POST['patient_id'] ?? 0);
    $doctor_id = intval($_POST['doctor_id'] ?? 0);
    $appointment_id = intval($_POST['appointment_id'] ?? 0);

    $diagnosis = trim($_POST['diagnosis'] ?? "");
    $symptoms = trim($_POST['symptoms'] ?? "");
    $treatment = trim($_POST['treatment'] ?? "");
    $notes = trim($_POST['notes'] ?? "");


    /* =====================================================
       VALIDATION
    ===================================================== */

    if ($patient_id <= 0 || $doctor_id <= 0) {

        $error = "Please select a valid patient and doctor.";

    } elseif (empty($diagnosis)) {

        $error = "Diagnosis is required.";

    } else {


        /* =================================================
           ADD RECORD
        ================================================= */

        if ($action === "add") {

            $stmt = $conn->prepare("
                INSERT INTO medical_records
                (
                    patient_id,
                    doctor_id,
                    appointment_id,
                    diagnosis,
                    symptoms,
                    treatment,
                    notes,
                    record_date
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");

            if ($stmt) {

                $stmt->bind_param(
                    "iiissss",
                    $patient_id,
                    $doctor_id,
                    $appointment_id,
                    $diagnosis,
                    $symptoms,
                    $treatment,
                    $notes
                );

                if ($stmt->execute()) {

                    $message =
                        "Medical record added successfully.";

                } else {

                    $error =
                        "Unable to add medical record. " .
                        $stmt->error;
                }

                $stmt->close();

            } else {

                $error = "Database error.";
            }
        }


        /* =================================================
           UPDATE RECORD
        ================================================= */

        elseif ($action === "update") {

            $record_id =
                intval($_POST['record_id'] ?? 0);

            if ($record_id <= 0) {

                $error = "Invalid medical record ID.";

            } else {

                $stmt = $conn->prepare("
                    UPDATE medical_records
                    SET
                        patient_id = ?,
                        doctor_id = ?,
                        appointment_id = ?,
                        diagnosis = ?,
                        symptoms = ?,
                        treatment = ?,
                        notes = ?
                    WHERE record_id = ?
                ");

                if ($stmt) {

                    $stmt->bind_param(
                        "iiissssi",
                        $patient_id,
                        $doctor_id,
                        $appointment_id,
                        $diagnosis,
                        $symptoms,
                        $treatment,
                        $notes,
                        $record_id
                    );

                    if ($stmt->execute()) {

                        $message =
                            "Medical record updated successfully.";

                    } else {

                        $error =
                            "Unable to update medical record. " .
                            $stmt->error;
                    }

                    $stmt->close();

                } else {

                    $error = "Database error.";
                }
            }
        }
    }
}


/* =========================================================
   LOAD ACTIVE PATIENTS
========================================================= */

$patients = [];

$result = $conn->query("
    SELECT id, patient_id, name
    FROM patients
    WHERE status = 'Active'
    ORDER BY name ASC
");

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $patients[] = $row;
    }
}


/* =========================================================
   LOAD ACTIVE DOCTORS
========================================================= */

$doctors = [];

$result = $conn->query("
    SELECT id, doctor_id, name, specialization
    FROM doctors
    WHERE status IN ('Active', 'Available')
    ORDER BY name ASC
");

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $doctors[] = $row;
    }
}


/* =========================================================
   LOAD APPOINTMENTS
========================================================= */

$appointments = [];

$result = $conn->query("
    SELECT
        a.id,
        a.appointment_id,
        a.patient_id,
        a.doctor_id,
        a.appointment_date,
        a.appointment_time,
        p.patient_id AS patient_code,
        p.name AS patient_name,
        d.doctor_id AS doctor_code,
        d.name AS doctor_name
    FROM appointments a
    INNER JOIN patients p
        ON a.patient_id = p.id
    INNER JOIN doctors d
        ON a.doctor_id = d.id
    ORDER BY
        a.appointment_date DESC,
        a.appointment_time DESC
");

if ($result) {

    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
}


/* =========================================================
   SEARCH MEDICAL RECORDS
========================================================= */

$search = trim($_GET['search'] ?? "");

if ($search !== "") {

    $searchTerm = "%" . $search . "%";

    $stmt = $conn->prepare("
        SELECT
            m.*,
            p.patient_id AS patient_code,
            p.name AS patient_name,
            d.doctor_id AS doctor_code,
            d.name AS doctor_name,
            d.specialization,
            a.appointment_id AS appointment_code,
            a.appointment_date,
            a.appointment_time
        FROM medical_records m

        INNER JOIN patients p
            ON m.patient_id = p.id

        INNER JOIN doctors d
            ON m.doctor_id = d.id

        LEFT JOIN appointments a
            ON m.appointment_id = a.id

        WHERE
            p.patient_id LIKE ?
            OR p.name LIKE ?
            OR d.doctor_id LIKE ?
            OR d.name LIKE ?
            OR m.diagnosis LIKE ?
            OR m.treatment LIKE ?

        ORDER BY m.record_date DESC
    ");

    if ($stmt) {

        $stmt->bind_param(
            "ssssss",
            $searchTerm,
            $searchTerm,
            $searchTerm,
            $searchTerm,
            $searchTerm,
            $searchTerm
        );

        $stmt->execute();

        $medicalRecords =
            $stmt->get_result();

        $stmt->close();

    } else {

        $error = "Unable to search records.";

        $medicalRecords = false;
    }

} else {

    $medicalRecords = $conn->query("
        SELECT
            m.*,
            p.patient_id AS patient_code,
            p.name AS patient_name,
            d.doctor_id AS doctor_code,
            d.name AS doctor_name,
            d.specialization,
            a.appointment_id AS appointment_code,
            a.appointment_date,
            a.appointment_time
        FROM medical_records m

        INNER JOIN patients p
            ON m.patient_id = p.id

        INNER JOIN doctors d
            ON m.doctor_id = d.id

        LEFT JOIN appointments a
            ON m.appointment_id = a.id

        ORDER BY m.record_date DESC
    ");
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Medical Records Management</title>

<style>

/* =========================================================
   RESET
========================================================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #f4f7fb;

    color: #333;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;

    height: 100vh;

    background: #172b4d;

    color: white;

    overflow-y: auto;
}

.logo {

    text-align: center;

    padding: 25px 15px;

    border-bottom:
        1px solid rgba(255,255,255,0.15);
}

.logo h2 {

    font-size: 20px;
}

.logo p {

    margin-top: 6px;

    font-size: 12px;

    color: #b9c7da;
}

.menu {

    list-style: none;

    padding: 20px 12px;
}

.menu li {

    margin-bottom: 4px;
}

.menu a {

    display: block;

    padding: 12px 15px;

    color: #dce6f2;

    text-decoration: none;

    border-radius: 7px;

    font-size: 14px;
}

.menu a:hover,
.menu a.active {

    background: #2f80ed;

    color: white;
}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left: 250px;

    min-height: 100vh;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    height: 70px;

    background: white;

    border-bottom:
        1px solid #e2e7ee;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;
}

.topbar h1 {

    color: #172b4d;

    font-size: 22px;
}

.admin-info {

    color: #555;

    font-size: 14px;
}


/* =========================================================
   CONTENT
========================================================= */

.content {

    padding: 30px;
}


/* =========================================================
   ALERT
========================================================= */

.alert {

    padding: 13px 17px;

    border-radius: 6px;

    margin-bottom: 20px;

    font-size: 14px;
}

.success {

    background: #e9f8ef;

    border: 1px solid #b9e5c9;

    color: #19713f;
}

.danger {

    background: #fdecec;

    border: 1px solid #f0bbbb;

    color: #b42318;
}


/* =========================================================
   CARD
========================================================= */

.card {

    background: white;

    border-radius: 10px;

    padding: 25px;

    margin-bottom: 25px;

    box-shadow:
        0 2px 8px rgba(0,0,0,0.06);
}

.card-title {

    color: #172b4d;

    font-size: 19px;

    font-weight: bold;

    margin-bottom: 20px;
}


/* =========================================================
   FORM
========================================================= */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 18px;
}

.form-group {

    display: flex;

    flex-direction: column;
}

.form-group.full {

    grid-column: 1 / -1;
}

.form-group label {

    font-size: 13px;

    font-weight: bold;

    color: #444;

    margin-bottom: 7px;
}

.form-group input,
.form-group select,
.form-group textarea {

    width: 100%;

    padding: 11px 12px;

    border: 1px solid #ccd4df;

    border-radius: 6px;

    font-size: 14px;

    outline: none;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #2f80ed;

    box-shadow:
        0 0 0 2px rgba(47,128,237,0.1);
}

.form-group textarea {

    min-height: 100px;

    resize: vertical;
}


/* =========================================================
   BUTTONS
========================================================= */

.button-area {

    display: flex;

    gap: 10px;

    margin-top: 20px;
}

.btn {

    display: inline-block;

    padding: 10px 16px;

    border: none;

    border-radius: 6px;

    text-decoration: none;

    cursor: pointer;

    font-size: 13px;
}

.btn-primary {

    background: #2f80ed;

    color: white;
}

.btn-primary:hover {

    background: #1769d3;
}

.btn-secondary {

    background: #6c757d;

    color: white;
}

.btn-warning {

    background: #f39c12;

    color: white;
}

.btn-danger {

    background: #e74c3c;

    color: white;
}

.btn-small {

    padding: 7px 10px;

    font-size: 12px;
}


/* =========================================================
   SEARCH
========================================================= */

.search-area {

    display: flex;

    gap: 10px;

    margin-bottom: 20px;
}

.search-area input {

    flex: 1;

    padding: 11px 12px;

    border: 1px solid #ccd4df;

    border-radius: 6px;

    font-size: 14px;
}


/* =========================================================
   TABLE
========================================================= */

.table-container {

    width: 100%;

    overflow-x: auto;
}

table {

    width: 100%;

    min-width: 1100px;

    border-collapse: collapse;
}

thead {

    background: #172b4d;

    color: white;
}

th,
td {

    padding: 12px;

    text-align: left;

    border-bottom:
        1px solid #e5e9ef;

    font-size: 13px;

    vertical-align: top;
}

tbody tr:hover {

    background: #f8fafc;
}

small {

    color: #777;
}


/* =========================================================
   DIAGNOSIS
========================================================= */

.diagnosis {

    max-width: 220px;

    white-space: normal;

    line-height: 1.5;
}


/* =========================================================
   EMPTY
========================================================= */

.empty {

    text-align: center;

    padding: 35px;

    color: #777;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .sidebar {

        width: 210px;
    }

    .main {

        margin-left: 210px;
    }

    .form-grid {

        grid-template-columns: 1fr;
    }

    .form-group.full {

        grid-column: auto;
    }
}

@media (max-width: 650px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .main {

        margin-left: 0;
    }

    .topbar {

        padding: 0 15px;
    }

    .content {

        padding: 15px;
    }

    .search-area {

        flex-direction: column;
    }
}

</style>

</head>

<body>


<!-- =====================================================
     SIDEBAR
===================================================== -->

<div class="sidebar">

    <div class="logo">

        <h2>Hospital Management</h2>

        <p>Administration Panel</p>

    </div>


    <ul class="menu">

        <li>
            <a href="dashboard.php">
                Dashboard
            </a>
        </li>

        <li>
            <a href="patients.php">
                Patients
            </a>
        </li>

        <li>
            <a href="doctors.php">
                Doctors
            </a>
        </li>

        <li>
            <a href="appointments.php">
                Appointments
            </a>
        </li>

        <li>
            <a href="medical_records.php"
               class="active">
                Medical Records
            </a>
        </li>

        <li>
            <a href="prescriptions.php">
                Prescriptions
            </a>
        </li>

        <li>
            <a href="billing.php">
                Billing
            </a>
        </li>

        <li>
            <a href="reports.php">
                Reports
            </a>
        </li>

        <li>
            <a href="users.php">
                Users
            </a>
        </li>

        <li>
            <a href="settings.php">
                Settings
            </a>
        </li>

        <li>
            <a href="../auth/logout.php">
                Logout
            </a>
        </li>

    </ul>

</div>


<!-- =====================================================
     MAIN
===================================================== -->

<div class="main">


    <!-- TOPBAR -->

    <div class="topbar">

        <h1>Medical Records</h1>

        <div class="admin-info">

            Welcome,
            <strong>
                <?php
                echo htmlspecialchars(
                    $_SESSION['full_name']
                );
                ?>
            </strong>

        </div>

    </div>


    <!-- CONTENT -->

    <div class="content">


        <!-- ALERTS -->

        <?php if ($message): ?>

            <div class="alert success">

                <?php
                echo htmlspecialchars($message);
                ?>

            </div>

        <?php endif; ?>


        <?php if ($error): ?>

            <div class="alert danger">

                <?php
                echo htmlspecialchars($error);
                ?>

            </div>

        <?php endif; ?>


        <!-- =================================================
             ADD / EDIT FORM
        ================================================= -->

        <div class="card">

            <div class="card-title">

                <?php
                echo $editRecord
                    ? "Edit Medical Record"
                    : "Create Medical Record";
                ?>

            </div>


            <form method="POST">

                <?php if ($editRecord): ?>

                    <input
                        type="hidden"
                        name="action"
                        value="update"
                    >

                    <input
                        type="hidden"
                        name="record_id"
                        value="<?php
                        echo $editRecord['record_id'];
                        ?>"
                    >

                <?php else: ?>

                    <input
                        type="hidden"
                        name="action"
                        value="add"
                    >

                <?php endif; ?>


                <div class="form-grid">


                    <!-- PATIENT -->

                    <div class="form-group">

                        <label>
                            Patient *
                        </label>

                        <select
                            name="patient_id"
                            required
                        >

                            <option value="">
                                -- Select Patient --
                            </option>

                            <?php foreach (
                                $patients as $patient
                            ): ?>

                                <option
                                    value="<?php
                                    echo $patient['id'];
                                    ?>"
                                    <?php

                                    if (
                                        $editRecord &&
                                        $editRecord[
                                            'patient_id'
                                        ]
                                        ==
                                        $patient['id']
                                    ) {
                                        echo "selected";
                                    }

                                    ?>
                                >

                                    <?php
                                    echo htmlspecialchars(
                                        $patient['patient_id']
                                    );
                                    ?>

                                    -
                                    <?php
                                    echo htmlspecialchars(
                                        $patient['name']
                                    );
                                    ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- DOCTOR -->

                    <div class="form-group">

                        <label>
                            Doctor *
                        </label>

                        <select
                            name="doctor_id"
                            required
                        >

                            <option value="">
                                -- Select Doctor --
                            </option>

                            <?php foreach (
                                $doctors as $doctor
                            ): ?>

                                <option
                                    value="<?php
                                    echo $doctor['id'];
                                    ?>"
                                    <?php

                                    if (
                                        $editRecord &&
                                        $editRecord[
                                            'doctor_id'
                                        ]
                                        ==
                                        $doctor['id']
                                    ) {
                                        echo "selected";
                                    }

                                    ?>
                                >

                                    DOC-<?php
                                    echo htmlspecialchars(
                                        $doctor['doctor_id']
                                    );
                                    ?>

                                    -
                                    Dr.
                                    <?php
                                    echo htmlspecialchars(
                                        $doctor['name']
                                    );
                                    ?>

                                    -
                                    <?php
                                    echo htmlspecialchars(
                                        $doctor['specialization']
                                    );
                                    ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- APPOINTMENT -->

                    <div class="form-group full">

                        <label>
                            Related Appointment
                        </label>

                        <select
                            name="appointment_id"
                        >

                            <option value="0">
                                -- No Appointment / Select Appointment --
                            </option>

                            <?php foreach (
                                $appointments as $appointment
                            ): ?>

                                <option
                                    value="<?php
                                    echo $appointment['id'];
                                    ?>"
                                    <?php

                                    if (
                                        $editRecord &&
                                        $editRecord[
                                            'appointment_id'
                                        ]
                                        ==
                                        $appointment['id']
                                    ) {
                                        echo "selected";
                                    }

                                    ?>
                                >

                                    <?php
                                    echo htmlspecialchars(
                                        $appointment[
                                            'appointment_id'
                                        ]
                                    );
                                    ?>

                                    |
                                    <?php
                                    echo htmlspecialchars(
                                        $appointment[
                                            'patient_name'
                                        ]
                                    );
                                    ?>

                                    |
                                    Dr.
                                    <?php
                                    echo htmlspecialchars(
                                        $appointment[
                                            'doctor_name'
                                        ]
                                    );
                                    ?>

                                    |
                                    <?php
                                    echo date(
                                        'd M Y',
                                        strtotime(
                                            $appointment[
                                                'appointment_date'
                                            ]
                                        )
                                    );
                                    ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- DIAGNOSIS -->

                    <div class="form-group full">

                        <label>
                            Diagnosis *
                        </label>

                        <textarea
                            name="diagnosis"
                            required
                            placeholder="Enter patient's diagnosis..."
                        ><?php

                        echo $editRecord
                            ? htmlspecialchars(
                                $editRecord['diagnosis']
                            )
                            : '';

                        ?></textarea>

                    </div>


                    <!-- SYMPTOMS -->

                    <div class="form-group">

                        <label>
                            Symptoms
                        </label>

                        <textarea
                            name="symptoms"
                            placeholder="Enter patient's symptoms..."
                        ><?php

                        echo $editRecord
                            ? htmlspecialchars(
                                $editRecord['symptoms']
                            )
                            : '';

                        ?></textarea>

                    </div>


                    <!-- TREATMENT -->

                    <div class="form-group">

                        <label>
                            Treatment
                        </label>

                        <textarea
                            name="treatment"
                            placeholder="Enter treatment details..."
                        ><?php

                        echo $editRecord
                            ? htmlspecialchars(
                                $editRecord['treatment']
                            )
                            : '';

                        ?></textarea>

                    </div>


                    <!-- NOTES -->

                    <div class="form-group full">

                        <label>
                            Doctor's Notes
                        </label>

                        <textarea
                            name="notes"
                            placeholder="Additional medical notes..."
                        ><?php

                        echo $editRecord
                            ? htmlspecialchars(
                                $editRecord['notes']
                            )
                            : '';

                        ?></textarea>

                    </div>

                </div>


                <!-- BUTTONS -->

                <div class="button-area">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >

                        <?php
                        echo $editRecord
                            ? "Update Medical Record"
                            : "Save Medical Record";
                        ?>

                    </button>


                    <?php if ($editRecord): ?>

                        <a
                            href="medical_records.php"
                            class="btn btn-secondary"
                        >
                            Cancel
                        </a>

                    <?php endif; ?>

                </div>

            </form>

        </div>


        <!-- =================================================
             MEDICAL RECORD LIST
        ================================================= -->

        <div class="card">

            <div class="card-title">

                Medical Records List

            </div>


            <!-- SEARCH -->

            <form
                method="GET"
                class="search-area"
            >

                <input
                    type="text"
                    name="search"
                    placeholder="Search patient, doctor, diagnosis, treatment..."
                    value="<?php
                    echo htmlspecialchars($search);
                    ?>"
                >

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Search
                </button>


                <?php if ($search !== ""): ?>

                    <a
                        href="medical_records.php"
                        class="btn btn-secondary"
                    >
                        Clear
                    </a>

                <?php endif; ?>

            </form>


            <!-- TABLE -->

            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>
                                Record ID
                            </th>

                            <th>
                                Patient
                            </th>

                            <th>
                                Doctor
                            </th>

                            <th>
                                Appointment
                            </th>

                            <th>
                                Diagnosis
                            </th>

                            <th>
                                Symptoms
                            </th>

                            <th>
                                Treatment
                            </th>

                            <th>
                                Record Date
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php if (
                        $medicalRecords &&
                        $medicalRecords->num_rows > 0
                    ): ?>


                        <?php while (
                            $record =
                            $medicalRecords->fetch_assoc()
                        ): ?>

                            <tr>


                                <!-- RECORD ID -->

                                <td>

                                    <strong>

                                        MR-
                                        <?php
                                        echo str_pad(
                                            $record[
                                                'record_id'
                                            ],
                                            5,
                                            '0',
                                            STR_PAD_LEFT
                                        );
                                        ?>

                                    </strong>

                                </td>


                                <!-- PATIENT -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $record[
                                            'patient_name'
                                        ]
                                    );
                                    ?>

                                    <br>

                                    <small>

                                        <?php
                                        echo htmlspecialchars(
                                            $record[
                                                'patient_code'
                                            ]
                                        );
                                        ?>

                                    </small>

                                </td>


                                <!-- DOCTOR -->

                                <td>

                                    Dr.
                                    <?php
                                    echo htmlspecialchars(
                                        $record[
                                            'doctor_name'
                                        ]
                                    );
                                    ?>

                                    <br>

                                    <small>

                                        <?php
                                        echo htmlspecialchars(
                                            $record[
                                                'specialization'
                                            ]
                                        );
                                        ?>

                                    </small>

                                </td>


                                <!-- APPOINTMENT -->

                                <td>

                                    <?php

                                    if (
                                        !empty(
                                            $record[
                                                'appointment_code'
                                            ]
                                        )
                                    ) {

                                        echo htmlspecialchars(
                                            $record[
                                                'appointment_code'
                                            ]
                                        );

                                    } else {

                                        echo "N/A";
                                    }

                                    ?>

                                </td>


                                <!-- DIAGNOSIS -->

                                <td class="diagnosis">

                                    <?php
                                    echo nl2br(
                                        htmlspecialchars(
                                            $record[
                                                'diagnosis'
                                            ]
                                        )
                                    );
                                    ?>

                                </td>


                                <!-- SYMPTOMS -->

                                <td class="diagnosis">

                                    <?php
                                    echo nl2br(
                                        htmlspecialchars(
                                            $record[
                                                'symptoms'
                                            ]
                                        )
                                    );
                                    ?>

                                </td>


                                <!-- TREATMENT -->

                                <td class="diagnosis">

                                    <?php
                                    echo nl2br(
                                        htmlspecialchars(
                                            $record[
                                                'treatment'
                                            ]
                                        )
                                    );
                                    ?>

                                </td>


                                <!-- DATE -->

                                <td>

                                    <?php

                                    echo date(
                                        'd M Y',
                                        strtotime(
                                            $record[
                                                'record_date'
                                            ]
                                        )
                                    );

                                    ?>

                                </td>


                                <!-- ACTIONS -->

                                <td>

                                    <a
                                        href="medical_records.php?edit=<?php
                                        echo $record[
                                            'record_id'
                                        ];
                                        ?>"
                                        class="btn btn-warning btn-small"
                                    >
                                        Edit
                                    </a>


                                    <a
                                        href="medical_records.php?delete=<?php
                                        echo $record[
                                            'record_id'
                                        ];
                                        ?>"
                                        class="btn btn-danger btn-small"
                                        onclick="return confirm(
                                            'Are you sure you want to delete this medical record?'
                                        );"
                                    >
                                        Delete
                                    </a>

                                </td>

                            </tr>

                        <?php endwhile; ?>


                    <?php else: ?>

                        <tr>

                            <td
                                colspan="9"
                                class="empty"
                            >

                                No medical records found.

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

</body>

</html>