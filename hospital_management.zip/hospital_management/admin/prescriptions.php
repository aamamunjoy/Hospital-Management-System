<?php
require __DIR__ . '/_common.php';

// The original archive contains two schemas. Detect their real primary keys
// instead of assuming every table has a column named "id".
function rx_columns($conn, $table) {
    if (!in_array($table, ['prescriptions', 'medical_records'], true)) {
        throw new RuntimeException('Unsupported table name.');
    }
    $result = $conn->query("SHOW COLUMNS FROM `$table`");
    if ($result === false) throw new RuntimeException('Cannot read table columns: ' . $conn->error);
    $columns = [];
    while ($row = $result->fetch_assoc()) $columns[$row['Field']] = $row;
    $result->free();
    return $columns;
}

function rx_primary_key($columns, $alternative) {
    foreach (['id', $alternative] as $column) {
        if (isset($columns[$column]) && $columns[$column]['Key'] === 'PRI') return $column;
    }
    throw new RuntimeException('The table has no supported primary key.');
}

// Check prepare/bind/execute explicitly, including installations that return
// false rather than throwing mysqli_sql_exception on a failed SQL statement.
function rx_statement($conn, $sql, $types = '', $values = []) {
    $stmt = $conn->prepare($sql);
    if ($stmt === false) throw new RuntimeException('Prepare failed: ' . $conn->error);
    try {
        if ($types !== '' && !$stmt->bind_param($types, ...$values)) {
            throw new RuntimeException('Parameter binding failed: ' . $stmt->error);
        }
        if (!$stmt->execute()) throw new RuntimeException('Statement failed: ' . $stmt->error);
        return $stmt;
    } catch (Throwable $error) {
        $stmt->close();
        throw $error;
    }
}

function rx_rows($conn, $sql, $types = '', $values = []) {
    $stmt = rx_statement($conn, $sql, $types, $values);
    try {
        $result = $stmt->get_result();
        if ($result === false) throw new RuntimeException('Result could not be read: ' . $stmt->error);
        $rows = [];
        while ($row = $result->fetch_assoc()) $rows[] = $row;
        $result->free();
        return $rows;
    } finally {
        $stmt->close();
    }
}

function rx_input($source, $name, $default = '') {
    return isset($source[$name]) && is_string($source[$name]) ? trim($source[$name]) : $default;
}

function rx_id($value, $label) {
    $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    if ($id === false) throw new InvalidArgumentException('Select a valid ' . $label . '.');
    return (int) $id;
}

$errors = [];
$form = [
    'id' => '', 'patient_id' => '', 'doctor_id' => '', 'medical_record_id' => '',
    'medicine_name' => '', 'dosage' => '', 'frequency' => '', 'duration' => '',
    'instructions' => '', 'prescription_date' => date('Y-m-d')
];
$isEditing = false;
$q = rx_input($_GET, 'q');

try {
    $prescriptionColumns = rx_columns($conn, 'prescriptions');
    $recordColumns = rx_columns($conn, 'medical_records');
    $prescriptionKey = rx_primary_key($prescriptionColumns, 'prescription_id');
    $recordKey = rx_primary_key($recordColumns, 'record_id');
    $fields = ['patient_id', 'doctor_id', 'medical_record_id', 'medicine_name',
        'dosage', 'frequency', 'duration', 'instructions', 'prescription_date'];
    foreach (array_merge(['prescription_id'], $fields) as $column) {
        if (!isset($prescriptionColumns[$column])) throw new RuntimeException('Missing prescription column: ' . $column);
    }
    if (!isset($recordColumns['record_id'], $recordColumns['patient_id'])) {
        throw new RuntimeException('Medical record columns are missing.');
    }
    if (stripos($prescriptionColumns[$prescriptionKey]['Extra'], 'auto_increment') === false) {
        throw new RuntimeException('The prescription primary key must be auto-incrementing.');
    }

    $patients = rx_rows($conn, 'SELECT id, patient_id, name FROM patients ORDER BY name');
    $doctors = rx_rows($conn, 'SELECT id, doctor_id, name FROM doctors ORDER BY name');
    $records = rx_rows($conn, "SELECT `$recordKey` AS id, record_id, patient_id FROM medical_records ORDER BY `$recordKey` DESC");
} catch (Throwable $error) {
    error_log('[Prescriptions: load] ' . $error->getMessage());
    http_response_code(500);
    page_top('Prescriptions', 'prescriptions');
    echo '<div class="alert error" role="alert">The prescription tables could not be loaded. Check the database connection and the PHP error log for the database details.</div>';
    page_bottom();
    exit;
}

// Every generated column identifier below is selected from the fixed names above.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    foreach (array_keys($form) as $field) $form[$field] = rx_input($_POST, $field);
    $isEditing = $form['id'] !== '' && $form['id'] !== '0';
    try {
        $action = rx_input($_POST, 'action', 'save');
        if (!in_array($action, ['save', 'delete'], true)) throw new InvalidArgumentException('Unknown prescription action.');
        $id = $isEditing ? rx_id($form['id'], 'prescription') : 0;
        $existing = null;
        if ($id > 0) {
            $found = rx_rows($conn, "SELECT * FROM prescriptions WHERE `$prescriptionKey` = ? LIMIT 1", 'i', [$id]);
            if (!$found) throw new InvalidArgumentException('That prescription no longer exists.');
            $existing = $found[0];
        }
        if ($action === 'delete') {
            if ($id === 0) throw new InvalidArgumentException('Select a prescription to delete.');
            rx_statement($conn, "DELETE FROM prescriptions WHERE `$prescriptionKey` = ?", 'i', [$id])->close();
            flash('success', 'Prescription deleted.');
        } else {
            $patientId = rx_id($form['patient_id'], 'patient');
            $doctorId = rx_id($form['doctor_id'], 'doctor');
            $recordId = $form['medical_record_id'] !== '' ? rx_id($form['medical_record_id'], 'medical record') : null;
            if (!rx_rows($conn, 'SELECT id FROM patients WHERE id = ?', 'i', [$patientId])) {
                throw new InvalidArgumentException('The selected patient no longer exists.');
            }
            if (!rx_rows($conn, 'SELECT id FROM doctors WHERE id = ?', 'i', [$doctorId])) {
                throw new InvalidArgumentException('The selected doctor no longer exists.');
            }
            if ($recordId !== null && !rx_rows($conn, "SELECT `$recordKey` FROM medical_records WHERE `$recordKey` = ? AND patient_id = ?", 'ii', [$recordId, $patientId])) {
                throw new InvalidArgumentException('Select a medical record belonging to this patient, or choose No linked record.');
            }
            if ($form['medicine_name'] === '') throw new InvalidArgumentException('Enter the medicine name.');
            foreach (['medicine_name' => 150, 'dosage' => 100, 'frequency' => 100, 'duration' => 100] as $field => $limit) {
                $length = function_exists('mb_strlen') ? mb_strlen($form[$field], 'UTF-8') : strlen($form[$field]);
                if ($length > $limit) throw new InvalidArgumentException(ucfirst(str_replace('_', ' ', $field)) . ' must be at most ' . $limit . ' characters.');
            }
            $date = DateTime::createFromFormat('!Y-m-d', $form['prescription_date']);
            if (!$date || $date->format('Y-m-d') !== $form['prescription_date']) {
                throw new InvalidArgumentException('Enter a valid prescription date.');
            }
            $dateValue = $form['prescription_date'];
            // Preserve an existing DATETIME's time when only other fields change.
            if ($existing && substr($existing['prescription_date'], 0, 10) === $dateValue) {
                $dateValue = $existing['prescription_date'];
            }
            $values = [$patientId, $doctorId, $recordId, $form['medicine_name'],
                $form['dosage'], $form['frequency'], $form['duration'], $form['instructions'], $dateValue];
            $types = 'iii' . str_repeat('s', 6);
            if ($id > 0) {
                $assignments = [];
                foreach ($fields as $field) $assignments[] = "`$field` = ?";
                $values[] = $id;
                rx_statement($conn, 'UPDATE prescriptions SET ' . implode(', ', $assignments) . " WHERE `$prescriptionKey` = ?", $types . 'i', $values)->close();
                flash('success', 'Prescription updated.');
            } else {
                $insertFields = $fields;
                // database.sql has a separate string code; the import schema
                // instead auto-generates the numeric prescription_id itself.
                if ($prescriptionKey !== 'prescription_id') {
                    array_unshift($insertFields, 'prescription_id');
                    array_unshift($values, 'RX-' . date('ymd') . '-' . strtoupper(bin2hex(random_bytes(4))));
                    $types = 's' . $types;
                }
                $placeholders = implode(', ', array_fill(0, count($values), '?'));
                $sql = 'INSERT INTO prescriptions (`' . implode('`, `', $insertFields) . "`) VALUES ($placeholders)";
                rx_statement($conn, $sql, $types, $values)->close();
                flash('success', 'Prescription created.');
            }
        }
        header('Location: prescriptions.php');
        exit;
    } catch (InvalidArgumentException $error) {
        $errors[] = $error->getMessage();
    } catch (Throwable $error) {
        error_log('[Prescriptions: save] ' . $error->getMessage());
        $errors[] = 'The change could not be saved. Your entries are still shown below. Check the PHP error log for details.';
    }
} elseif (isset($_GET['edit'])) {
    try {
        $id = rx_id(rx_input($_GET, 'edit'), 'prescription');
        $found = rx_rows($conn, "SELECT p.*, p.`$prescriptionKey` AS row_id FROM prescriptions p WHERE p.`$prescriptionKey` = ? LIMIT 1", 'i', [$id]);
        if (!$found) throw new InvalidArgumentException('That prescription no longer exists.');
        $row = $found[0];
        foreach ($fields as $field) $form[$field] = $row[$field] ?? '';
        $form['id'] = $row['row_id'];
        $form['prescription_date'] = substr((string) $row['prescription_date'], 0, 10);
        $isEditing = true;
    } catch (InvalidArgumentException $error) {
        $errors[] = $error->getMessage();
    } catch (Throwable $error) {
        error_log('[Prescriptions: edit] ' . $error->getMessage());
        $errors[] = 'The prescription could not be opened. Check the PHP error log for details.';
    }
}

$rows = [];
$listLoaded = true;
try {
    $like = '%' . $q . '%';
    $sql = "SELECT p.*, p.`$prescriptionKey` AS row_id, pa.name AS patient_name, d.name AS doctor_name
        FROM prescriptions p
        JOIN patients pa ON pa.id = p.patient_id
        JOIN doctors d ON d.id = p.doctor_id
        WHERE CAST(p.prescription_id AS CHAR) LIKE ? OR p.medicine_name LIKE ? OR pa.name LIKE ?
        ORDER BY p.prescription_date DESC, p.`$prescriptionKey` DESC";
    $rows = rx_rows($conn, $sql, 'sss', [$like, $like, $like]);
} catch (Throwable $error) {
    error_log('[Prescriptions: list] ' . $error->getMessage());
    $errors[] = 'The prescription list could not be loaded. Check the PHP error log for details.';
    $listLoaded = false;
}
$patientNames = [];
foreach ($patients as $patient) $patientNames[$patient['id']] = $patient['name'];
page_top('Prescriptions', 'prescriptions');
?>
<?php foreach ($errors as $message): ?>
    <div class="alert error" role="alert"><?= e($message) ?></div>
<?php endforeach; ?>
<section class="card">
    <h2><?= $isEditing ? 'Edit prescription' : 'New prescription' ?></h2>
    <form method="post" action="prescriptions.php" class="grid-form">
        <?= csrf() ?>
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= e($form['id']) ?>">
        <label>Patient
            <select name="patient_id" required>
                <option value="">Select patient</option>
                <?php foreach ($patients as $patient): ?>
                    <option value="<?= e($patient['id']) ?>" <?= (string) $form['patient_id'] === (string) $patient['id'] ? 'selected' : '' ?>><?= e($patient['patient_id'] . ' — ' . $patient['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Doctor
            <select name="doctor_id" required>
                <option value="">Select doctor</option>
                <?php foreach ($doctors as $doctor): ?>
                    <option value="<?= e($doctor['id']) ?>" <?= (string) $form['doctor_id'] === (string) $doctor['id'] ? 'selected' : '' ?>><?= e($doctor['doctor_id'] . ' — ' . $doctor['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Medical record (optional)
            <select name="medical_record_id">
                <option value="">No linked record</option>
                <?php foreach ($records as $record): ?>
                    <option value="<?= e($record['id']) ?>" <?= (string) $form['medical_record_id'] === (string) $record['id'] ? 'selected' : '' ?>><?= e($record['record_id'] . ' — ' . ($patientNames[$record['patient_id']] ?? 'Patient')) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Medicine<input name="medicine_name" required maxlength="150" value="<?= e($form['medicine_name']) ?>"></label>
        <label>Dosage<input name="dosage" maxlength="100" value="<?= e($form['dosage']) ?>"></label>
        <label>Frequency<input name="frequency" maxlength="100" value="<?= e($form['frequency']) ?>"></label>
        <label>Duration<input name="duration" maxlength="100" value="<?= e($form['duration']) ?>"></label>
        <label>Date<input type="date" name="prescription_date" required value="<?= e($form['prescription_date']) ?>"></label>
        <label class="wide">Instructions<textarea name="instructions"><?= e($form['instructions']) ?></textarea></label>
        <div class="actions wide">
            <button type="submit" class="btn">Save prescription</button>
            <?php if ($isEditing): ?><a class="btn secondary" href="prescriptions.php">Cancel</a><?php endif; ?>
        </div>
    </form>
</section>
<section class="toolbar">
    <h2>Prescription list</h2>
    <form method="get" action="prescriptions.php" role="search">
        <label for="prescription-search">Search prescriptions</label>
        <input class="search" id="prescription-search" name="q" value="<?= e($q) ?>" placeholder="ID, patient, or medicine">
        <button class="btn secondary" type="submit">Search</button>
        <?php if ($q !== ''): ?><a class="btn secondary" href="prescriptions.php">Clear</a><?php endif; ?>
    </form>
</section>
<section class="card">
    <table>
        <thead><tr><th scope="col">ID / Date</th><th scope="col">Patient</th><th scope="col">Doctor</th><th scope="col">Medicine</th><th scope="col">Directions</th><th scope="col">Actions</th></tr></thead>
        <tbody>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><b><?= e($row['prescription_id']) ?></b><br><?= e(substr((string) $row['prescription_date'], 0, 10)) ?></td>
                <td><?= e($row['patient_name']) ?></td>
                <td><?= e($row['doctor_name']) ?></td>
                <td><b><?= e($row['medicine_name']) ?></b><br><?= e($row['dosage']) ?></td>
                <td><?= e(implode(' · ', array_filter([$row['frequency'], $row['duration']], function ($value) { return $value !== null && $value !== ''; }))) ?></td>
                <td>
                    <a class="btn secondary" href="prescriptions.php?edit=<?= (int) $row['row_id'] ?>">Edit</a>
                    <form method="post" action="prescriptions.php" style="display:inline" onsubmit="return confirm('Delete this prescription?')">
                        <?= csrf() ?>
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?= (int) $row['row_id'] ?>">
                        <button type="submit" class="btn danger">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$rows && $listLoaded): ?>
            <tr><td colspan="6" class="empty"><?= $q !== '' ? 'No prescriptions match your search.' : 'No prescriptions have been added yet.' ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</section>
<?php page_bottom(); ?>
