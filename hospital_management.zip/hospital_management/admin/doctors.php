<?php

session_start();

/* =========================================================
   ADMIN ACCESS PROTECTION
========================================================= */

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'admin'
) {
    header("Location: ../auth/login.php");
    exit();
}


/* =========================================================
   DATABASE CONNECTION
========================================================= */

require_once "../config/database.php";

function doctor_escape($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function doctor_fee_label($value) {
    return $value === null || $value === '' ? 'Not provided' : '৳' . number_format((float) $value, 2);
}
$doctorStatusValues = ['Active', 'Inactive'];
$doctorFeeNullable = false;
try {
    $doctorColumns = $conn->query('SHOW COLUMNS FROM `doctors`');
    if ($doctorColumns) {
        while ($doctorColumn = $doctorColumns->fetch_assoc()) {
            if ($doctorColumn['Field'] === 'status' && strpos($doctorColumn['Type'], "'Available'") !== false) {
                $doctorStatusValues = ['Available', 'Unavailable'];
            }
            if ($doctorColumn['Field'] === 'consultation_fee') $doctorFeeNullable = $doctorColumn['Null'] === 'YES';
        }
        $doctorColumns->free();
    }
} catch (Throwable $schemaError) { error_log('Doctor schema: ' . $schemaError->getMessage()); }



$message = "";
$error = "";


/* =========================================================
   DELETE DOCTOR
========================================================= */

if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);

    if ($id > 0) {

        $stmt = $conn->prepare(
            "DELETE FROM doctors WHERE id = ?"
        );

        if ($stmt) {

            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {

                $message = "Doctor deleted successfully.";

            } else {

                $error =
                    "Unable to delete doctor. " .
                    $stmt->error;
            }

            $stmt->close();

        } else {

            $error =
                "Database error: " .
                $conn->error;
        }
    }
}


/* =========================================================
   ADD DOCTOR
========================================================= */

if (
    $_SERVER["REQUEST_METHOD"] === "POST" &&
    isset($_POST['add_doctor'])
) {

    $name =
        trim($_POST['name'] ?? '');

    $specialization =
        trim($_POST['specialization'] ?? '');

    $qualification =
        trim($_POST['qualification'] ?? '');

    $phone =
        trim($_POST['phone'] ?? '');
    if ($phone === '') $phone = null;

    $email =
        trim($_POST['email'] ?? '');
    if ($email === '') $email = null;

    $address =
        trim($_POST['address'] ?? '');
    if ($address === '') $address = null;

    $gender =
        $_POST['gender'] ?? '';
    if ($gender === '') $gender = null;

    $date_of_birth =
        $_POST['date_of_birth'] ?? '';
    if ($date_of_birth === '') $date_of_birth = null;

    $joining_date =
        $_POST['joining_date'] ?? '';
    if ($joining_date === '') $joining_date = null;

    $feeText = is_string($_POST['consultation_fee'] ?? null) ? trim($_POST['consultation_fee']) : '';
    $consultation_fee = $feeText === '' ? ($doctorFeeNullable ? null : 0.0) : filter_var($feeText, FILTER_VALIDATE_FLOAT);

    $status =
        $_POST['status'] ?? $doctorStatusValues[0];


    /* -----------------------------------------------------
       VALIDATION
    ----------------------------------------------------- */

    if ($name === '') {

        $error =
            "Doctor name is required.";

    } elseif ($specialization === '') {

        $error =
            "Specialization is required.";

    } elseif ($consultation_fee === false || ($consultation_fee !== null && ($consultation_fee < 0 || $consultation_fee > 99999999.99))) {

        $error = 'Enter a valid consultation fee, or leave it blank if unknown.';

    } elseif (!in_array($status, $doctorStatusValues, true)) {

        $error =
            "Invalid doctor status.";

    } else {


        /* -------------------------------------------------
           GENERATE DOCTOR ID
        ------------------------------------------------- */

        $result = $conn->query(
            "SELECT id
             FROM doctors
             ORDER BY id DESC
             LIMIT 1"
        );


        if (
            $result &&
            $result->num_rows > 0
        ) {

            $lastDoctor =
                $result->fetch_assoc();

            $nextNumber =
                intval($lastDoctor['id']) + 1;

        } else {

            $nextNumber = 1;
        }


        $doctor_id =
            "DOC-" .
            str_pad(
                $nextNumber,
                5,
                "0",
                STR_PAD_LEFT
            );


        /* -------------------------------------------------
           INSERT DOCTOR
        ------------------------------------------------- */

        $sql = "INSERT INTO doctors
        (
            doctor_id,
            name,
            specialization,
            qualification,
            phone,
            email,
            address,
            gender,
            date_of_birth,
            joining_date,
            consultation_fee,
            status
        )
        VALUES
        (
            ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?
        )";


        $stmt =
            $conn->prepare($sql);


        if ($stmt) {

            /*
             * 12 variables
             *
             * s = string
             * d = decimal/double
             */

            $stmt->bind_param(
                "ssssssssssds",
                $doctor_id,
                $name,
                $specialization,
                $qualification,
                $phone,
                $email,
                $address,
                $gender,
                $date_of_birth,
                $joining_date,
                $consultation_fee,
                $status
            );


            if ($stmt->execute()) {

                $message =
                    "Doctor added successfully. " .
                    "Doctor ID: " .
                    $doctor_id;

            } else {

                $error =
                    "Unable to add doctor. " .
                    $stmt->error;
            }


            $stmt->close();

        } else {

            $error =
                "Database error: " .
                $conn->error;
        }
    }
}


/* =========================================================
   UPDATE DOCTOR
========================================================= */

if (
    $_SERVER["REQUEST_METHOD"] === "POST" &&
    isset($_POST['update_doctor'])
) {

    $id =
        intval($_POST['id'] ?? 0);


    $name =
        trim($_POST['name'] ?? '');

    $specialization =
        trim($_POST['specialization'] ?? '');

    $qualification =
        trim($_POST['qualification'] ?? '');

    $phone =
        trim($_POST['phone'] ?? '');
    if ($phone === '') $phone = null;

    $email =
        trim($_POST['email'] ?? '');
    if ($email === '') $email = null;

    $address =
        trim($_POST['address'] ?? '');
    if ($address === '') $address = null;

    $gender =
        $_POST['gender'] ?? '';
    if ($gender === '') $gender = null;

    $date_of_birth =
        $_POST['date_of_birth'] ?? '';
    if ($date_of_birth === '') $date_of_birth = null;

    $joining_date =
        $_POST['joining_date'] ?? '';
    if ($joining_date === '') $joining_date = null;

    $feeText = is_string($_POST['consultation_fee'] ?? null) ? trim($_POST['consultation_fee']) : '';
    $consultation_fee = $feeText === '' ? ($doctorFeeNullable ? null : 0.0) : filter_var($feeText, FILTER_VALIDATE_FLOAT);

    $status =
        $_POST['status'] ?? $doctorStatusValues[0];


    /* -----------------------------------------------------
       VALIDATION
    ----------------------------------------------------- */

    if ($id <= 0) {

        $error =
            "Invalid doctor ID.";

    } elseif ($name === '') {

        $error =
            "Doctor name is required.";

    } elseif ($specialization === '') {

        $error =
            "Specialization is required.";

    } elseif ($consultation_fee === false || ($consultation_fee !== null && ($consultation_fee < 0 || $consultation_fee > 99999999.99))) {

        $error = 'Enter a valid consultation fee, or leave it blank if unknown.';

    } elseif (!in_array($status, $doctorStatusValues, true)) {

        $error =
            "Invalid doctor status.";

    } else {


        /* -------------------------------------------------
           UPDATE QUERY
        ------------------------------------------------- */

        $sql = "UPDATE doctors
                SET
                    name = ?,
                    specialization = ?,
                    qualification = ?,
                    phone = ?,
                    email = ?,
                    address = ?,
                    gender = ?,
                    date_of_birth = ?,
                    joining_date = ?,
                    consultation_fee = ?,
                    status = ?
                WHERE id = ?";


        $stmt =
            $conn->prepare($sql);


        if ($stmt) {


            /*
             * 12 variables:
             *
             * 9 strings
             * 1 double
             * 1 string
             * 1 integer
             *
             * s s s s s s s s s d s i
             */

            $stmt->bind_param(
                "sssssssssdsi",
                $name,
                $specialization,
                $qualification,
                $phone,
                $email,
                $address,
                $gender,
                $date_of_birth,
                $joining_date,
                $consultation_fee,
                $status,
                $id
            );


            /* -------------------------------------------------
               EXECUTE UPDATE
            ------------------------------------------------- */

            if ($stmt->execute()) {

                if ($stmt->affected_rows >= 0) {

                    $message =
                        "Doctor information updated successfully.";
                }

            } else {

                $error =
                    "Unable to update doctor. " .
                    $stmt->error;
            }


            $stmt->close();

        } else {

            $error =
                "Database error: " .
                $conn->error;
        }
    }
}


/* =========================================================
   SEARCH DOCTORS
========================================================= */

$search =
    trim($_GET['search'] ?? '');


if ($search !== '') {

    $searchValue =
        "%" . $search . "%";


    $stmt =
        $conn->prepare(
            "SELECT *
             FROM doctors
             WHERE doctor_id LIKE ?
             OR name LIKE ?
             OR specialization LIKE ?
             OR phone LIKE ?
             OR email LIKE ?
             ORDER BY id DESC"
        );


    if ($stmt) {

        $stmt->bind_param(
            "sssss",
            $searchValue,
            $searchValue,
            $searchValue,
            $searchValue,
            $searchValue
        );


        $stmt->execute();


        $doctors =
            $stmt->get_result();


        $stmt->close();

    } else {

        $doctors = false;

        $error =
            "Database error: " .
            $conn->error;
    }

} else {

    $doctors =
        $conn->query(
            "SELECT *
             FROM doctors
             ORDER BY id DESC"
        );
}


/* =========================================================
   GET DOCTOR FOR EDIT
========================================================= */

$editDoctor = null;


if (isset($_GET['edit'])) {

    $editId =
        intval($_GET['edit']);


    if ($editId > 0) {

        $stmt =
            $conn->prepare(
                "SELECT *
                 FROM doctors
                 WHERE id = ?"
            );


        if ($stmt) {

            $stmt->bind_param(
                "i",
                $editId
            );


            $stmt->execute();


            $result =
                $stmt->get_result();


            if (
                $result->num_rows > 0
            ) {

                $editDoctor =
                    $result->fetch_assoc();
            }


            $stmt->close();
        }
    }
}


/* =========================================================
   GET DOCTOR FOR VIEW
========================================================= */

$viewDoctor = null;


if (isset($_GET['view'])) {

    $viewId =
        intval($_GET['view']);


    if ($viewId > 0) {

        $stmt =
            $conn->prepare(
                "SELECT *
                 FROM doctors
                 WHERE id = ?"
            );


        if ($stmt) {

            $stmt->bind_param(
                "i",
                $viewId
            );


            $stmt->execute();


            $result =
                $stmt->get_result();


            if (
                $result->num_rows > 0
            ) {

                $viewDoctor =
                    $result->fetch_assoc();
            }


            $stmt->close();
        }
    }
}

$doctorSourceProfile = null;
if ($viewDoctor) {
    try {
        $profileTable = $conn->query("SHOW TABLES LIKE 'doctor_external_profiles'");
        if ($profileTable && $profileTable->num_rows > 0) {
            $profileStatement = $conn->prepare("SELECT * FROM doctor_external_profiles WHERE doctor_id = ? AND source_hospital = 'Apollo Imperial Hospitals' ORDER BY source_checked_at DESC LIMIT 1");
            if (!$profileStatement) throw new RuntimeException($conn->error);
            try {
                $profileDoctorId = (int) $viewDoctor['id'];
                if (!$profileStatement->bind_param('i', $profileDoctorId) || !$profileStatement->execute()) throw new RuntimeException($profileStatement->error);
                $doctorSourceProfile = $profileStatement->get_result()->fetch_assoc();
            } finally { $profileStatement->close(); }
        }
        if ($profileTable) $profileTable->free();
    } catch (Throwable $profileError) { error_log('Doctor source profile: ' . $profileError->getMessage()); }
}
?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>
Doctor Management | Hospital Management System
</title>


<style>
.source-profile { display:flex; gap:18px; align-items:center; flex-wrap:wrap; padding:18px; margin-bottom:20px; background:#eef7fa; border-radius:10px; }
.source-profile img { height:auto; border-radius:8px; }
.source-profile p { margin:6px 0; }
.source-profile small { color:#526575; }


/* =========================================================
   GENERAL
========================================================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #f4f7fb;

    color: #333;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 240px;
    height: 100vh;

    background: #172b4d;

    color: white;

    padding-top: 25px;

    overflow-y: auto;
}


.sidebar h2 {

    text-align: center;

    margin-bottom: 30px;

    font-size: 22px;
}


.sidebar a {

    display: block;

    color: #dbe5f5;

    text-decoration: none;

    padding: 14px 25px;

    font-size: 15px;
}


.sidebar a:hover,
.sidebar a.active {

    background: #1f6feb;

    color: white;
}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left: 240px;

    padding: 30px;

    min-height: 100vh;
}


/* =========================================================
   HEADER
========================================================= */

.header {

    background: white;

    padding: 20px 25px;

    border-radius: 10px;

    margin-bottom: 25px;

    box-shadow:
        0 2px 8px rgba(0,0,0,0.06);

    display: flex;

    justify-content: space-between;

    align-items: center;
}


.header h1 {

    font-size: 25px;

    color: #172b4d;
}


.header span {

    color: #666;
}


/* =========================================================
   MESSAGES
========================================================= */

.success {

    background: #d1e7dd;

    color: #0f5132;

    padding: 14px;

    border-radius: 6px;

    margin-bottom: 20px;

    border-left:
        5px solid #198754;
}


.error {

    background: #f8d7da;

    color: #842029;

    padding: 14px;

    border-radius: 6px;

    margin-bottom: 20px;

    border-left:
        5px solid #dc3545;
}


/* =========================================================
   CARD
========================================================= */

.card {

    background: white;

    border-radius: 10px;

    padding: 25px;

    margin-bottom: 25px;

    box-shadow:
        0 2px 8px rgba(0,0,0,0.06);
}


.card h2 {

    margin-bottom: 20px;

    color: #172b4d;
}


/* =========================================================
   FORM
========================================================= */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;
}


.form-group {

    display: flex;

    flex-direction: column;
}


.form-group.full {

    grid-column: 1 / -1;
}


.form-group label {

    font-weight: bold;

    margin-bottom: 7px;

    font-size: 14px;
}


.form-group input,
.form-group select,
.form-group textarea {

    padding: 11px;

    border: 1px solid #ccd4df;

    border-radius: 6px;

    font-size: 14px;

    outline: none;

    font-family: inherit;
}


.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #1f6feb;

    box-shadow:
        0 0 0 2px rgba(31,111,235,0.10);
}


.form-group textarea {

    resize: vertical;

    min-height: 80px;
}


/* =========================================================
   BUTTONS
========================================================= */

.btn {

    border: none;

    padding: 11px 18px;

    border-radius: 6px;

    cursor: pointer;

    font-size: 14px;

    text-decoration: none;

    display: inline-block;
}


.btn-primary {

    background: #1f6feb;

    color: white;
}


.btn-primary:hover {

    background: #1557b0;
}


.btn-success {

    background: #198754;

    color: white;
}


.btn-success:hover {

    background: #146c43;
}


.btn-warning {

    background: #f0ad4e;

    color: white;
}


.btn-warning:hover {

    background: #d9963d;
}


.btn-danger {

    background: #dc3545;

    color: white;
}


.btn-danger:hover {

    background: #bb2d3b;
}


.btn-secondary {

    background: #6c757d;

    color: white;
}


.btn-secondary:hover {

    background: #565e64;
}


/* =========================================================
   SEARCH
========================================================= */

.search-box {

    display: flex;

    gap: 10px;

    margin-bottom: 20px;
}


.search-box input {

    flex: 1;

    padding: 12px;

    border: 1px solid #ccd4df;

    border-radius: 6px;

    outline: none;
}


.search-box input:focus {

    border-color: #1f6feb;
}


/* =========================================================
   TABLE
========================================================= */

.table-container {

    overflow-x: auto;
}


table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1000px;
}


table th {

    background: #172b4d;

    color: white;

    padding: 13px;

    text-align: left;

    font-size: 14px;
}


table td {

    padding: 12px;

    border-bottom:
        1px solid #e5e7eb;

    font-size: 14px;
}


table tr:hover {

    background: #f8fafc;
}


/* =========================================================
   ACTIONS
========================================================= */

.actions {

    display: flex;

    gap: 5px;

    flex-wrap: wrap;
}


.actions .btn {

    padding: 7px 10px;

    font-size: 12px;
}


/* =========================================================
   DETAILS
========================================================= */

.details-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 15px;
}


.detail-item {

    padding: 13px;

    background: #f8fafc;

    border-radius: 6px;
}


.detail-item strong {

    display: block;

    color: #172b4d;

    margin-bottom: 5px;
}


/* =========================================================
   STATUS
========================================================= */

.status-active {

    color: #198754;

    font-weight: bold;
}


.status-inactive {

    color: #dc3545;

    font-weight: bold;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 1000px) {

    .form-grid {

        grid-template-columns:
            repeat(2, 1fr);
    }
}


@media (max-width: 900px) {

    .sidebar {

        width: 200px;
    }


    .main {

        margin-left: 200px;
    }
}


@media (max-width: 650px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;

        padding-bottom: 10px;
    }


    .main {

        margin-left: 0;

        padding: 15px;
    }


    .form-grid {

        grid-template-columns: 1fr;
    }


    .details-grid {

        grid-template-columns: 1fr;
    }


    .header {

        flex-direction: column;

        align-items: flex-start;

        gap: 10px;
    }


    .search-box {

        flex-direction: column;
    }
}

</style>

</head>


<body>


<!-- =====================================================
     SIDEBAR
====================================================== -->

<div class="sidebar">

    <h2>🏥 HMS</h2>


    <a href="dashboard.php">
        Dashboard
    </a>


    <a href="patients.php">
        👤 Patients
    </a>


    <a href="doctors.php"
       class="active">
        👨‍⚕️ Doctors
    </a>


    <a href="appointments.php">
        📅 Appointments
    </a>


    <a href="medical_records.php">
        📋 Medical Records
    </a>


    <a href="prescriptions.php">
        💊 Prescriptions
    </a>


    <a href="billing.php">
        💰 Billing
    </a>


    <a href="reports.php">
        📊 Reports
    </a>


    <a href="users.php">
        👥 Users
    </a>


    <a href="settings.php">
        ⚙ Settings
    </a>


    <a href="../auth/logout.php">
        🚪 Logout
    </a>

</div>


<!-- =====================================================
     MAIN CONTENT
====================================================== -->

<div class="main">


    <!-- =================================================
         HEADER
    ================================================== -->

    <div class="header">

        <h1>
            Doctor Management
        </h1>


        <span>

            Welcome,
            <?php

            echo doctor_escape(
                $_SESSION['full_name'] ??
                'Administrator'
            );

            ?>

        </span>

    </div>


    <!-- =================================================
         SUCCESS MESSAGE
    ================================================== -->

    <?php if ($message !== ""): ?>

        <div class="success">

            <?php

            echo doctor_escape(
                $message
            );

            ?>

        </div>

    <?php endif; ?>


    <!-- =================================================
         ERROR MESSAGE
    ================================================== -->

    <?php if ($error !== ""): ?>

        <div class="error">

            <?php

            echo doctor_escape(
                $error
            );

            ?>

        </div>

    <?php endif; ?>


    <!-- =================================================
         VIEW DOCTOR
    ================================================== -->

    <?php if ($viewDoctor): ?>

    <div class="card">

        <h2>
            Doctor Details
        </h2>


        <?php if ($doctorSourceProfile): ?>
            <div class="source-profile">
                <?php if (preg_match('#^https://aihlbd\.org/wp-content/uploads/[^\s]+$#D', (string) $doctorSourceProfile['photo_url'])): ?>
                    <img src="<?= doctor_escape($doctorSourceProfile['photo_url']) ?>" alt="<?= doctor_escape($doctorSourceProfile['listed_name']) ?>" width="110" loading="lazy" referrerpolicy="no-referrer">
                <?php endif; ?>
                <div>
                    <strong><?= doctor_escape($doctorSourceProfile['designation']) ?></strong>
                    <p><?= doctor_escape($doctorSourceProfile['experience']) ?></p>
                    <p>Listed at <?= doctor_escape($doctorSourceProfile['source_hospital']) ?>.</p>
                    <small>Source: <a href="https://aihlbd.org/our-doctors/" target="_blank" rel="noopener noreferrer">Hospital doctor directory</a> · Checked <?= doctor_escape($doctorSourceProfile['source_checked_at']) ?> UTC</small>
                </div>
            </div>
        <?php endif; ?>
        <div class="details-grid">


            <div class="detail-item">

                <strong>
                    Doctor ID
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['doctor_id']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Doctor Name
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['name']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Specialization
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['specialization']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Qualification
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['qualification']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Gender
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['gender']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Date of Birth
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['date_of_birth']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Phone
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['phone']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Email
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['email']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Joining Date
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['joining_date']
                );

                ?>

            </div>


            <div class="detail-item">

                <strong>
                    Consultation Fee
                </strong>

                <?php echo doctor_escape(doctor_fee_label($viewDoctor['consultation_fee'])); ?>

            </div>


            <div class="detail-item">

                <strong>
                    Status
                </strong>


                <?php if (
                    $viewDoctor['status']
                    === $doctorStatusValues[0]
                ): ?>

                    <span class="status-active">
                        ● <?= doctor_escape($doctorStatusValues[0]) ?>
                    </span>

                <?php else: ?>

                    <span class="status-inactive">
                        ● <?= doctor_escape($doctorStatusValues[1]) ?>
                    </span>

                <?php endif; ?>

            </div>


            <div class="detail-item">

                <strong>
                    Address
                </strong>

                <?php

                echo doctor_escape(
                    $viewDoctor['address']
                );

                ?>

            </div>


        </div>


        <br>


        <a href="doctors.php"
           class="btn btn-secondary">

            ← Back to Doctors

        </a>

    </div>

    <?php endif; ?>


    <!-- =================================================
         ADD / EDIT DOCTOR FORM
    ================================================== -->

    <?php if (!$viewDoctor): ?>

    <div class="card">

        <h2>

            <?php

            echo $editDoctor
                ? "Edit Doctor"
                : "Add New Doctor";

            ?>

        </h2>


        <form method="POST"
              action="doctors.php<?php

              echo $editDoctor
                  ? '?edit=' .
                    intval($editDoctor['id'])
                  : '';

              ?>">


            <!-- EDIT DOCTOR ID -->

            <?php if ($editDoctor): ?>

                <input
                    type="hidden"
                    name="id"
                    value="<?php

                    echo intval(
                        $editDoctor['id']
                    );

                    ?>"
                >

            <?php endif; ?>


            <div class="form-grid">


                <!-- =====================================
                     DOCTOR NAME
                ====================================== -->

                <div class="form-group">

                    <label>
                        Doctor Name *
                    </label>


                    <input
                        type="text"
                        name="name"
                        required
                        placeholder="Enter doctor name"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor['name']
                            ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     SPECIALIZATION
                ====================================== -->

                <div class="form-group">

                    <label>
                        Specialization *
                    </label>


                    <input
                        type="text"
                        name="specialization"
                        required
                        placeholder="e.g. Cardiology"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor[
                                'specialization'
                            ] ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     QUALIFICATION
                ====================================== -->

                <div class="form-group">

                    <label>
                        Qualification
                    </label>


                    <input
                        type="text"
                        name="qualification"
                        placeholder="e.g. MBBS, FCPS"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor[
                                'qualification'
                            ] ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     PHONE
                ====================================== -->

                <div class="form-group">

                    <label>
                        Phone (optional)
                    </label>


                    <input
                        type="text"
                        name="phone"
                        placeholder="e.g. 01711111111"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor['phone']
                            ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     EMAIL
                ====================================== -->

                <div class="form-group">

                    <label>
                        Email
                    </label>


                    <input
                        type="email"
                        name="email"
                        placeholder="doctor@hospital.com"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor['email']
                            ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     GENDER
                ====================================== -->

                <div class="form-group">

                    <label>
                        Gender
                    </label>


                    <select name="gender">


                        <option value="">
                            Select Gender
                        </option>


                        <option value="Male"
                            <?php

                            if (
                                (
                                    $editDoctor[
                                        'gender'
                                    ] ?? ''
                                ) === 'Male'
                            ) {

                                echo 'selected';
                            }

                            ?>>

                            Male

                        </option>


                        <option value="Female"
                            <?php

                            if (
                                (
                                    $editDoctor[
                                        'gender'
                                    ] ?? ''
                                ) === 'Female'
                            ) {

                                echo 'selected';
                            }

                            ?>>

                            Female

                        </option>


                        <option value="Other"
                            <?php

                            if (
                                (
                                    $editDoctor[
                                        'gender'
                                    ] ?? ''
                                ) === 'Other'
                            ) {

                                echo 'selected';
                            }

                            ?>>

                            Other

                        </option>


                    </select>

                </div>


                <!-- =====================================
                     DATE OF BIRTH
                ====================================== -->

                <div class="form-group">

                    <label>
                        Date of Birth
                    </label>


                    <input
                        type="date"
                        name="date_of_birth"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor[
                                'date_of_birth'
                            ] ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     JOINING DATE
                ====================================== -->

                <div class="form-group">

                    <label>
                        Joining Date
                    </label>


                    <input
                        type="date"
                        name="joining_date"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor[
                                'joining_date'
                            ] ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     CONSULTATION FEE
                ====================================== -->

                <div class="form-group">

                    <label>
                        Consultation Fee (৳)
                    </label>


                    <input
                        type="number"
                        name="consultation_fee"
                        placeholder="Not provided"
                        min="0"
                        step="0.01"
                        value="<?php

                        echo doctor_escape(
                            $editDoctor[
                                'consultation_fee'
                            ] ?? ''
                        );

                        ?>"
                    >

                </div>


                <!-- =====================================
                     STATUS
                ====================================== -->

                <div class="form-group">

                    <label>
                        Status
                    </label>


                    <select name="status" required>
                        <?php foreach ($doctorStatusValues as $doctorStatusOption): ?>
                            <option value="<?= doctor_escape($doctorStatusOption) ?>" <?= ($editDoctor['status'] ?? $doctorStatusValues[0]) === $doctorStatusOption ? 'selected' : '' ?>><?= doctor_escape($doctorStatusOption) ?></option>
                        <?php endforeach; ?>
                    </select>

                </div>


                <!-- =====================================
                     ADDRESS
                ====================================== -->

                <div class="form-group full">

                    <label>
                        Address
                    </label>


                    <textarea
                        name="address"
                        placeholder="Enter doctor's address"
                    ><?php

                    echo doctor_escape(
                        $editDoctor[
                            'address'
                        ] ?? ''
                    );

                    ?></textarea>

                </div>


            </div>


            <br>


            <!-- =========================================
                 FORM BUTTONS
            ========================================== -->

            <?php if ($editDoctor): ?>


                <button
                    type="submit"
                    name="update_doctor"
                    class="btn btn-success">

                    ✓ Update Doctor

                </button>


                <a
                    href="doctors.php"
                    class="btn btn-secondary">

                    Cancel

                </a>


            <?php else: ?>


                <button
                    type="submit"
                    name="add_doctor"
                    class="btn btn-primary">

                    + Add Doctor

                </button>


            <?php endif; ?>


        </form>

    </div>

    <?php endif; ?>


    <!-- =================================================
         DOCTOR LIST
    ================================================== -->

    <div class="card">

        <h2>
            Doctor List
        </h2>


        <!-- =============================================
             SEARCH
        ============================================== -->

        <form method="GET"
              class="search-box">


            <input
                type="text"
                name="search"
                placeholder="Search by Doctor ID, Name, Specialization, Phone or Email..."
                value="<?php

                echo doctor_escape(
                    $search
                );

                ?>"
            >


            <button
                type="submit"
                class="btn btn-primary">

                🔎 Search

            </button>


            <?php if ($search !== ''): ?>


                <a
                    href="doctors.php"
                    class="btn btn-secondary">

                    Clear

                </a>


            <?php endif; ?>


        </form>


        <!-- =============================================
             TABLE
        ============================================== -->

        <div class="table-container">


        <table>


            <thead>

                <tr>

                    <th>#</th>

                    <th>Doctor ID</th>

                    <th>Name</th>

                    <th>Specialization</th>

                    <th>Qualification</th>

                    <th>Phone</th>

                    <th>Fee</th>

                    <th>Status</th>

                    <th>Actions</th>

                </tr>

            </thead>


            <tbody>


            <?php

            if (
                $doctors &&
                $doctors->num_rows > 0
            ):

                $counter = 1;


                while (
                    $doctor =
                    $doctors->fetch_assoc()
                ):

            ?>


                <tr>


                    <!-- NUMBER -->

                    <td>

                        <?php

                        echo $counter++;

                        ?>

                    </td>


                    <!-- DOCTOR ID -->

                    <td>

                        <strong>

                            <?php

                            echo doctor_escape(
                                $doctor[
                                    'doctor_id'
                                ]
                            );

                            ?>

                        </strong>

                    </td>


                    <!-- NAME -->

                    <td>

                        <?php

                        echo doctor_escape(
                            $doctor['name']
                        );

                        ?>

                    </td>


                    <!-- SPECIALIZATION -->

                    <td>

                        <?php

                        echo doctor_escape(
                            $doctor[
                                'specialization'
                            ]
                        );

                        ?>

                    </td>


                    <!-- QUALIFICATION -->

                    <td>

                        <?php

                        echo doctor_escape(
                            $doctor[
                                'qualification'
                            ]
                        );

                        ?>

                    </td>


                    <!-- PHONE -->

                    <td>

                        <?php

                        echo doctor_escape(
                            $doctor['phone']
                        );

                        ?>

                    </td>


                    <!-- FEE -->

                    <td>

                        <?php echo doctor_escape(doctor_fee_label($doctor['consultation_fee'])); ?>

                    </td>


                    <!-- STATUS -->

                    <td>


                        <?php

                        $doctorStatus =
                            trim(
                                $doctor['status']
                                ?? ''
                            );


                        if (
                            strcasecmp(
                                $doctorStatus,
                                $doctorStatusValues[0]
                            ) === 0
                        ):

                        ?>


                            <span
                                class="status-active">

                                ● <?= doctor_escape($doctorStatusValues[0]) ?>

                            </span>


                        <?php else: ?>


                            <span
                                class="status-inactive">

                                ● <?= doctor_escape($doctorStatusValues[1]) ?>

                            </span>


                        <?php endif; ?>


                    </td>


                    <!-- ACTIONS -->

                    <td>


                        <div class="actions">


                            <!-- VIEW -->

                            <a
                                href="doctors.php?view=<?php

                                echo intval(
                                    $doctor['id']
                                );

                                ?>"
                                class="btn btn-primary">

                                View

                            </a>


                            <!-- EDIT -->

                            <a
                                href="doctors.php?edit=<?php

                                echo intval(
                                    $doctor['id']
                                );

                                ?>"
                                class="btn btn-warning">

                                Edit

                            </a>


                            <!-- DELETE -->

                            <a
                                href="doctors.php?delete=<?php

                                echo intval(
                                    $doctor['id']
                                );

                                ?>"
                                class="btn btn-danger"
                                onclick="return confirm(
                                    'Are you sure you want to delete this doctor?'
                                );">

                                Delete

                            </a>


                        </div>


                    </td>


                </tr>


            <?php

                endwhile;


            else:

            ?>


                <tr>

                    <td
                        colspan="9"
                        style="
                            text-align:center;
                            padding:30px;
                        ">

                        No doctors found.

                    </td>

                </tr>


            <?php endif; ?>


            </tbody>


        </table>


        </div>


    </div>


</div>


</body>

</html>