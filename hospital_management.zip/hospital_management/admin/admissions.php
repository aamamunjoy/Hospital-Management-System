<?php
require_once __DIR__ . '/_common.php';

// All values are bound parameters. Check preparation before calling bind_param.
function admission_statement($conn, $sql, $types = '', $values = []) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) throw new RuntimeException('Prepare failed: ' . $conn->error);
    try {
        if ($types !== '' && !$stmt->bind_param($types, ...$values)) {
            throw new RuntimeException('Bind failed: ' . $stmt->error);
        }
        if (!$stmt->execute()) throw new RuntimeException('Execute failed: ' . $stmt->error);
        return $stmt;
    } catch (Throwable $error) {
        $stmt->close();
        throw $error;
    }
}
function admission_rows($conn, $sql, $types = '', $values = []) {
    $stmt = admission_statement($conn, $sql, $types, $values);
    try {
        $result = $stmt->get_result();
        if (!$result) throw new RuntimeException('Result failed: ' . $stmt->error);
        return $result->fetch_all(MYSQLI_ASSOC);
    } finally {
        $stmt->close();
    }
}
function admission_input($source, $key, $default = '') {
    return isset($source[$key]) && is_string($source[$key]) ? trim($source[$key]) : $default;
}
function admission_positive_id($value) {
    return filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 2147483647]]);
}
function admission_valid_date($value) {
    if (!preg_match('/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/D', $value)) return false;
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
    return $date !== false && $date->format('Y-m-d') === $value && substr($value, 0, 4) >= '1000';
}

$today = date('Y-m-d');
$statuses = ['Admitted', 'Discharged'];
$errors = [];
$setupError = '';
$patients = $doctors = $admissions = [];
$form = ['id' => '', 'patient_id' => '', 'doctor_id' => '', 'admission_date' => $today,
    'room_no' => '', 'bed_no' => '', 'status' => 'Admitted', 'discharge_date' => ''];

try {
    $columns = $conn->query('SHOW COLUMNS FROM `admissions`');
    if (!$columns) throw new RuntimeException('Cannot read admissions schema: ' . $conn->error);
    $fields = array_column($columns->fetch_all(MYSQLI_ASSOC), 'Field');
    $columns->free();
    $required = ['id', 'admission_id', 'patient_id', 'doctor_id', 'admission_date', 'room_no', 'bed_no', 'status', 'discharge_date'];
    if (array_diff($required, $fields)) throw new RuntimeException('Admissions columns do not match the supplied schema.');
    $patients = admission_rows($conn, 'SELECT id, patient_id, name FROM patients ORDER BY name, id');
    $doctors = admission_rows($conn, 'SELECT id, doctor_id, name FROM doctors ORDER BY name, id');
} catch (Throwable $error) {
    error_log('Admissions setup: ' . $error->getMessage());
    $setupError = 'Admissions could not be loaded. If the admissions table is missing, import migrations/001_add_admissions.sql into your hospital database. If it already exists, check the database connection and PHP error log.';
}

if ($setupError === '' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    // Reject invalid tokens before any database write.
    if (!is_string($_POST['csrf'] ?? null)) die('Invalid request token.');
    verify_csrf();
    $action = admission_input($_POST, 'action');
    $idText = admission_input($_POST, 'id');
    $id = $idText === '' ? 0 : admission_positive_id($idText);
    if (!in_array($action, ['save', 'discharge'], true)) $errors[] = 'Invalid admission action.';
    if ($id === false || ($action === 'discharge' && !$id)) $errors[] = 'Invalid admission record.';

    if ($action === 'save') {
        foreach (array_keys($form) as $field) $form[$field] = admission_input($_POST, $field);
        $form['room_no'] = strtoupper($form['room_no']);
        $form['bed_no'] = strtoupper($form['bed_no']);
        $patientId = admission_positive_id($form['patient_id']);
        $doctorId = admission_positive_id($form['doctor_id']);
        if (!$patientId || !in_array($patientId, array_map('intval', array_column($patients, 'id')), true)) {
            $errors[] = 'Choose an existing patient.';
        }
        if (!$doctorId || !in_array($doctorId, array_map('intval', array_column($doctors, 'id')), true)) {
            $errors[] = 'Choose an assigned doctor.';
        }
        if (!admission_valid_date($form['admission_date']) || $form['admission_date'] > $today) {
            $errors[] = 'Enter a valid admission date that is not in the future.';
        }
        foreach (['room_no' => 'Room number', 'bed_no' => 'Bed number'] as $field => $label) {
            $length = function_exists('mb_strlen') ? mb_strlen($form[$field], 'UTF-8') : strlen($form[$field]);
            if ($length < 1 || $length > 30) $errors[] = $label . ' must contain 1 to 30 characters.';
        }
        if (!in_array($form['status'], $statuses, true)) $errors[] = 'Choose Admitted or Discharged.';
        if ($form['status'] === 'Discharged') {
            if (!admission_valid_date($form['discharge_date']) || $form['discharge_date'] < $form['admission_date'] || $form['discharge_date'] > $today) {
                $errors[] = 'Enter a discharge date between the admission date and today.';
            }
        } else {
            $form['discharge_date'] = '';
        }
    }

    if (!$errors) {
        $locked = false;
        $inTransaction = false;
        $saved = false;
        try {
            // Serialize this page's admission writes, including check + save.
            // MySQL named locks survive commit/rollback; always release in finally.
            $database = admission_rows($conn, 'SELECT DATABASE() AS db_name')[0]['db_name'];
            $lockName = 'hms.admissions.' . substr(hash('sha256', (string) $database), 0, 40);
            $lock = admission_rows($conn, 'SELECT GET_LOCK(?, 5) AS acquired', 's', [$lockName]);
            if ((int) ($lock[0]['acquired'] ?? 0) !== 1) {
                throw new DomainException('Admissions is busy. Please try saving again in a few seconds.');
            }
            $locked = true;
            if (!$conn->begin_transaction()) throw new RuntimeException('Begin transaction failed: ' . $conn->error);
            $inTransaction = true;
            $existing = null;
            if ($id) {
                $existing = admission_rows($conn, 'SELECT * FROM admissions WHERE id = ? FOR UPDATE', 'i', [$id])[0] ?? null;
                if (!$existing) throw new DomainException('That admission no longer exists. Refresh the page and try again.');
            }

            if ($action === 'discharge') {
                if ($existing['status'] !== 'Admitted') throw new DomainException('This patient has already been discharged from this admission.');
                if ($existing['admission_date'] > $today) throw new DomainException('The admission date is in the future. Correct it before discharging.');
                $stmt = admission_statement($conn, "UPDATE admissions SET status = 'Discharged', discharge_date = ? WHERE id = ?", 'si', [$today, $id]);
                $stmt->close();
            } else {
                if ($form['status'] === 'Admitted') {
                    $active = admission_rows($conn, "SELECT id FROM admissions WHERE patient_id = ? AND status = 'Admitted' AND id <> ? LIMIT 1", 'ii', [$patientId, $id]);
                    if ($active) throw new DomainException('This patient already has an active admission. Discharge that stay before creating another.');
                    $occupied = admission_rows($conn, "SELECT id FROM admissions WHERE UPPER(TRIM(room_no)) = ? AND UPPER(TRIM(bed_no)) = ? AND status = 'Admitted' AND id <> ? LIMIT 1", 'ssi', [$form['room_no'], $form['bed_no'], $id]);
                    if ($occupied) throw new DomainException('That bed is already occupied in the selected room. Choose another bed.');
                }
                $values = [$patientId, $doctorId, $form['admission_date'], $form['room_no'], $form['bed_no'], $form['status'], $form['discharge_date'] === '' ? null : $form['discharge_date']];
                if ($id) {
                    $values[] = $id;
                    $stmt = admission_statement($conn, 'UPDATE admissions SET patient_id = ?, doctor_id = ?, admission_date = ?, room_no = ?, bed_no = ?, status = ?, discharge_date = ? WHERE id = ?', 'iisssssi', $values);
                } else {
                    // 19 characters, within the existing VARCHAR(20) column.
                    array_unshift($values, 'ADM' . strtoupper(bin2hex(random_bytes(8))));
                    $stmt = admission_statement($conn, 'INSERT INTO admissions (admission_id, patient_id, doctor_id, admission_date, room_no, bed_no, status, discharge_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', 'siisssss', $values);
                }
                $stmt->close();
            }
            if (!$conn->commit()) throw new RuntimeException('Commit failed: ' . $conn->error);
            $inTransaction = false;
            $saved = true;
        } catch (Throwable $error) {
            if ($inTransaction) {
                try { $conn->rollback(); } catch (Throwable $rollbackError) { error_log('Admissions rollback: ' . $rollbackError->getMessage()); }
            }
            if ($error instanceof DomainException) $errors[] = $error->getMessage();
            else {
                error_log('Admissions save: ' . $error->getMessage());
                $errors[] = 'The admission could not be saved. Please try again or check the PHP error log.';
            }
        } finally {
            if ($locked) {
                try { admission_rows($conn, 'SELECT RELEASE_LOCK(?) AS released', 's', [$lockName]); }
                catch (Throwable $releaseError) { error_log('Admissions unlock: ' . $releaseError->getMessage()); }
            }
        }
        if ($saved) {
            flash('success', $action === 'discharge' ? 'Patient discharged. The bed is now available.' : 'Admission saved successfully.');
            header('Location: admissions.php');
            exit;
        }
    }
}

if ($setupError === '' && $_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['edit'])) {
    $editId = admission_positive_id(admission_input($_GET, 'edit'));
    try {
        $record = $editId ? (admission_rows($conn, 'SELECT * FROM admissions WHERE id = ?', 'i', [$editId])[0] ?? null) : null;
        if (!$record) $errors[] = 'Admission not found.';
        else foreach (array_keys($form) as $field) $form[$field] = (string) ($record[$field] ?? '');
    } catch (Throwable $error) {
        error_log('Admissions edit: ' . $error->getMessage());
        $errors[] = 'The admission could not be opened. Please try again.';
    }
}

$query = substr(admission_input($_GET, 'q'), 0, 100);
$filter = admission_input($_GET, 'status');
if (!in_array($filter, $statuses, true)) $filter = '';
$page = admission_positive_id(admission_input($_GET, 'page', '1')) ?: 1;
$total = 0;
$pages = 1;
$listError = '';
if ($setupError === '') {
    try {
        $where = ' WHERE 1 = 1';
        $types = '';
        $values = [];
        if ($query !== '') {
            $where .= ' AND (p.patient_id LIKE ? OR p.name LIKE ? OR a.admission_id LIKE ? OR a.room_no LIKE ? OR a.bed_no LIKE ?)';
            $types .= 'sssss';
            // Treat percent and underscore as literal search characters.
            $term = '%' . str_replace(['!', '%', '_'], ['!!', '!%', '!_'], $query) . '%';
            $where = str_replace('LIKE ?', "LIKE ? ESCAPE '!'", $where);
            $values = array_fill(0, 5, $term);
        }
        if ($filter !== '') { $where .= ' AND a.status = ?'; $types .= 's'; $values[] = $filter; }
        $joins = ' FROM admissions a JOIN patients p ON p.id = a.patient_id JOIN doctors d ON d.id = a.doctor_id';
        $total = (int) admission_rows($conn, 'SELECT COUNT(*) AS total' . $joins . $where, $types, $values)[0]['total'];
        $pages = max(1, (int) ceil($total / 25));
        $page = min($page, $pages);
        $listValues = array_merge($values, [25, ($page - 1) * 25]);
        $admissions = admission_rows($conn, 'SELECT a.*, p.patient_id AS patient_code, p.name AS patient_name, d.name AS doctor_name' . $joins . $where . ' ORDER BY a.admission_date DESC, a.id DESC LIMIT ? OFFSET ?', $types . 'ii', $listValues);
    } catch (Throwable $error) {
        error_log('Admissions list: ' . $error->getMessage());
        $listError = 'The admission list could not be loaded. Please refresh or check the PHP error log.';
    }
}
page_top('Patient Admissions', 'admissions');
?>
<p>Record hospital stays, assign beds, and keep each patient's admission history.</p>
<?php if ($setupError): ?>
    <div class="alert error" role="alert"><?= e($setupError) ?></div>
<?php else: ?>
    <?php if ($errors): ?>
        <div class="alert error" role="alert"><ul><?php foreach ($errors as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div>
    <?php endif; ?>
    <?php if (!$patients || !$doctors): ?>
        <div class="alert error">Register at least one <a href="patients.php">patient</a> and one <a href="doctors.php">doctor</a> before adding an admission.</div>
    <?php endif; ?>
    <section class="card" id="admission-form" aria-labelledby="admission-form-title">
        <h2 id="admission-form-title"><?= $form['id'] !== '' ? 'Edit admission' : 'New admission' ?></h2>
        <form method="post" action="admissions.php" class="grid-form">
            <?= csrf() ?>
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="id" value="<?= e($form['id']) ?>">
            <label for="patient_id">Patient ID / name
                <select name="patient_id" id="patient_id" required>
                    <option value="">Choose a patient</option>
                    <?php foreach ($patients as $patient): ?>
                        <option value="<?= (int) $patient['id'] ?>" <?= (string) $patient['id'] === $form['patient_id'] ? 'selected' : '' ?>><?= e($patient['patient_id'] . ' — ' . $patient['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label for="doctor_id">Assigned doctor
                <select name="doctor_id" id="doctor_id" required>
                    <option value="">Choose a doctor</option>
                    <?php foreach ($doctors as $doctor): ?>
                        <option value="<?= (int) $doctor['id'] ?>" <?= (string) $doctor['id'] === $form['doctor_id'] ? 'selected' : '' ?>><?= e($doctor['doctor_id'] . ' — ' . $doctor['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label for="admission_date">Admission date
                <input type="date" name="admission_date" id="admission_date" value="<?= e($form['admission_date']) ?>" min="1000-01-01" max="<?= e($today) ?>" required>
            </label>
            <label for="room_no">Room number
                <input name="room_no" id="room_no" value="<?= e($form['room_no']) ?>" placeholder="e.g. R101" maxlength="30" required>
            </label>
            <label for="bed_no">Bed number
                <input name="bed_no" id="bed_no" value="<?= e($form['bed_no']) ?>" placeholder="e.g. B01" maxlength="30" required>
            </label>
            <label for="status">Status
                <select name="status" id="status" required>
                    <?php foreach ($statuses as $status): ?><option value="<?= e($status) ?>" <?= $status === $form['status'] ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?>
                </select>
            </label>
            <label for="discharge_date">Discharge date (if discharged)
                <input type="date" name="discharge_date" id="discharge_date" value="<?= e($form['discharge_date']) ?>" min="<?= e(admission_valid_date($form['admission_date']) ? $form['admission_date'] : '1000-01-01') ?>" max="<?= e($today) ?>" aria-describedby="discharge-help">
                <small id="discharge-help">Required when the status is Discharged.</small>
            </label>
            <div class="actions wide">
                <button type="submit" class="btn" <?= !$patients || !$doctors ? 'disabled' : '' ?>><?= $form['id'] !== '' ? 'Save changes' : 'Admit patient' ?></button>
                <?php if ($form['id'] !== ''): ?><a class="btn secondary" href="admissions.php">Cancel</a><?php endif; ?>
            </div>
        </form>
    </section>
    <section class="card" aria-labelledby="history-title">
        <h2 id="history-title">Admission history</h2>
        <form method="get" action="admissions.php" class="grid-form">
            <label for="q">Search admissions<input type="search" name="q" id="q" value="<?= e($query) ?>" placeholder="Patient, admission ID, room, or bed" maxlength="100"></label>
            <label for="filter_status">Status<select name="status" id="filter_status"><option value="">All statuses</option><?php foreach ($statuses as $status): ?><option value="<?= e($status) ?>" <?= $filter === $status ? 'selected' : '' ?>><?= e($status) ?></option><?php endforeach; ?></select></label>
            <div class="actions"><button type="submit" class="btn">Search</button><a href="admissions.php" class="btn secondary">Clear</a></div>
        </form>
        <?php if ($listError): ?><div class="alert error" role="alert"><?= e($listError) ?></div><?php else: ?>
            <p><?= $total ?> admission<?= $total === 1 ? '' : 's' ?> found.</p>
            <div style="overflow-x:auto" tabindex="0" role="region" aria-label="Admission history table">
                <table>
                    <thead><tr><th scope="col">Admission ID</th><th scope="col">Patient ID / name</th><th scope="col">Doctor</th><th scope="col">Admission date</th><th scope="col">Room no.</th><th scope="col">Bed no.</th><th scope="col">Status</th><th scope="col">Discharge date</th><th scope="col">Actions</th></tr></thead>
                    <tbody>
                    <?php if (!$admissions): ?><tr><td colspan="9" class="empty">No admissions found.</td></tr><?php endif; ?>
                    <?php foreach ($admissions as $admission): ?>
                        <tr>
                            <td><?= e($admission['admission_id']) ?></td>
                            <td><strong><?= e($admission['patient_code']) ?></strong><br><?= e($admission['patient_name']) ?></td>
                            <td><?= e($admission['doctor_name']) ?></td>
                            <td><?= e($admission['admission_date']) ?></td>
                            <td><?= e($admission['room_no']) ?></td>
                            <td><?= e($admission['bed_no']) ?></td>
                            <td><span class="badge"><?= e($admission['status']) ?></span></td>
                            <td><?= e($admission['discharge_date'] ?: '—') ?></td>
                            <td><div class="actions" style="flex-wrap:wrap">
                                <a class="btn secondary" href="admissions.php?edit=<?= (int) $admission['id'] ?>#admission-form" aria-label="Edit admission <?= e($admission['admission_id']) ?>">Edit</a>
                                <?php if ($admission['status'] === 'Admitted'): ?>
                                    <form method="post" action="admissions.php" onsubmit="return confirm('Discharge this patient today and release the bed?')">
                                        <?= csrf() ?><input type="hidden" name="action" value="discharge"><input type="hidden" name="id" value="<?= (int) $admission['id'] ?>">
                                        <button class="btn" type="submit" aria-label="Discharge admission <?= e($admission['admission_id']) ?>">Discharge</button>
                                    </form>
                                <?php endif; ?>
                            </div></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($pages > 1): ?>
                <div class="actions" aria-label="Admission pages">
                    <?php if ($page > 1): ?><a class="btn secondary" href="?<?= e(http_build_query(['q' => $query, 'status' => $filter, 'page' => $page - 1])) ?>">Previous</a><?php endif; ?>
                    <span>Page <?= $page ?> of <?= $pages ?></span>
                    <?php if ($page < $pages): ?><a class="btn secondary" href="?<?= e(http_build_query(['q' => $query, 'status' => $filter, 'page' => $page + 1])) ?>">Next</a><?php endif; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </section>
    <script>
    (() => {
        const status = document.getElementById('status');
        const admission = document.getElementById('admission_date');
        const discharge = document.getElementById('discharge_date');
        const update = () => {
            discharge.disabled = status.value !== 'Discharged';
            discharge.required = status.value === 'Discharged';
            discharge.min = admission.value || '1000-01-01';
        };
        status.addEventListener('change', update);
        admission.addEventListener('change', update);
        update();
    })();
    </script>
<?php endif; ?>
<?php page_bottom(); ?>
