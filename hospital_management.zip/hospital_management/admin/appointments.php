<?php

session_start();

require_once "../config/database.php";

/* =========================================================
   ADMIN ACCESS PROTECTION
========================================================= */

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {

    header("Location: ../auth/login.php");
    exit;
}


/* =========================================================
   VARIABLES
========================================================= */

$message = "";
$error = "";

$editAppointment = null;


/* =========================================================
   GENERATE APPOINTMENT ID
========================================================= */

function generateAppointmentID($conn)
{
    $result = $conn->query("
        SELECT id
        FROM appointments
        ORDER BY id DESC
        LIMIT 1
    ");

    if ($result && $result->num_rows > 0) {

        $row = $result->fetch_assoc();

        $nextNumber = $row['id'] + 1;

    } else {

        $nextNumber = 1;
    }

    return "APT-" . str_pad($nextNumber, 5, "0", STR_PAD_LEFT);
}


/* =========================================================
   DELETE APPOINTMENT
========================================================= */

if (isset($_GET['delete'])) {

    $id = intval($_GET['delete']);

    if ($id > 0) {

        $stmt = $conn->prepare("
            DELETE FROM appointments
            WHERE id = ?
        ");

        if ($stmt) {

            $stmt->bind_param("i", $id);

            if ($stmt->execute()) {

                $message = "Appointment deleted successfully.";

            } else {

                $error = "Unable to delete appointment. " . $stmt->error;
            }

            $stmt->close();

        } else {

            $error = "Database error.";
        }
    }
}


/* =========================================================
   EDIT APPOINTMENT
========================================================= */

if (isset($_GET['edit'])) {

    $id = intval($_GET['edit']);

    $stmt = $conn->prepare("
        SELECT *
        FROM appointments
        WHERE id = ?
    ");

    if ($stmt) {

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows === 1) {

            $editAppointment = $result->fetch_assoc();
        }

        $stmt->close();
    }
}


/* =========================================================
   ADD / UPDATE APPOINTMENT
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';

    $patient_id = intval($_POST['patient_id'] ?? 0);
    $doctor_id = intval($_POST['doctor_id'] ?? 0);

    $appointment_date =
        trim($_POST['appointment_date'] ?? '');

    $appointment_time =
        trim($_POST['appointment_time'] ?? '');

    $reason =
        trim($_POST['reason'] ?? '');

    $status =
        trim($_POST['status'] ?? 'Scheduled');

    $notes =
        trim($_POST['notes'] ?? '');


    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
        $patient_id <= 0 ||
        $doctor_id <= 0 ||
        empty($appointment_date) ||
        empty($appointment_time)
    ) {

        $error =
            "Please fill in all required appointment fields.";

    } elseif (
        !in_array(
            $status,
            ['Scheduled', 'Completed', 'Cancelled', 'Pending']
        )
    ) {

        $error = "Invalid appointment status.";

    } else {


        /* =================================================
           ADD APPOINTMENT
        ================================================= */

        if ($action === 'add') {

            $appointment_id =
                generateAppointmentID($conn);

            $stmt = $conn->prepare("
                INSERT INTO appointments
                (
                    appointment_id,
                    patient_id,
                    doctor_id,
                    appointment_date,
                    appointment_time,
                    reason,
                    status,
                    notes
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            if ($stmt) {

                $stmt->bind_param(
                    "siisssss",
                    $appointment_id,
                    $patient_id,
                    $doctor_id,
                    $appointment_date,
                    $appointment_time,
                    $reason,
                    $status,
                    $notes
                );

                if ($stmt->execute()) {

                    $message =
                        "Appointment added successfully.";

                } else {

                    $error =
                        "Unable to add appointment. " .
                        $stmt->error;
                }

                $stmt->close();

            } else {

                $error = "Database error.";
            }
        }


        /* =================================================
           UPDATE APPOINTMENT
        ================================================= */

        elseif ($action === 'update') {

            $id = intval($_POST['id'] ?? 0);

            if ($id <= 0) {

                $error = "Invalid appointment ID.";

            } else {

                $stmt = $conn->prepare("
                    UPDATE appointments
                    SET
                        patient_id = ?,
                        doctor_id = ?,
                        appointment_date = ?,
                        appointment_time = ?,
                        reason = ?,
                        status = ?,
                        notes = ?
                    WHERE id = ?
                ");

                if ($stmt) {

                    $stmt->bind_param(
                        "iisssssi",
                        $patient_id,
                        $doctor_id,
                        $appointment_date,
                        $appointment_time,
                        $reason,
                        $status,
                        $notes,
                        $id
                    );

                    if ($stmt->execute()) {

                        $message =
                            "Appointment updated successfully.";

                    } else {

                        $error =
                            "Unable to update appointment. " .
                            $stmt->error;
                    }

                    $stmt->close();

                } else {

                    $error = "Database error.";
                }
            }
        }
    }
}


/* =========================================================
   LOAD ACTIVE PATIENTS
========================================================= */

$patients = [];

$result = $conn->query("
    SELECT id, patient_id, name
    FROM patients
    WHERE status = 'Active'
    ORDER BY name ASC
");

if ($result) {

    while ($row = $result->fetch_assoc()) {

        $patients[] = $row;
    }
}


/* =========================================================
   LOAD ACTIVE DOCTORS
========================================================= */

$doctors = [];

$result = $conn->query("
    SELECT id, doctor_id, name, specialization
    FROM doctors
    WHERE status IN ('Active', 'Available')
    ORDER BY name ASC
");

if ($result) {

    while ($row = $result->fetch_assoc()) {

        $doctors[] = $row;
    }
}


/* =========================================================
   SEARCH APPOINTMENTS
========================================================= */

$search = trim($_GET['search'] ?? '');

if ($search !== '') {

    $searchTerm = "%" . $search . "%";

    $stmt = $conn->prepare("
        SELECT
            a.*,
            p.patient_id AS patient_code,
            p.name AS patient_name,
            d.doctor_id AS doctor_code,
            d.name AS doctor_name,
            d.specialization
        FROM appointments a
        INNER JOIN patients p
            ON a.patient_id = p.id
        INNER JOIN doctors d
            ON a.doctor_id = d.id
        WHERE
            a.appointment_id LIKE ?
            OR p.patient_id LIKE ?
            OR p.name LIKE ?
            OR d.doctor_id LIKE ?
            OR d.name LIKE ?
        ORDER BY
            a.appointment_date DESC,
            a.appointment_time DESC
    ");

    $stmt->bind_param(
        "sssss",
        $searchTerm,
        $searchTerm,
        $searchTerm,
        $searchTerm,
        $searchTerm
    );

    $stmt->execute();

    $appointments =
        $stmt->get_result();

    $stmt->close();

} else {

    $appointments = $conn->query("
        SELECT
            a.*,
            p.patient_id AS patient_code,
            p.name AS patient_name,
            d.doctor_id AS doctor_code,
            d.name AS doctor_name,
            d.specialization
        FROM appointments a
        INNER JOIN patients p
            ON a.patient_id = p.id
        INNER JOIN doctors d
            ON a.doctor_id = d.id
        ORDER BY
            a.appointment_date DESC,
            a.appointment_time DESC
    ");
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Appointment Management</title>

<style>

/* =========================================================
   GENERAL
========================================================= */

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background: #f4f7fb;

    color: #333;
}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    position: fixed;

    left: 0;
    top: 0;

    width: 250px;
    height: 100vh;

    background: #172b4d;

    color: white;

    padding-top: 20px;

    overflow-y: auto;
}

.logo {

    text-align: center;

    padding: 10px 20px 25px;

    border-bottom:
        1px solid rgba(255,255,255,0.15);
}

.logo h2 {

    font-size: 21px;
}

.logo p {

    margin-top: 5px;

    font-size: 12px;

    color: #b8c7dc;
}

.menu {

    list-style: none;

    padding: 20px 0;
}

.menu li {

    margin: 3px 12px;
}

.menu a {

    display: block;

    color: #dce6f2;

    text-decoration: none;

    padding: 12px 15px;

    border-radius: 7px;

    font-size: 14px;

    transition: 0.2s;
}

.menu a:hover,
.menu a.active {

    background: #2f80ed;

    color: white;
}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left: 250px;

    min-height: 100vh;
}


/* =========================================================
   TOPBAR
========================================================= */

.topbar {

    height: 70px;

    background: white;

    border-bottom:
        1px solid #e3e8ef;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding: 0 30px;
}

.topbar h1 {

    font-size: 22px;

    color: #172b4d;
}

.admin-info {

    font-size: 14px;

    color: #555;
}


/* =========================================================
   CONTENT
========================================================= */

.content {

    padding: 30px;
}


/* =========================================================
   ALERTS
========================================================= */

.alert {

    padding: 13px 17px;

    border-radius: 6px;

    margin-bottom: 20px;

    font-size: 14px;
}

.success {

    background: #e8f7ee;

    color: #1d7a46;

    border: 1px solid #b9e5c9;
}

.danger {

    background: #fdecec;

    color: #b42318;

    border: 1px solid #f3baba;
}


/* =========================================================
   CARD
========================================================= */

.card {

    background: white;

    border-radius: 10px;

    padding: 25px;

    margin-bottom: 25px;

    box-shadow:
        0 2px 8px rgba(0,0,0,0.06);
}

.card-title {

    font-size: 19px;

    font-weight: bold;

    color: #172b4d;

    margin-bottom: 20px;
}


/* =========================================================
   FORM
========================================================= */

.form-grid {

    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 18px;
}

.form-group {

    display: flex;

    flex-direction: column;
}

.form-group.full {

    grid-column: 1 / -1;
}

.form-group label {

    font-size: 13px;

    font-weight: bold;

    margin-bottom: 7px;

    color: #444;
}

.form-group input,
.form-group select,
.form-group textarea {

    padding: 11px 12px;

    border: 1px solid #ccd4df;

    border-radius: 6px;

    font-size: 14px;

    outline: none;

    background: white;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {

    border-color: #2f80ed;

    box-shadow:
        0 0 0 2px rgba(47,128,237,0.1);
}

.form-group textarea {

    min-height: 90px;

    resize: vertical;
}


/* =========================================================
   BUTTONS
========================================================= */

.button-area {

    margin-top: 20px;

    display: flex;

    gap: 10px;
}

.btn {

    border: none;

    border-radius: 6px;

    padding: 11px 18px;

    text-decoration: none;

    display: inline-block;

    cursor: pointer;

    font-size: 14px;
}

.btn-primary {

    background: #2f80ed;

    color: white;
}

.btn-primary:hover {

    background: #1769d3;
}

.btn-secondary {

    background: #6c757d;

    color: white;
}

.btn-success {

    background: #27ae60;

    color: white;
}

.btn-danger {

    background: #e74c3c;

    color: white;
}

.btn-warning {

    background: #f39c12;

    color: white;
}

.btn-small {

    padding: 7px 10px;

    font-size: 12px;
}


/* =========================================================
   SEARCH
========================================================= */

.search-area {

    display: flex;

    gap: 10px;

    margin-bottom: 20px;
}

.search-area input {

    flex: 1;

    padding: 11px;

    border:
        1px solid #ccd4df;

    border-radius: 6px;

    font-size: 14px;
}


/* =========================================================
   TABLE
========================================================= */

.table-container {

    width: 100%;

    overflow-x: auto;
}

table {

    width: 100%;

    border-collapse: collapse;

    min-width: 1000px;
}

thead {

    background: #172b4d;

    color: white;
}

th,
td {

    padding: 12px;

    text-align: left;

    border-bottom:
        1px solid #e5e9ef;

    font-size: 13px;
}

tbody tr:hover {

    background: #f8fafc;
}


/* =========================================================
   STATUS
========================================================= */

.status {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    font-size: 11px;

    font-weight: bold;
}

.status-scheduled {

    background: #e8f1ff;

    color: #1769d3;
}

.status-completed {

    background: #e8f7ee;

    color: #1d7a46;
}

.status-cancelled {

    background: #fdecec;

    color: #b42318;
}

.status-pending {

    background: #fff4df;

    color: #a45b00;
}


/* =========================================================
   EMPTY
========================================================= */

.empty {

    text-align: center;

    padding: 35px;

    color: #777;
}


/* =========================================================
   RESPONSIVE
========================================================= */

@media (max-width: 900px) {

    .sidebar {

        width: 210px;
    }

    .main {

        margin-left: 210px;
    }

    .form-grid {

        grid-template-columns: 1fr;
    }

    .form-group.full {

        grid-column: auto;
    }
}

@media (max-width: 650px) {

    .sidebar {

        position: relative;

        width: 100%;

        height: auto;
    }

    .main {

        margin-left: 0;
    }

    .topbar {

        padding: 0 15px;
    }

    .content {

        padding: 15px;
    }

    .search-area {

        flex-direction: column;
    }
}

</style>

</head>


<body>


<!-- =====================================================
     SIDEBAR
===================================================== -->

<div class="sidebar">

    <div class="logo">

        <h2>Hospital Management</h2>

        <p>Administration Panel</p>

    </div>


    <ul class="menu">

        <li>
            <a href="dashboard.php">
                Dashboard
            </a>
        </li>

        <li>
            <a href="patients.php">
                Patients
            </a>
        </li>

        <li>
            <a href="doctors.php">
                Doctors
            </a>
        </li>

        <li>
            <a href="appointments.php"
               class="active">
                Appointments
            </a>
        </li>

        <li>
            <a href="medical_records.php">
                Medical Records
            </a>
        </li>

        <li>
            <a href="prescriptions.php">
                Prescriptions
            </a>
        </li>

        <li>
            <a href="billing.php">
                Billing
            </a>
        </li>

        <li>
            <a href="reports.php">
                Reports
            </a>
        </li>

        <li>
            <a href="users.php">
                Users
            </a>
        </li>

        <li>
            <a href="settings.php">
                Settings
            </a>
        </li>

        <li>
            <a href="../auth/logout.php">
                Logout
            </a>
        </li>

    </ul>

</div>


<!-- =====================================================
     MAIN
===================================================== -->

<div class="main">


    <!-- TOPBAR -->

    <div class="topbar">

        <h1>Appointment Management</h1>

        <div class="admin-info">

            Welcome,
            <strong>
                <?php
                echo htmlspecialchars(
                    $_SESSION['full_name']
                );
                ?>
            </strong>

        </div>

    </div>


    <!-- CONTENT -->

    <div class="content">


        <!-- ALERTS -->

        <?php if ($message): ?>

            <div class="alert success">

                <?php
                echo htmlspecialchars($message);
                ?>

            </div>

        <?php endif; ?>


        <?php if ($error): ?>

            <div class="alert danger">

                <?php
                echo htmlspecialchars($error);
                ?>

            </div>

        <?php endif; ?>


        <!-- =================================================
             APPOINTMENT FORM
        ================================================= -->

        <div class="card">

            <div class="card-title">

                <?php
                echo $editAppointment
                    ? "Edit Appointment"
                    : "Create New Appointment";
                ?>

            </div>


            <form method="POST">

                <?php if ($editAppointment): ?>

                    <input
                        type="hidden"
                        name="action"
                        value="update"
                    >

                    <input
                        type="hidden"
                        name="id"
                        value="<?php
                        echo $editAppointment['id'];
                        ?>"
                    >

                <?php else: ?>

                    <input
                        type="hidden"
                        name="action"
                        value="add"
                    >

                <?php endif; ?>


                <div class="form-grid">


                    <!-- PATIENT -->

                    <div class="form-group">

                        <label>
                            Patient *
                        </label>

                        <select
                            name="patient_id"
                            required
                        >

                            <option value="">
                                -- Select Patient --
                            </option>

                            <?php foreach ($patients as $patient): ?>

                                <option
                                    value="<?php
                                    echo $patient['id'];
                                    ?>"
                                    <?php

                                    if (
                                        $editAppointment &&
                                        $editAppointment['patient_id']
                                        ==
                                        $patient['id']
                                    ) {
                                        echo "selected";
                                    }

                                    ?>
                                >

                                    <?php
                                    echo htmlspecialchars(
                                        $patient['patient_id']
                                    );
                                    ?>

                                    -
                                    <?php
                                    echo htmlspecialchars(
                                        $patient['name']
                                    );
                                    ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- DOCTOR -->

                    <div class="form-group">

                        <label>
                            Doctor *
                        </label>

                        <select
                            name="doctor_id"
                            required
                        >

                            <option value="">
                                -- Select Doctor --
                            </option>

                            <?php foreach ($doctors as $doctor): ?>

                                <option
                                    value="<?php
                                    echo $doctor['id'];
                                    ?>"
                                    <?php

                                    if (
                                        $editAppointment &&
                                        $editAppointment['doctor_id']
                                        ==
                                        $doctor['id']
                                    ) {
                                        echo "selected";
                                    }

                                    ?>
                                >

                                    <?php
                                    echo htmlspecialchars(
                                        $doctor['doctor_id']
                                    );
                                    ?>

                                    -
                                    Dr.
                                    <?php
                                    echo htmlspecialchars(
                                        $doctor['name']
                                    );
                                    ?>

                                    -
                                    <?php
                                    echo htmlspecialchars(
                                        $doctor['specialization']
                                    );
                                    ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- DATE -->

                    <div class="form-group">

                        <label>
                            Appointment Date *
                        </label>

                        <input
                            type="date"
                            name="appointment_date"
                            required
                            value="<?php

                            echo $editAppointment
                                ? htmlspecialchars(
                                    $editAppointment[
                                        'appointment_date'
                                    ]
                                )
                                : date('Y-m-d');

                            ?>"
                        >

                    </div>


                    <!-- TIME -->

                    <div class="form-group">

                        <label>
                            Appointment Time *
                        </label>

                        <input
                            type="time"
                            name="appointment_time"
                            required
                            value="<?php

                            echo $editAppointment
                                ? htmlspecialchars(
                                    $editAppointment[
                                        'appointment_time'
                                    ]
                                )
                                : '';

                            ?>"
                        >

                    </div>


                    <!-- STATUS -->

                    <div class="form-group">

                        <label>
                            Status
                        </label>

                        <select name="status">

                            <?php

                            $currentStatus =
                                $editAppointment
                                ? $editAppointment['status']
                                : 'Scheduled';

                            ?>

                            <option
                                value="Scheduled"
                                <?php
                                echo $currentStatus ===
                                    'Scheduled'
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                Scheduled
                            </option>

                            <option
                                value="Pending"
                                <?php
                                echo $currentStatus ===
                                    'Pending'
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                Pending
                            </option>

                            <option
                                value="Completed"
                                <?php
                                echo $currentStatus ===
                                    'Completed'
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                Completed
                            </option>

                            <option
                                value="Cancelled"
                                <?php
                                echo $currentStatus ===
                                    'Cancelled'
                                    ? 'selected'
                                    : '';
                                ?>
                            >
                                Cancelled
                            </option>

                        </select>

                    </div>


                    <!-- REASON -->

                    <div class="form-group">

                        <label>
                            Appointment Reason
                        </label>

                        <input
                            type="text"
                            name="reason"
                            placeholder="e.g. General checkup"
                            value="<?php

                            echo $editAppointment
                                ? htmlspecialchars(
                                    $editAppointment['reason']
                                )
                                : '';

                            ?>"
                        >

                    </div>


                    <!-- NOTES -->

                    <div class="form-group full">

                        <label>
                            Notes
                        </label>

                        <textarea
                            name="notes"
                            placeholder="Additional appointment notes..."
                        ><?php

                        echo $editAppointment
                            ? htmlspecialchars(
                                $editAppointment['notes']
                            )
                            : '';

                        ?></textarea>

                    </div>

                </div>


                <!-- BUTTONS -->

                <div class="button-area">

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >

                        <?php
                        echo $editAppointment
                            ? "Update Appointment"
                            : "Create Appointment";
                        ?>

                    </button>


                    <?php if ($editAppointment): ?>

                        <a
                            href="appointments.php"
                            class="btn btn-secondary"
                        >
                            Cancel
                        </a>

                    <?php endif; ?>

                </div>

            </form>

        </div>


        <!-- =================================================
             APPOINTMENT LIST
        ================================================= -->

        <div class="card">

            <div class="card-title">

                Appointment List

            </div>


            <!-- SEARCH -->

            <form
                method="GET"
                class="search-area"
            >

                <input
                    type="text"
                    name="search"
                    placeholder="Search by appointment ID, patient, or doctor..."
                    value="<?php
                    echo htmlspecialchars($search);
                    ?>"
                >

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Search
                </button>


                <?php if ($search !== ''): ?>

                    <a
                        href="appointments.php"
                        class="btn btn-secondary"
                    >
                        Clear
                    </a>

                <?php endif; ?>

            </form>


            <!-- TABLE -->

            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>
                                Appointment ID
                            </th>

                            <th>
                                Patient
                            </th>

                            <th>
                                Doctor
                            </th>

                            <th>
                                Date
                            </th>

                            <th>
                                Time
                            </th>

                            <th>
                                Reason
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Actions
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php if (
                        $appointments &&
                        $appointments->num_rows > 0
                    ): ?>


                        <?php while (
                            $appointment =
                            $appointments->fetch_assoc()
                        ): ?>


                            <tr>

                                <!-- ID -->

                                <td>

                                    <strong>

                                        <?php
                                        echo htmlspecialchars(
                                            $appointment[
                                                'appointment_id'
                                            ]
                                        );
                                        ?>

                                    </strong>

                                </td>


                                <!-- PATIENT -->

                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $appointment[
                                            'patient_name'
                                        ]
                                    );
                                    ?>

                                    <br>

                                    <small>

                                        <?php
                                        echo htmlspecialchars(
                                            $appointment[
                                                'patient_code'
                                            ]
                                        );
                                        ?>

                                    </small>

                                </td>


                                <!-- DOCTOR -->

                                <td>

                                    Dr.
                                    <?php
                                    echo htmlspecialchars(
                                        $appointment[
                                            'doctor_name'
                                        ]
                                    );
                                    ?>

                                    <br>

                                    <small>

                                        <?php
                                        echo htmlspecialchars(
                                            $appointment[
                                                'specialization'
                                            ]
                                        );
                                        ?>

                                    </small>

                                </td>


                                <!-- DATE -->

                                <td>

                                    <?php
                                    echo date(
                                        'd M Y',
                                        strtotime(
                                            $appointment[
                                                'appointment_date'
                                            ]
                                        )
                                    );
                                    ?>

                                </td>


                                <!-- TIME -->

                                <td>

                                    <?php
                                    echo date(
                                        'h:i A',
                                        strtotime(
                                            $appointment[
                                                'appointment_time'
                                            ]
                                        )
                                    );
                                    ?>

                                </td>


                                <!-- REASON -->

                                <td>

                                    <?php

                                    echo htmlspecialchars(
                                        $appointment['reason']
                                    );

                                    ?>

                                </td>


                                <!-- STATUS -->

                                <td>

                                    <?php

                                    $statusClass =
                                        strtolower(
                                            $appointment['status']
                                        );

                                    ?>

                                    <span
                                        class="status status-<?php
                                        echo $statusClass;
                                        ?>"
                                    >

                                        <?php
                                        echo htmlspecialchars(
                                            $appointment['status']
                                        );
                                        ?>

                                    </span>

                                </td>


                                <!-- ACTIONS -->

                                <td>

                                    <a
                                        href="appointments.php?edit=<?php
                                        echo $appointment['id'];
                                        ?>"
                                        class="btn btn-warning btn-small"
                                    >
                                        Edit
                                    </a>


                                    <a
                                        href="appointments.php?delete=<?php
                                        echo $appointment['id'];
                                        ?>"
                                        class="btn btn-danger btn-small"
                                        onclick="return confirm(
                                            'Are you sure you want to delete this appointment?'
                                        );"
                                    >
                                        Delete
                                    </a>

                                </td>

                            </tr>


                        <?php endwhile; ?>


                    <?php else: ?>

                        <tr>

                            <td
                                colspan="8"
                                class="empty"
                            >

                                No appointments found.

                            </td>

                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

</body>

</html>