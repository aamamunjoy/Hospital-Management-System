-- Hospital Management System
-- Excel dummy-data import generated from Hospital_Management_Dummy_Data-1.xlsx
-- Import this file in phpMyAdmin after selecting/creating the hospital_management database.

CREATE DATABASE IF NOT EXISTS hospital_management
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hospital_management;

SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS prescriptions;
DROP TABLE IF EXISTS medical_records;
DROP TABLE IF EXISTS billing;
DROP TABLE IF EXISTS admissions;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS medicines;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS doctors;
DROP TABLE IF EXISTS departments;
DROP TABLE IF EXISTS system_settings;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(30),
    role ENUM('admin','doctor','receptionist','patient') NOT NULL DEFAULT 'patient',
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    department_id VARCHAR(20) NOT NULL UNIQUE,
    department_name VARCHAR(100) NOT NULL UNIQUE,
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB;

CREATE TABLE doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    doctor_id VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    qualification VARCHAR(150) NULL,
    phone VARCHAR(30),
    email VARCHAR(100),
    address VARCHAR(255),
    gender VARCHAR(20),
    date_of_birth DATE NULL,
    joining_date DATE NULL,
    consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    department_id INT NULL,
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    patient_id VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    gender VARCHAR(20),
    age INT NULL,
    date_of_birth DATE NULL,
    blood_group VARCHAR(10),
    phone VARCHAR(30),
    email VARCHAR(100),
    address VARCHAR(255),
    emergency_contact VARCHAR(30),
    emergency_contact_name VARCHAR(100),
    medical_history TEXT,
    allergies TEXT,
    registration_date DATE DEFAULT (CURRENT_DATE),
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    reason VARCHAR(255),
    status ENUM('Scheduled','Completed','Cancelled','Pending') NOT NULL DEFAULT 'Scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE admissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admission_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    admission_date DATE NOT NULL,
    room_no VARCHAR(30) NOT NULL,
    bed_no VARCHAR(30) NOT NULL,
    status ENUM('Admitted','Discharged') NOT NULL DEFAULT 'Admitted',
    discharge_date DATE NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_id VARCHAR(20) NOT NULL UNIQUE,
    medicine_name VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    unit_price DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT 0,
    status ENUM('Available','Unavailable') NOT NULL DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE medical_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_id INT NULL,
    diagnosis VARCHAR(255) NOT NULL,
    symptoms TEXT,
    treatment TEXT,
    notes TEXT,
    record_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE prescriptions (
    prescription_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    medical_record_id INT NULL,
    medicine_name VARCHAR(150) NOT NULL,
    dosage VARCHAR(100) NOT NULL,
    frequency VARCHAR(100) NOT NULL,
    duration VARCHAR(100) NOT NULL,
    instructions TEXT,
    prescription_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE RESTRICT,
    FOREIGN KEY (medical_record_id) REFERENCES medical_records(record_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE billing (
    invoice_id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    appointment_id INT NULL,
    consultation_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    medicine_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    test_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    room_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    other_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
    discount DECIMAL(10,2) NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    payment_status ENUM('Paid','Unpaid','Partial') NOT NULL DEFAULT 'Unpaid',
    payment_method ENUM('Cash','Card','Mobile Banking','Bank Transfer') NOT NULL DEFAULT 'Cash',
    billing_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE RESTRICT,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hospital_name VARCHAR(150) NOT NULL DEFAULT 'Hospital Management System',
    phone VARCHAR(30),
    email VARCHAR(100),
    address VARCHAR(255)
) ENGINE=InnoDB;

INSERT INTO users (username, password, full_name, email, role, status)
VALUES ('admin', '$2b$10$6P6AwuwmQbUYo8BABTqtUeBSq/cvxxtqjNgKIbOs2gMRWorQVmLVq', 'System Administrator', 'admin@hospital.com', 'admin', 'active');

INSERT INTO departments (department_id, department_name) VALUES
('DEP001', 'Medicine'),
('DEP002', 'Cardiology'),
('DEP003', 'Gynecology'),
('DEP004', 'Pediatrics'),
('DEP005', 'Orthopedics'),
('DEP006', 'Emergency'),
('DEP007', 'Pathology');

INSERT INTO patients
(patient_id, name, gender, age, blood_group, phone, address, status)
VALUES
('P0001', 'Rahim Uddin', 'Male', '45', 'B+', '1711000001', 'Dhaka'),
('P0002', 'Nusrat Jahan', 'Female', '32', 'O+', '1811000002', 'Gazipur'),
('P0003', 'Karim Ahmed', 'Male', '58', 'A+', '1911000003', 'Narayanganj'),
('P0004', 'Sumi Akter', 'Female', '27', 'AB+', '1611000004', 'Cumilla'),
('P0005', 'Hasan Mahmud', 'Male', '36', 'O-', '1511000005', 'Chattogram');

INSERT INTO doctors
(doctor_id, name, specialization, phone, consultation_fee, department_id, status)
SELECT x.doctor_id, x.name, x.specialization, x.phone, x.fee, d.id, 'Active'
FROM (
    SELECT CAST('D001' AS CHAR), 'Dr. Md. Kamal Hossain', 'Medicine', '1712000001', 800.0
    UNION ALL SELECT CAST('D002' AS CHAR), 'Dr. Farzana Rahman', 'Gynecology', '1812000002', 1000.0
    UNION ALL SELECT CAST('D003' AS CHAR), 'Dr. Saiful Islam', 'Cardiology', '1912000003', 1200.0
    UNION ALL SELECT CAST('D004' AS CHAR), 'Dr. Tania Ahmed', 'Pediatrics', '1612000004', 700.0
    UNION ALL SELECT CAST('D005' AS CHAR), 'Dr. Arif Khan', 'Orthopedics', '1512000005', 900.0
) AS x(doctor_id, name, specialization, phone, fee)
LEFT JOIN departments d ON d.department_name = x.specialization;

INSERT INTO appointments
(appointment_id, patient_id, doctor_id, appointment_date, appointment_time, status)
SELECT x.appointment_id, p.id, d.id, x.appointment_date, x.appointment_time, x.status
FROM (
    SELECT 'A0001', 'P0001', 'D001', '2026-09-01', '10:00', 'Completed'
    UNION ALL SELECT 'A0002', 'P0002', 'D002', '2026-09-01', '11:30', 'Completed'
    UNION ALL SELECT 'A0003', 'P0003', 'D003', '2026-09-02', '09:30', 'Completed'
    UNION ALL SELECT 'A0004', 'P0004', 'D004', '2026-09-03', '12:00', 'Pending'
    UNION ALL SELECT 'A0005', 'P0005', 'D005', '2026-09-04', '15:00', 'Cancelled'
) AS x(appointment_id, patient_code, doctor_code, appointment_date, appointment_time, status)
JOIN patients p ON p.patient_id = x.patient_code
JOIN doctors d ON d.doctor_id = x.doctor_code;

INSERT INTO admissions
(admission_id, patient_id, doctor_id, admission_date, room_no, bed_no, status)
SELECT x.admission_id, p.id, d.id, x.admission_date, x.room_no, x.bed_no, x.status
FROM (
    SELECT 'AD001', 'P0001', 'D001', '2026-09-01', 'R101', 'B01', 'Admitted'
    UNION ALL SELECT 'AD002', 'P0003', 'D003', '2026-09-02', 'R201', 'B03', 'Admitted'
    UNION ALL SELECT 'AD003', 'P0005', 'D005', '2026-09-03', 'R301', 'B02', 'Discharged'
) AS x(admission_id, patient_code, doctor_code, admission_date, room_no, bed_no, status)
JOIN patients p ON p.patient_id = x.patient_code
JOIN doctors d ON d.doctor_id = x.doctor_code;

INSERT INTO medicines
(medicine_id, medicine_name, category, unit_price, stock, status)
VALUES
('M001', 'Napa 500mg', 'Tablet', '2.0', '5000', 'Available'),
('M002', 'Omeprazole 20mg', 'Capsule', '3.5', '3000', 'Available'),
('M003', 'Azithromycin 500mg', 'Tablet', '15.0', '1200', 'Available'),
('M004', 'Salbutamol', 'Inhaler', '180.0', '150', 'Available'),
('M005', 'Ceftriaxone 1g', 'Injection', '120.0', '300', 'Available');

INSERT INTO billing
(invoice_number, patient_id, billing_date, consultation_fee, medicine_fee, test_fee, room_fee, total_amount, payment_status, payment_method)
SELECT x.bill_id, p.id, x.bill_date, x.consultation, x.medicine, x.test_fee, x.room_fee, x.total, 'Unpaid', 'Cash'
FROM (
    SELECT 'INV001', 'P0001', '2026-09-01', 800.0, 250.0, 600.0, 1000.0, 2650.0
    UNION ALL SELECT 'INV002', 'P0002', '2026-09-01', 1000.0, 450.0, 800.0, 0.0, 2250.0
    UNION ALL SELECT 'INV003', 'P0003', '2026-09-02', 1200.0, 850.0, 1500.0, 2000.0, 5550.0
    UNION ALL SELECT 'INV004', 'P0004', '2026-09-03', 700.0, 300.0, 500.0, 0.0, 1500.0
    UNION ALL SELECT 'INV005', 'P0005', '2026-09-04', 900.0, 600.0, 750.0, 1500.0, 3750.0
) AS x(bill_id, patient_code, bill_date, consultation, medicine, test_fee, room_fee, total)
JOIN patients p ON p.patient_id = x.patient_code;

INSERT INTO system_settings (hospital_name, phone, email, address)
VALUES ('Hospital Management System', '', 'admin@hospital.com', 'Dhaka, Bangladesh');

-- Verification queries
SELECT 'Patients' AS table_name, COUNT(*) AS imported_rows FROM patients
UNION ALL SELECT 'Doctors', COUNT(*) FROM doctors
UNION ALL SELECT 'Departments', COUNT(*) FROM departments
UNION ALL SELECT 'Appointments', COUNT(*) FROM appointments
UNION ALL SELECT 'Admissions', COUNT(*) FROM admissions
UNION ALL SELECT 'Medicines', COUNT(*) FROM medicines
UNION ALL SELECT 'Bills', COUNT(*) FROM billing;
