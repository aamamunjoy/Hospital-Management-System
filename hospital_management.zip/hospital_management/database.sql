-- =========================================================
-- HOSPITAL MANAGEMENT SYSTEM
-- Database: hospital_management
-- =========================================================

CREATE DATABASE IF NOT EXISTS hospital_management
CHARACTER SET utf8mb4
COLLATE utf8mb4_general_ci;

USE hospital_management;

-- =========================================================
-- 1. USERS TABLE
-- =========================================================

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    role ENUM('admin', 'doctor', 'receptionist', 'patient') NOT NULL DEFAULT 'patient',
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
-- 2. DOCTORS TABLE
-- =========================================================

CREATE TABLE doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    doctor_id VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    qualification VARCHAR(150),
    phone VARCHAR(20),
    email VARCHAR(100),
    address VARCHAR(255),
    gender ENUM('Male', 'Female', 'Other'),
    date_of_birth DATE,
    joining_date DATE,
    consultation_fee DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('Available', 'Unavailable') DEFAULT 'Available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- =========================================================
-- 3. PATIENTS TABLE
-- =========================================================

CREATE TABLE patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    patient_id VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    gender ENUM('Male', 'Female', 'Other'),
    date_of_birth DATE,
    blood_group VARCHAR(5),
    phone VARCHAR(20),
    email VARCHAR(100),
    address VARCHAR(255),
    emergency_contact VARCHAR(20),
    emergency_contact_name VARCHAR(100),
    medical_history TEXT,
    allergies TEXT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('Active', 'Inactive') DEFAULT 'Active',

    FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- =========================================================
-- 4. APPOINTMENTS TABLE
-- =========================================================

CREATE TABLE appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    reason TEXT,
    status ENUM(
        'Scheduled',
        'Completed',
        'Cancelled',
        'Pending'
    ) DEFAULT 'Scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (patient_id)
        REFERENCES patients(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (doctor_id)
        REFERENCES doctors(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- =========================================================
-- 5. MEDICAL RECORDS TABLE
-- =========================================================

CREATE TABLE medical_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    record_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_id INT NULL,
    diagnosis TEXT NOT NULL,
    symptoms TEXT,
    treatment TEXT,
    notes TEXT,
    record_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (patient_id)
        REFERENCES patients(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (doctor_id)
        REFERENCES doctors(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (appointment_id)
        REFERENCES appointments(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- =========================================================
-- 6. PRESCRIPTIONS TABLE
-- =========================================================

CREATE TABLE prescriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prescription_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    medical_record_id INT NULL,
    medicine_name VARCHAR(150) NOT NULL,
    dosage VARCHAR(100),
    frequency VARCHAR(100),
    duration VARCHAR(100),
    instructions TEXT,
    prescription_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (patient_id)
        REFERENCES patients(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (doctor_id)
        REFERENCES doctors(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (medical_record_id)
        REFERENCES medical_records(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- =========================================================
-- 7. BILLING TABLE
-- =========================================================

CREATE TABLE billing (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id VARCHAR(20) NOT NULL UNIQUE,
    patient_id INT NOT NULL,
    appointment_id INT NULL,
    consultation_fee DECIMAL(10,2) DEFAULT 0.00,
    medicine_fee DECIMAL(10,2) DEFAULT 0.00,
    test_fee DECIMAL(10,2) DEFAULT 0.00,
    room_fee DECIMAL(10,2) DEFAULT 0.00,
    other_fee DECIMAL(10,2) DEFAULT 0.00,
    discount DECIMAL(10,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) DEFAULT 0.00,
    payment_status ENUM(
        'Paid',
        'Unpaid',
        'Partial'
    ) DEFAULT 'Unpaid',
    payment_method ENUM(
        'Cash',
        'Card',
        'Mobile Banking',
        'Bank Transfer'
    ) DEFAULT 'Cash',
    billing_date DATE NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (patient_id)
        REFERENCES patients(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (appointment_id)
        REFERENCES appointments(id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- =========================================================
-- 8. SYSTEM SETTINGS TABLE
-- =========================================================

CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_name VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ON UPDATE CURRENT_TIMESTAMP
);

-- =========================================================
-- DEFAULT ADMIN ACCOUNT
-- =========================================================
-- Password: Admin@123
--
-- The password below is a bcrypt hash generated for:
-- Admin@123
-- =========================================================

INSERT INTO users
(username, password, full_name, email, role, status)
VALUES
(
    'admin',
    '$2b$10$6P6AwuwmQbUYo8BABTqtUeBSq/cvxxtqjNgKIbOs2gMRWorQVmLVq',
    'System Administrator',
    'admin@hospital.com',
    'admin',
    'active'
);

-- =========================================================
-- DEFAULT SYSTEM SETTINGS
-- =========================================================

INSERT INTO system_settings
(setting_name, setting_value)
VALUES
('hospital_name', 'City General Hospital'),
('hospital_phone', '+880 1XXXXXXXXX'),
('hospital_email', 'info@hospital.com'),
('hospital_address', 'Dhaka, Bangladesh');

-- =========================================================
-- END OF DATABASE
-- =========================================================
