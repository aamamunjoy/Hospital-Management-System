# CarePoint Hospital Management System

A PHP and MySQL admin system for patients, doctors, appointments, medical records, prescriptions, billing, users, reports, and hospital settings.

## Run with XAMPP

1. Copy the `hospital_management` folder into XAMPP's `htdocs` folder.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Open phpMyAdmin and import `database.sql`.
4. Open `http://localhost/hospital_management/`.
5. Sign in with username `admin` and password `Admin@123`.

Change the default password from the Users page after the first login.

## Database connection

The default local settings are in `config/database.php`:

- Host: `localhost`
- User: `root`
- Password: empty
- Database: `hospital_management`

Update these values if your MySQL setup is different.
